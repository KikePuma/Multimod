﻿Namespace BrainYesNo
	Partial Friend Class BrainYesNo
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.bn_yes = New Button()
			Me.bn_NO = New Button()
			Me.cb_bigLittle = New CheckBox()
			Me.cb_color = New CheckBox()
			Me.bn_Yes_No_color = New Button()
			Me.cb_yesNo_Color = New CheckBox()
			Me.bn_LoadUserData = New Button()
			Me.cb_powerYes = New ComboBox()
			Me.cb_powerNo = New ComboBox()
			Me.label1 = New Label()
			Me.label2 = New Label()
			Me.SuspendLayout()
			' 
			' bn_yes
			' 
			Me.bn_yes.AutoSize = True
			Me.bn_yes.Font = New Font("Microsoft Sans Serif", 36F, FontStyle.Regular, GraphicsUnit.Point, (CByte(0)))
			Me.bn_yes.Location = New Point(27, 27)
			Me.bn_yes.Name = "bn_yes"
			Me.bn_yes.Size = New Size(222, 161)
			Me.bn_yes.TabIndex = 0
			Me.bn_yes.Text = "YES"
			Me.bn_yes.UseVisualStyleBackColor = True
			' 
			' bn_NO
			' 
			Me.bn_NO.AutoSize = True
			Me.bn_NO.Font = New Font("Microsoft Sans Serif", 36F, FontStyle.Regular, GraphicsUnit.Point, (CByte(0)))
			Me.bn_NO.Location = New Point(526, 27)
			Me.bn_NO.Name = "bn_NO"
			Me.bn_NO.Size = New Size(222, 161)
			Me.bn_NO.TabIndex = 1
			Me.bn_NO.Text = "NO"
			Me.bn_NO.UseVisualStyleBackColor = True
			' 
			' cb_bigLittle
			' 
			Me.cb_bigLittle.AutoSize = True
			Me.cb_bigLittle.Checked = True
			Me.cb_bigLittle.CheckState = CheckState.Checked
			Me.cb_bigLittle.Location = New Point(272, 2)
			Me.cb_bigLittle.Name = "cb_bigLittle"
			Me.cb_bigLittle.Size = New Size(66, 17)
			Me.cb_bigLittle.TabIndex = 2
			Me.cb_bigLittle.Text = "BigSmall"
			Me.cb_bigLittle.UseVisualStyleBackColor = True
'			Me.cb_bigLittle.CheckedChanged += New System.EventHandler(Me.cb_bigLittle_CheckedChanged)
			' 
			' cb_color
			' 
			Me.cb_color.AutoSize = True
			Me.cb_color.Checked = True
			Me.cb_color.CheckState = CheckState.Checked
			Me.cb_color.Location = New Point(372, 191)
			Me.cb_color.Name = "cb_color"
			Me.cb_color.Size = New Size(50, 17)
			Me.cb_color.TabIndex = 3
			Me.cb_color.Text = "Color"
			Me.cb_color.UseVisualStyleBackColor = True
'			Me.cb_color.CheckedChanged += New System.EventHandler(Me.cb_color_CheckedChanged)
			' 
			' bn_Yes_No_color
			' 
			Me.bn_Yes_No_color.Font = New Font("Microsoft Sans Serif", 27.75F, FontStyle.Regular, GraphicsUnit.Point, (CByte(0)))
			Me.bn_Yes_No_color.Location = New Point(197, 214)
			Me.bn_Yes_No_color.Name = "bn_Yes_No_color"
			Me.bn_Yes_No_color.Size = New Size(378, 230)
			Me.bn_Yes_No_color.TabIndex = 4
			Me.bn_Yes_No_color.Text = "CHOICE"
			Me.bn_Yes_No_color.UseVisualStyleBackColor = True
			' 
			' cb_yesNo_Color
			' 
			Me.cb_yesNo_Color.AutoSize = True
			Me.cb_yesNo_Color.Location = New Point(372, 2)
			Me.cb_yesNo_Color.Name = "cb_yesNo_Color"
			Me.cb_yesNo_Color.Size = New Size(63, 17)
			Me.cb_yesNo_Color.TabIndex = 5
			Me.cb_yesNo_Color.Text = "COLOR"
			Me.cb_yesNo_Color.UseVisualStyleBackColor = True
'			Me.cb_yesNo_Color.CheckedChanged += New System.EventHandler(Me.cb_yesNo_Color_CheckedChanged)
			' 
			' bn_LoadUserData
			' 
			Me.bn_LoadUserData.Location = New Point(27, 393)
			Me.bn_LoadUserData.Name = "bn_LoadUserData"
			Me.bn_LoadUserData.Size = New Size(75, 34)
			Me.bn_LoadUserData.TabIndex = 10
			Me.bn_LoadUserData.Text = "Load User Data"
			Me.bn_LoadUserData.UseVisualStyleBackColor = True
'			Me.bn_LoadUserData.Click += New System.EventHandler(Me.bn_LoadUserData_Click)
			' 
			' cb_powerYes
			' 
			Me.cb_powerYes.FormattingEnabled = True
			Me.cb_powerYes.Location = New Point(46, 329)
			Me.cb_powerYes.Name = "cb_powerYes"
			Me.cb_powerYes.Size = New Size(121, 21)
			Me.cb_powerYes.TabIndex = 11
'			Me.cb_powerYes.SelectedIndexChanged += New System.EventHandler(Me.cb_powerYes_SelectedIndexChanged)
			' 
			' cb_powerNo
			' 
			Me.cb_powerNo.FormattingEnabled = True
			Me.cb_powerNo.Location = New Point(46, 366)
			Me.cb_powerNo.Name = "cb_powerNo"
			Me.cb_powerNo.Size = New Size(121, 21)
			Me.cb_powerNo.TabIndex = 12
'			Me.cb_powerNo.SelectedIndexChanged += New System.EventHandler(Me.cb_powerNo_SelectedIndexChanged)
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New Point(9, 332)
			Me.label1.Name = "label1"
			Me.label1.Size = New Size(31, 13)
			Me.label1.TabIndex = 13
			Me.label1.Text = "YES:"
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Location = New Point(9, 366)
			Me.label2.Name = "label2"
			Me.label2.Size = New Size(26, 13)
			Me.label2.TabIndex = 14
			Me.label2.Text = "NO:"
			' 
			' BrainYesNo
			' 
			Me.AutoScaleDimensions = New SizeF(6F, 13F)
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.ClientSize = New Size(760, 436)
			Me.Controls.Add(Me.label2)
			Me.Controls.Add(Me.label1)
			Me.Controls.Add(Me.cb_powerNo)
			Me.Controls.Add(Me.cb_powerYes)
			Me.Controls.Add(Me.bn_LoadUserData)
			Me.Controls.Add(Me.cb_yesNo_Color)
			Me.Controls.Add(Me.bn_Yes_No_color)
			Me.Controls.Add(Me.cb_color)
			Me.Controls.Add(Me.cb_bigLittle)
			Me.Controls.Add(Me.bn_NO)
			Me.Controls.Add(Me.bn_yes)
			Me.Name = "BrainYesNo"
			Me.Text = "Brain Game YES/NO"
'			Me.Load += New System.EventHandler(Me.BrainGame_Load)
'			Me.FormClosing += New System.Windows.Forms.FormClosingEventHandler(Me.BrainGame_FormClosing)
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private bn_yes As Button
		Private bn_NO As Button
		Private WithEvents cb_bigLittle As CheckBox
		Private WithEvents cb_color As CheckBox
		Private bn_Yes_No_color As Button
		Private WithEvents cb_yesNo_Color As CheckBox
		Private WithEvents bn_LoadUserData As Button
		Private WithEvents cb_powerYes As ComboBox
		Private WithEvents cb_powerNo As ComboBox
		Private label1 As Label
		Private label2 As Label

	End Class
End Namespace

