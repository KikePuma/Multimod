﻿Namespace BrainYesNo
	Partial Public Class BrainYesNo
		Inherits Form
		Private typeCogYes As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum = EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum.COG_PUSH
		Private typeCogNo As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum = EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum.COG_PULL
		#Region "vars"
		Private Delegate Sub d()
		Private myEmotivPower As EmotivSharp.EmotivPower
		Private Semaphore_BlockInvoke As New System.Threading.Semaphore(1, 1)
		Private tic As New System.Timers.Timer(800)
'INSTANT VB NOTE: The variable hot was renamed since Visual Basic does not allow class members with the same name:
		Private hot_Renamed As Boolean



		Private fontNO As Integer = 0
		Private fontYES As Integer = 0

		Private R As Integer = 0
		Private B As Integer = 10
		Private G As Integer = 0
		Private fontNo As Integer = 0
		Private fontYes As Integer = 0

		Public Property Hot() As Boolean
			Get
'INSTANT VB TODO TASK: Assignments within expressions are not supported in VB
'ORIGINAL LINE: Return hot ? True : !(hot = True);
				Return If(hot_Renamed, True, Not(hot_Renamed = True))
			End Get
			Set(ByVal value As Boolean)
				hot_Renamed = value
			End Set
		End Property
		#End Region ' ---vars---

		#Region "con"
		Public Sub New()
			InitializeComponent()
			cb_powerNo.Items.AddRange(System.Enum.GetNames(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)))
			cb_powerNo.SelectedItem = System.Enum.GetName(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), typeCogNo)
			cb_powerYes.Items.AddRange(System.Enum.GetNames(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)))
			cb_powerYes.SelectedItem = System.Enum.GetName(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), typeCogYes)
		End Sub

		Private Sub BrainGame_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
			' If you are looking at this line and it work in this location but not in your app
			' Well, EPOC DLL's only work under x86/32bit and not 64bit
			' so if your on a 64bit system you have to set the project to compile under x86
			' note: if you are not on a 64bit system you should set it to compile under x86 or it will no work on 64bit systems
			Try
				myEmotivPower = New EmotivSharp.EmotivPower(EmotivSharp.EmotivPower.headsetConnectionType.AskUser)
				AddHandler myEmotivPower.DIE, AddressOf myEmotivPower_DIE
			Catch
				Me.Close()
				Me.Dispose()
				Return
			End Try
			' connect to the data from the EPOC
			'    myEmotivPower.NewEmoState += new EmotivSharp.EmotivPower.BaseData.d_EmoState(EmotivPower_NewEmoState);
			AddHandler myEmotivPower.NewCognitivEvent, AddressOf myEmotivPower_NewCognitivEvent
			'    myEmotivPower.NewExpressivEvent += new EmotivSharp.EmotivPower.BaseData.d_ExpressivEvent(EmotivPower_NewExpressivEvent);
			AddHandler myEmotivPower.NewFacialEvent, AddressOf myEmotivPower_NewFacialEvent
			AddHandler myEmotivPower.NewAffectivEvent, AddressOf myEmotivPower_NewAffectivEvent
			'    myEmotivPower.NewHeadsetBaseEvent += new EmotivSharp.EmotivPower.BaseData.d_HeadsetBaseEvent(myEmotivPower_NewHeadsetBaseEvent);
			loadTimer()
		End Sub
		#End Region ' ---con---

		#Region "timer"
		Private Sub loadTimer()
			AddHandler tic.Elapsed, AddressOf tic_Elapsed
			tic.AutoReset = True
			tic.Start()
		End Sub

		Private Sub tic_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs)
			processDataTic()
		End Sub
		#End Region ' ---timer---

		#Region "EPOC INPUT"
		Private Sub myEmotivPower_NewCognitivEvent(ByVal CognitivEvent_Data As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData)
			If CognitivEvent_Data.myCognitivAction = typeCogYes Then
				Me.Invoke((d)Sub()
					fontYes = CInt(Fix(CognitivEvent_Data.actionPower))
					G = CInt(Fix(CognitivEvent_Data.actionPower))+150
				End Sub)
			End If
			If CognitivEvent_Data.myCognitivAction = typeCogNo Then
				Me.Invoke((d)Sub()
					fontNO = CInt(Fix(CognitivEvent_Data.actionPower))
					R = CInt(Fix(CognitivEvent_Data.actionPower))+150
				End Sub)
			End If
		End Sub
		Private Sub myEmotivPower_NewAffectivEvent(ByVal AffectivEvent_Data As EmotivSharp.EmotivPower.BaseData.AffectivState.AffectivData)
			SyncLock Me
				Try
					'this.Invoke((d)delegate()
					'{
					'    try
					'    {
					'    }
					'    catch
					'    {
					'        System.Windows.Forms.MessageBox.Show("myEmotivPower_NewFacialEvent Error");
					'    }
					'});
				Catch
				End Try
			End SyncLock
		End Sub
		Private Sub myEmotivPower_NewFacialEvent(ByVal FacialEvent_Data As EmotivSharp.EmotivPower.BaseData.FacialState.FacialData)
			SyncLock Me
				Try
							'if (FacialEvent_Data.WinkLeft)
							'    progressBar_leftWink.Value = 100;
							'if (FacialEvent_Data.WinkRight)
							'    progressBar_leftWink.Value = 0;
					Me.Invoke((d)Sub()
						Try
						Catch
							MessageBox.Show("myEmotivPower_NewFacialEvent Error")
						End Try
					End Sub)
				Catch
				End Try
			End SyncLock
		End Sub
		#End Region ' ---EPOC INPUT---

		#Region "processDataTic"
		Private Sub processDataTic()
			If Hot Then
				Return
			End If

			Try
						'this.SuspendLayout();
				Me.Invoke((d)Sub()
					Try
						If cb_bigLittle.Checked Then
							If fontNO > 20 Then
								fontNO -= 20
								Else
									fontNO = 1
								End If
									If fontNO <> bn_NO.Font.Size Then
										bn_NO.Font = New Font(bn_NO.Font.FontFamily, fontNO)
										bn_NO.Size = New Size(0, 0)
									End If
									If fontYes > 20 Then
										fontYes -= 20
										Else
											fontYes = 1
										End If
											If fontYes <> bn_yes.Font.Size Then
												bn_yes.Font = New Font(bn_yes.Font.FontFamily, fontYes)
												bn_yes.Size = New Size(0, 0)
											End If
						End If
						If cb_yesNo_Color.Checked Then
							If R > 170 Then
								bn_NO.BackColor = Color.Red
								Else
									If bn_NO.BackColor <> SystemColors.Control Then
										bn_NO.BackColor = SystemColors.Control
									End If
								End If
								If G > 170 Then
									bn_yes.BackColor = Color.YellowGreen
									Else
										If bn_yes.BackColor <> SystemColors.Control Then
											bn_yes.BackColor = SystemColors.Control
										End If
									End If
						End If
						If cb_color.Checked Then
							If R > 30 OrElse G > 30 Then
								bn_Yes_No_color.BackColor = Color.FromArgb(R, G, B)
							End If
						End If
						If R > 30 Then
							R -= 20
						End If
							If G > 30 Then
								G -= 20
							End If
					Catch
					End Try
				End Sub)
			Catch
			Finally
				'  this.ResumeLayout();
				hot_Renamed = False
			End Try
		End Sub
		#End Region ' ---processDataTic---

		#Region "CheckedChanged"
		Private Sub cb_bigLittle_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cb_bigLittle.CheckedChanged
				bn_NO.Visible = cb_bigLittle.Checked OrElse cb_yesNo_Color.Checked
				bn_yes.Visible = cb_bigLittle.Checked OrElse cb_yesNo_Color.Checked
			If Not cb_bigLittle.Checked Then
				bn_NO.Font = New Font(bn_yes.Font.FontFamily, 80)
				bn_yes.Font = New Font(bn_yes.Font.FontFamily, 80)
			End If
		End Sub

		Private Sub cb_yesNo_Color_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cb_yesNo_Color.CheckedChanged
			bn_NO.Visible = cb_bigLittle.Checked OrElse cb_yesNo_Color.Checked
			bn_yes.Visible = cb_bigLittle.Checked OrElse cb_yesNo_Color.Checked
			If Not cb_color.Checked Then
				bn_NO.BackColor = SystemColors.Control
				bn_yes.BackColor = SystemColors.Control
			End If
		End Sub

		Private Sub cb_color_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cb_color.CheckedChanged
			bn_Yes_No_color.Visible = cb_color.Checked

		End Sub
		#End Region ' ---CheckedChanged---

		#Region "Form Closing"
		Private Sub myEmotivPower_DIE()
			Me.BackColor = Color.Black
		End Sub
		Private Sub BrainGame_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
			Do While Not Hot
				System.Threading.Thread.SpinWait(100)
			Loop
			System.Threading.Thread.SpinWait(100)
			tic.Stop()
			tic.Dispose()

			myEmotivPower.Dispose()

			Application.Exit()

		End Sub
		#End Region ' ---Form Closing---

		Private Sub bn_LoadUserData_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_LoadUserData.Click
			Dim ofd As OpenFileDialog = New OpenFileDialog()
			ofd.Filter = "EMU|*.EMU"
			ofd.ShowDialog()
			If ofd.FileName IsNot Nothing AndAlso ofd.FileName.Length > 0 Then
				myEmotivPower.myUser.LoadUserProfile(ofd.FileName)
			End If

		End Sub
		Private Sub cb_powerYes_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cb_powerYes.SelectedIndexChanged
			Dim v = System.Enum.Parse(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), cb_powerYes.SelectedItem.ToString())
			If v IsNot Nothing Then
				typeCogYes = CType(v, EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)
			End If
		End Sub

		Private Sub cb_powerNo_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cb_powerNo.SelectedIndexChanged
			Dim v = System.Enum.Parse(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), cb_powerNo.SelectedItem.ToString())
			If v IsNot Nothing Then
				typeCogNo = CType(v, EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)
			End If

		End Sub
	End Class
End Namespace
