﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEmotivSharp
    Inherits System.Windows.Forms.Form
    ''' <summary>
    ''' Required designer variable.
    ''' </summary>
    Private components As System.ComponentModel.IContainer = Nothing

    ''' <summary>
    ''' Clean up any resources being used.
    ''' </summary>
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso (components IsNot Nothing) Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Windows Form Designer generated code"

    ''' <summary>
    ''' Required method for Designer support - do not modify
    ''' the contents of this method with the code editor.
    ''' </summary>
    Private Sub InitializeComponent()
        Me.rb_headsetConnection = New System.Windows.Forms.RadioButton
        Me.tb_EmoState = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.tb_CognitivData = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.tb_ExpressivEvent = New System.Windows.Forms.TextBox
        Me.cb_Blink = New System.Windows.Forms.CheckBox
        Me.groupBox_Facial = New System.Windows.Forms.GroupBox
        Me.tb_Num_FaceUpper = New System.Windows.Forms.TextBox
        Me.tb_Num_FaceLower = New System.Windows.Forms.TextBox
        Me.tb_LowerFace = New System.Windows.Forms.TextBox
        Me.tb_UpperFace = New System.Windows.Forms.TextBox
        Me.label5 = New System.Windows.Forms.Label
        Me.label4 = New System.Windows.Forms.Label
        Me.cb_LookingLeft = New System.Windows.Forms.CheckBox
        Me.cb_LookingRight = New System.Windows.Forms.CheckBox
        Me.cb_WinkRight = New System.Windows.Forms.CheckBox
        Me.cb_WinkLeft = New System.Windows.Forms.CheckBox
        Me.tb_Num_EmoState = New System.Windows.Forms.TextBox
        Me.tb_Num_Cognitiv = New System.Windows.Forms.TextBox
        Me.tb_CognitivEvent = New System.Windows.Forms.TextBox
        Me.label6 = New System.Windows.Forms.Label
        Me.tb_ExcitementShortTerm = New System.Windows.Forms.TextBox
        Me.tb_ExcitementLongTerm = New System.Windows.Forms.TextBox
        Me.tb_EngagementBoredom = New System.Windows.Forms.TextBox
        Me.label7 = New System.Windows.Forms.Label
        Me.label8 = New System.Windows.Forms.Label
        Me.label9 = New System.Windows.Forms.Label
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.label10 = New System.Windows.Forms.Label
        Me.tb_ExpressivEventTrainedSignature = New System.Windows.Forms.TextBox
        Me.groupBox2 = New System.Windows.Forms.GroupBox
        Me.progressBar_Battery = New System.Windows.Forms.ProgressBar
        Me.groupBox3 = New System.Windows.Forms.GroupBox
        Me.bn_AcceptTraining = New System.Windows.Forms.Button
        Me.bn_EraseTraining = New System.Windows.Forms.Button
        Me.bn_RejectTraining = New System.Windows.Forms.Button
        Me.bn_StartTraining = New System.Windows.Forms.Button
        Me.listBox_ExpressivTypes = New System.Windows.Forms.ListBox
        Me.rb_UseTrainedExpressiv = New System.Windows.Forms.RadioButton
        Me.rb_UseUniversalExpressiv = New System.Windows.Forms.RadioButton
        Me.tb_ExpressivSignature = New System.Windows.Forms.TextBox
        Me.bn_CheckForTrainedExpressivSignature = New System.Windows.Forms.Button
        Me.bn_LoadUserData = New System.Windows.Forms.Button
        Me.bn_SaveUserData = New System.Windows.Forms.Button
        Me.label11 = New System.Windows.Forms.Label
        Me.bn_getRaw = New System.Windows.Forms.Button
        Me.cb_goHot = New System.Windows.Forms.CheckBox
        Me.label12 = New System.Windows.Forms.Label
        Me.bn_Train = New System.Windows.Forms.Button
        Me.listBox_EmoTypes = New System.Windows.Forms.ListBox
        Me.groupBox4 = New System.Windows.Forms.GroupBox
        Me.progressBar_train = New System.Windows.Forms.ProgressBar
        Me.comboBox_users = New System.Windows.Forms.ComboBox
        Me.label13 = New System.Windows.Forms.Label
        Me.label14 = New System.Windows.Forms.Label
        Me.label15 = New System.Windows.Forms.Label
        Me.groupBox_Facial.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.groupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'rb_headsetConnection
        '
        Me.rb_headsetConnection.AutoSize = True
        Me.rb_headsetConnection.Enabled = False
        Me.rb_headsetConnection.Location = New System.Drawing.Point(13, 13)
        Me.rb_headsetConnection.Name = "rb_headsetConnection"
        Me.rb_headsetConnection.Size = New System.Drawing.Size(122, 17)
        Me.rb_headsetConnection.TabIndex = 0
        Me.rb_headsetConnection.TabStop = True
        Me.rb_headsetConnection.Text = "Headset Connection"
        Me.rb_headsetConnection.UseVisualStyleBackColor = True
        '
        'tb_EmoState
        '
        Me.tb_EmoState.Location = New System.Drawing.Point(92, 19)
        Me.tb_EmoState.Name = "tb_EmoState"
        Me.tb_EmoState.Size = New System.Drawing.Size(148, 20)
        Me.tb_EmoState.TabIndex = 1
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(30, 22)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(56, 13)
        Me.label1.TabIndex = 2
        Me.label1.Text = "EmoState:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(10, 48)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(76, 13)
        Me.label2.TabIndex = 4
        Me.label2.Text = "CognitivEvent:"
        '
        'tb_CognitivData
        '
        Me.tb_CognitivData.Location = New System.Drawing.Point(92, 45)
        Me.tb_CognitivData.Name = "tb_CognitivData"
        Me.tb_CognitivData.Size = New System.Drawing.Size(148, 20)
        Me.tb_CognitivData.TabIndex = 3
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(6, 18)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(83, 13)
        Me.label3.TabIndex = 6
        Me.label3.Text = "ExpressivEvent:"
        '
        'tb_ExpressivEvent
        '
        Me.tb_ExpressivEvent.Location = New System.Drawing.Point(9, 34)
        Me.tb_ExpressivEvent.Name = "tb_ExpressivEvent"
        Me.tb_ExpressivEvent.Size = New System.Drawing.Size(193, 20)
        Me.tb_ExpressivEvent.TabIndex = 5
        '
        'cb_Blink
        '
        Me.cb_Blink.AutoSize = True
        Me.cb_Blink.Location = New System.Drawing.Point(6, 19)
        Me.cb_Blink.Name = "cb_Blink"
        Me.cb_Blink.Size = New System.Drawing.Size(49, 17)
        Me.cb_Blink.TabIndex = 7
        Me.cb_Blink.Text = "Blink"
        Me.cb_Blink.UseVisualStyleBackColor = True
        '
        'groupBox_Facial
        '
        Me.groupBox_Facial.Controls.Add(Me.tb_Num_FaceUpper)
        Me.groupBox_Facial.Controls.Add(Me.tb_Num_FaceLower)
        Me.groupBox_Facial.Controls.Add(Me.tb_LowerFace)
        Me.groupBox_Facial.Controls.Add(Me.tb_UpperFace)
        Me.groupBox_Facial.Controls.Add(Me.label5)
        Me.groupBox_Facial.Controls.Add(Me.label4)
        Me.groupBox_Facial.Controls.Add(Me.cb_LookingLeft)
        Me.groupBox_Facial.Controls.Add(Me.cb_LookingRight)
        Me.groupBox_Facial.Controls.Add(Me.cb_WinkRight)
        Me.groupBox_Facial.Controls.Add(Me.cb_WinkLeft)
        Me.groupBox_Facial.Controls.Add(Me.cb_Blink)
        Me.groupBox_Facial.Location = New System.Drawing.Point(319, 21)
        Me.groupBox_Facial.Name = "groupBox_Facial"
        Me.groupBox_Facial.Size = New System.Drawing.Size(245, 134)
        Me.groupBox_Facial.TabIndex = 8
        Me.groupBox_Facial.TabStop = False
        Me.groupBox_Facial.Text = "Facial"
        '
        'tb_Num_FaceUpper
        '
        Me.tb_Num_FaceUpper.Location = New System.Drawing.Point(212, 33)
        Me.tb_Num_FaceUpper.Name = "tb_Num_FaceUpper"
        Me.tb_Num_FaceUpper.Size = New System.Drawing.Size(30, 20)
        Me.tb_Num_FaceUpper.TabIndex = 17
        '
        'tb_Num_FaceLower
        '
        Me.tb_Num_FaceLower.Location = New System.Drawing.Point(212, 77)
        Me.tb_Num_FaceLower.Name = "tb_Num_FaceLower"
        Me.tb_Num_FaceLower.Size = New System.Drawing.Size(30, 20)
        Me.tb_Num_FaceLower.TabIndex = 16
        '
        'tb_LowerFace
        '
        Me.tb_LowerFace.Location = New System.Drawing.Point(107, 77)
        Me.tb_LowerFace.Name = "tb_LowerFace"
        Me.tb_LowerFace.Size = New System.Drawing.Size(100, 20)
        Me.tb_LowerFace.TabIndex = 15
        '
        'tb_UpperFace
        '
        Me.tb_UpperFace.Location = New System.Drawing.Point(107, 33)
        Me.tb_UpperFace.Name = "tb_UpperFace"
        Me.tb_UpperFace.Size = New System.Drawing.Size(100, 20)
        Me.tb_UpperFace.TabIndex = 14
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(104, 61)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(63, 13)
        Me.label5.TabIndex = 13
        Me.label5.Text = "LowerFace:"
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(104, 16)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(63, 13)
        Me.label4.TabIndex = 12
        Me.label4.Text = "UpperFace:"
        '
        'cb_LookingLeft
        '
        Me.cb_LookingLeft.AutoSize = True
        Me.cb_LookingLeft.Location = New System.Drawing.Point(6, 88)
        Me.cb_LookingLeft.Name = "cb_LookingLeft"
        Me.cb_LookingLeft.Size = New System.Drawing.Size(85, 17)
        Me.cb_LookingLeft.TabIndex = 11
        Me.cb_LookingLeft.Text = "Looking Left"
        Me.cb_LookingLeft.UseVisualStyleBackColor = True
        '
        'cb_LookingRight
        '
        Me.cb_LookingRight.AutoSize = True
        Me.cb_LookingRight.Location = New System.Drawing.Point(6, 112)
        Me.cb_LookingRight.Name = "cb_LookingRight"
        Me.cb_LookingRight.Size = New System.Drawing.Size(92, 17)
        Me.cb_LookingRight.TabIndex = 10
        Me.cb_LookingRight.Text = "Looking Right"
        Me.cb_LookingRight.UseVisualStyleBackColor = True
        '
        'cb_WinkRight
        '
        Me.cb_WinkRight.AutoSize = True
        Me.cb_WinkRight.Location = New System.Drawing.Point(6, 65)
        Me.cb_WinkRight.Name = "cb_WinkRight"
        Me.cb_WinkRight.Size = New System.Drawing.Size(79, 17)
        Me.cb_WinkRight.TabIndex = 9
        Me.cb_WinkRight.Text = "Wink Right"
        Me.cb_WinkRight.UseVisualStyleBackColor = True
        '
        'cb_WinkLeft
        '
        Me.cb_WinkLeft.AutoSize = True
        Me.cb_WinkLeft.Location = New System.Drawing.Point(6, 42)
        Me.cb_WinkLeft.Name = "cb_WinkLeft"
        Me.cb_WinkLeft.Size = New System.Drawing.Size(72, 17)
        Me.cb_WinkLeft.TabIndex = 8
        Me.cb_WinkLeft.Text = "Wink Left"
        Me.cb_WinkLeft.UseVisualStyleBackColor = True
        '
        'tb_Num_EmoState
        '
        Me.tb_Num_EmoState.Location = New System.Drawing.Point(246, 19)
        Me.tb_Num_EmoState.Name = "tb_Num_EmoState"
        Me.tb_Num_EmoState.Size = New System.Drawing.Size(30, 20)
        Me.tb_Num_EmoState.TabIndex = 19
        '
        'tb_Num_Cognitiv
        '
        Me.tb_Num_Cognitiv.Location = New System.Drawing.Point(246, 45)
        Me.tb_Num_Cognitiv.Name = "tb_Num_Cognitiv"
        Me.tb_Num_Cognitiv.Size = New System.Drawing.Size(30, 20)
        Me.tb_Num_Cognitiv.TabIndex = 21
        '
        'tb_CognitivEvent
        '
        Me.tb_CognitivEvent.Location = New System.Drawing.Point(92, 69)
        Me.tb_CognitivEvent.Name = "tb_CognitivEvent"
        Me.tb_CognitivEvent.Size = New System.Drawing.Size(148, 20)
        Me.tb_CognitivEvent.TabIndex = 22
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(6, 26)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(62, 13)
        Me.label6.TabIndex = 23
        Me.label6.Text = "Excitement:"
        '
        'tb_ExcitementShortTerm
        '
        Me.tb_ExcitementShortTerm.Location = New System.Drawing.Point(77, 42)
        Me.tb_ExcitementShortTerm.Name = "tb_ExcitementShortTerm"
        Me.tb_ExcitementShortTerm.Size = New System.Drawing.Size(53, 20)
        Me.tb_ExcitementShortTerm.TabIndex = 24
        '
        'tb_ExcitementLongTerm
        '
        Me.tb_ExcitementLongTerm.Location = New System.Drawing.Point(164, 42)
        Me.tb_ExcitementLongTerm.Name = "tb_ExcitementLongTerm"
        Me.tb_ExcitementLongTerm.Size = New System.Drawing.Size(53, 20)
        Me.tb_ExcitementLongTerm.TabIndex = 25
        '
        'tb_EngagementBoredom
        '
        Me.tb_EngagementBoredom.Location = New System.Drawing.Point(77, 86)
        Me.tb_EngagementBoredom.Name = "tb_EngagementBoredom"
        Me.tb_EngagementBoredom.Size = New System.Drawing.Size(53, 20)
        Me.tb_EngagementBoredom.TabIndex = 26
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(161, 26)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(61, 13)
        Me.label7.TabIndex = 27
        Me.label7.Text = "Long Term "
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Location = New System.Drawing.Point(74, 26)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(59, 13)
        Me.label8.TabIndex = 28
        Me.label8.Text = "Short Term"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(74, 70)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(112, 13)
        Me.label9.TabIndex = 29
        Me.label9.Text = "Engagement Boredom"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.label6)
        Me.groupBox1.Controls.Add(Me.label9)
        Me.groupBox1.Controls.Add(Me.tb_ExcitementShortTerm)
        Me.groupBox1.Controls.Add(Me.label8)
        Me.groupBox1.Controls.Add(Me.tb_ExcitementLongTerm)
        Me.groupBox1.Controls.Add(Me.label7)
        Me.groupBox1.Controls.Add(Me.tb_EngagementBoredom)
        Me.groupBox1.Location = New System.Drawing.Point(13, 326)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(245, 119)
        Me.groupBox1.TabIndex = 30
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Excitement"
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(4, 64)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(94, 13)
        Me.label10.TabIndex = 31
        Me.label10.Text = "Trained Signature:"
        '
        'tb_ExpressivEventTrainedSignature
        '
        Me.tb_ExpressivEventTrainedSignature.Location = New System.Drawing.Point(103, 61)
        Me.tb_ExpressivEventTrainedSignature.Name = "tb_ExpressivEventTrainedSignature"
        Me.tb_ExpressivEventTrainedSignature.Size = New System.Drawing.Size(52, 20)
        Me.tb_ExpressivEventTrainedSignature.TabIndex = 32
        '
        'groupBox2
        '
        Me.groupBox2.Controls.Add(Me.progressBar_Battery)
        Me.groupBox2.Location = New System.Drawing.Point(13, 451)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(232, 46)
        Me.groupBox2.TabIndex = 33
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Headset Data"
        '
        'progressBar_Battery
        '
        Me.progressBar_Battery.Location = New System.Drawing.Point(9, 19)
        Me.progressBar_Battery.Name = "progressBar_Battery"
        Me.progressBar_Battery.Size = New System.Drawing.Size(100, 23)
        Me.progressBar_Battery.TabIndex = 0
        '
        'groupBox3
        '
        Me.groupBox3.Controls.Add(Me.bn_AcceptTraining)
        Me.groupBox3.Controls.Add(Me.bn_EraseTraining)
        Me.groupBox3.Controls.Add(Me.bn_RejectTraining)
        Me.groupBox3.Controls.Add(Me.bn_StartTraining)
        Me.groupBox3.Controls.Add(Me.listBox_ExpressivTypes)
        Me.groupBox3.Controls.Add(Me.tb_ExpressivEventTrainedSignature)
        Me.groupBox3.Controls.Add(Me.rb_UseTrainedExpressiv)
        Me.groupBox3.Controls.Add(Me.label10)
        Me.groupBox3.Controls.Add(Me.rb_UseUniversalExpressiv)
        Me.groupBox3.Controls.Add(Me.tb_ExpressivSignature)
        Me.groupBox3.Controls.Add(Me.bn_CheckForTrainedExpressivSignature)
        Me.groupBox3.Controls.Add(Me.label3)
        Me.groupBox3.Controls.Add(Me.tb_ExpressivEvent)
        Me.groupBox3.Location = New System.Drawing.Point(331, 161)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(213, 356)
        Me.groupBox3.TabIndex = 34
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Headset Training"
        '
        'bn_AcceptTraining
        '
        Me.bn_AcceptTraining.Location = New System.Drawing.Point(127, 238)
        Me.bn_AcceptTraining.Name = "bn_AcceptTraining"
        Me.bn_AcceptTraining.Size = New System.Drawing.Size(75, 34)
        Me.bn_AcceptTraining.TabIndex = 8
        Me.bn_AcceptTraining.Text = "Accept Training"
        Me.bn_AcceptTraining.UseVisualStyleBackColor = True
        '
        'bn_EraseTraining
        '
        Me.bn_EraseTraining.Location = New System.Drawing.Point(127, 318)
        Me.bn_EraseTraining.Name = "bn_EraseTraining"
        Me.bn_EraseTraining.Size = New System.Drawing.Size(75, 34)
        Me.bn_EraseTraining.TabIndex = 7
        Me.bn_EraseTraining.Text = "Erase Training"
        Me.bn_EraseTraining.UseVisualStyleBackColor = True
        '
        'bn_RejectTraining
        '
        Me.bn_RejectTraining.Location = New System.Drawing.Point(127, 278)
        Me.bn_RejectTraining.Name = "bn_RejectTraining"
        Me.bn_RejectTraining.Size = New System.Drawing.Size(75, 34)
        Me.bn_RejectTraining.TabIndex = 6
        Me.bn_RejectTraining.Text = "Reject Training"
        Me.bn_RejectTraining.UseVisualStyleBackColor = True
        '
        'bn_StartTraining
        '
        Me.bn_StartTraining.Location = New System.Drawing.Point(127, 198)
        Me.bn_StartTraining.Name = "bn_StartTraining"
        Me.bn_StartTraining.Size = New System.Drawing.Size(75, 34)
        Me.bn_StartTraining.TabIndex = 5
        Me.bn_StartTraining.Text = "Start Training"
        Me.bn_StartTraining.UseVisualStyleBackColor = True
        '
        'listBox_ExpressivTypes
        '
        Me.listBox_ExpressivTypes.FormattingEnabled = True
        Me.listBox_ExpressivTypes.Location = New System.Drawing.Point(1, 208)
        Me.listBox_ExpressivTypes.Name = "listBox_ExpressivTypes"
        Me.listBox_ExpressivTypes.Size = New System.Drawing.Size(120, 134)
        Me.listBox_ExpressivTypes.TabIndex = 4
        '
        'rb_UseTrainedExpressiv
        '
        Me.rb_UseTrainedExpressiv.AutoSize = True
        Me.rb_UseTrainedExpressiv.Location = New System.Drawing.Point(7, 165)
        Me.rb_UseTrainedExpressiv.Name = "rb_UseTrainedExpressiv"
        Me.rb_UseTrainedExpressiv.Size = New System.Drawing.Size(179, 17)
        Me.rb_UseTrainedExpressiv.TabIndex = 3
        Me.rb_UseTrainedExpressiv.Text = "Use Trained Expressiv Signature"
        Me.rb_UseTrainedExpressiv.UseVisualStyleBackColor = True
        '
        'rb_UseUniversalExpressiv
        '
        Me.rb_UseUniversalExpressiv.AutoSize = True
        '  Me.rb_UseUniversalExpressiv.Checked = True
        Me.rb_UseUniversalExpressiv.Location = New System.Drawing.Point(7, 141)
        Me.rb_UseUniversalExpressiv.Name = "rb_UseUniversalExpressiv"
        Me.rb_UseUniversalExpressiv.Size = New System.Drawing.Size(187, 17)
        Me.rb_UseUniversalExpressiv.TabIndex = 2
        Me.rb_UseUniversalExpressiv.TabStop = True
        Me.rb_UseUniversalExpressiv.Text = "Use Universal Expressiv Signature"
        Me.rb_UseUniversalExpressiv.UseVisualStyleBackColor = True
        '
        'tb_ExpressivSignature
        '
        Me.tb_ExpressivSignature.Location = New System.Drawing.Point(48, 114)
        Me.tb_ExpressivSignature.Name = "tb_ExpressivSignature"
        Me.tb_ExpressivSignature.Size = New System.Drawing.Size(100, 20)
        Me.tb_ExpressivSignature.TabIndex = 1
        Me.tb_ExpressivSignature.Text = "N/A"
        '
        'bn_CheckForTrainedExpressivSignature
        '
        Me.bn_CheckForTrainedExpressivSignature.Location = New System.Drawing.Point(7, 90)
        Me.bn_CheckForTrainedExpressivSignature.Name = "bn_CheckForTrainedExpressivSignature"
        Me.bn_CheckForTrainedExpressivSignature.Size = New System.Drawing.Size(187, 23)
        Me.bn_CheckForTrainedExpressivSignature.TabIndex = 0
        Me.bn_CheckForTrainedExpressivSignature.Text = "CheckForTrainedExpressivSignature"
        Me.bn_CheckForTrainedExpressivSignature.UseVisualStyleBackColor = True
        '
        'bn_LoadUserData
        '
        Me.bn_LoadUserData.Location = New System.Drawing.Point(13, 507)
        Me.bn_LoadUserData.Name = "bn_LoadUserData"
        Me.bn_LoadUserData.Size = New System.Drawing.Size(75, 34)
        Me.bn_LoadUserData.TabIndex = 9
        Me.bn_LoadUserData.Text = "Load User Data"
        Me.bn_LoadUserData.UseVisualStyleBackColor = True
        '
        'bn_SaveUserData
        '
        Me.bn_SaveUserData.Location = New System.Drawing.Point(94, 507)
        Me.bn_SaveUserData.Name = "bn_SaveUserData"
        Me.bn_SaveUserData.Size = New System.Drawing.Size(75, 34)
        Me.bn_SaveUserData.TabIndex = 10
        Me.bn_SaveUserData.Text = "Save User Data"
        Me.bn_SaveUserData.UseVisualStyleBackColor = True
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(99, 518)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(95, 13)
        Me.label11.TabIndex = 35
        Me.label11.Text = "Does NOT WORK"
        '
        'bn_getRaw
        '
        Me.bn_getRaw.Location = New System.Drawing.Point(211, 518)
        Me.bn_getRaw.Name = "bn_getRaw"
        Me.bn_getRaw.Size = New System.Drawing.Size(75, 23)
        Me.bn_getRaw.TabIndex = 37
        Me.bn_getRaw.Text = "gat raw"
        Me.bn_getRaw.UseVisualStyleBackColor = True
        '
        'cb_goHot
        '
        Me.cb_goHot.AutoSize = True
        Me.cb_goHot.Enabled = False
        Me.cb_goHot.Location = New System.Drawing.Point(13, 195)
        Me.cb_goHot.Name = "cb_goHot"
        Me.cb_goHot.Size = New System.Drawing.Size(85, 17)
        Me.cb_goHot.TabIndex = 38
        Me.cb_goHot.Text = "Is Hot Event"
        Me.cb_goHot.UseVisualStyleBackColor = True
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Location = New System.Drawing.Point(137, 15)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(32, 13)
        Me.label12.TabIndex = 40
        Me.label12.Text = "User:"
        '
        'bn_Train
        '
        Me.bn_Train.Location = New System.Drawing.Point(238, 40)
        Me.bn_Train.Name = "bn_Train"
        Me.bn_Train.Size = New System.Drawing.Size(75, 23)
        Me.bn_Train.TabIndex = 41
        Me.bn_Train.Text = "Train"
        Me.bn_Train.UseVisualStyleBackColor = True
        '
        'listBox_EmoTypes
        '
        Me.listBox_EmoTypes.FormattingEnabled = True
        Me.listBox_EmoTypes.Items.AddRange(New Object() {"NEUTRAL", "LEFT", "LIFT", "PULL", "PUSH", "RIGHT", "DISAPPEAR", "DROP", "ROTATE_CLOCKWISE", "ROTATE_COUNTER_CLOCKWISE", "ROTATE_FORWARDS", "ROTATE_LEFT", "ROTATE_REVERSE", "ROTATE_RIGHT"})
        Me.listBox_EmoTypes.Location = New System.Drawing.Point(13, 40)
        Me.listBox_EmoTypes.Name = "listBox_EmoTypes"
        Me.listBox_EmoTypes.Size = New System.Drawing.Size(219, 82)
        Me.listBox_EmoTypes.TabIndex = 42
        '
        'groupBox4
        '
        Me.groupBox4.Controls.Add(Me.tb_Num_EmoState)
        Me.groupBox4.Controls.Add(Me.tb_EmoState)
        Me.groupBox4.Controls.Add(Me.label1)
        Me.groupBox4.Controls.Add(Me.tb_CognitivData)
        Me.groupBox4.Controls.Add(Me.label2)
        Me.groupBox4.Controls.Add(Me.tb_Num_Cognitiv)
        Me.groupBox4.Controls.Add(Me.tb_CognitivEvent)
        Me.groupBox4.Location = New System.Drawing.Point(12, 225)
        Me.groupBox4.Name = "groupBox4"
        Me.groupBox4.Size = New System.Drawing.Size(295, 98)
        Me.groupBox4.TabIndex = 43
        Me.groupBox4.TabStop = False
        Me.groupBox4.Text = "Emo"
        '
        'progressBar_train
        '
        Me.progressBar_train.Location = New System.Drawing.Point(13, 129)
        Me.progressBar_train.Name = "progressBar_train"
        Me.progressBar_train.Size = New System.Drawing.Size(222, 23)
        Me.progressBar_train.TabIndex = 44
        Me.progressBar_train.Visible = False
        '
        'comboBox_users
        '
        Me.comboBox_users.FormattingEnabled = True
        Me.comboBox_users.Location = New System.Drawing.Point(167, 12)
        Me.comboBox_users.Name = "comboBox_users"
        Me.comboBox_users.Size = New System.Drawing.Size(121, 21)
        Me.comboBox_users.TabIndex = 45
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Location = New System.Drawing.Point(174, 45)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(95, 13)
        Me.label13.TabIndex = 46
        Me.label13.Text = "Does NOT WORK"
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.Location = New System.Drawing.Point(87, 82)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(95, 13)
        Me.label14.TabIndex = 47
        Me.label14.Text = "Does NOT WORK"
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Location = New System.Drawing.Point(150, 15)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(95, 13)
        Me.label15.TabIndex = 48
        Me.label15.Text = "Does NOT WORK"
        '
        'frmEmotivSharp
        '
        Me.ClientSize = New System.Drawing.Size(573, 553)
        Me.Controls.Add(Me.label15)
        Me.Controls.Add(Me.label14)
        Me.Controls.Add(Me.label13)
        Me.Controls.Add(Me.comboBox_users)
        Me.Controls.Add(Me.progressBar_train)
        Me.Controls.Add(Me.groupBox4)
        Me.Controls.Add(Me.listBox_EmoTypes)
        Me.Controls.Add(Me.bn_Train)
        Me.Controls.Add(Me.label12)
        Me.Controls.Add(Me.cb_goHot)
        Me.Controls.Add(Me.bn_getRaw)
        Me.Controls.Add(Me.label11)
        Me.Controls.Add(Me.bn_SaveUserData)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.bn_LoadUserData)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.groupBox_Facial)
        Me.Controls.Add(Me.rb_headsetConnection)
        Me.Name = "frmEmotivSharp"
        Me.Text = "EmotivSharp"
        Me.groupBox_Facial.ResumeLayout(True)
        '  Me.groupBox_Facial.PerformLayout()
        Me.groupBox1.ResumeLayout(True)
        Me.groupBox1.PerformLayout()
        Me.groupBox2.ResumeLayout(True)
        Me.groupBox3.ResumeLayout(True)
        Me.groupBox3.PerformLayout()
        Me.groupBox4.ResumeLayout(True)
        Me.groupBox4.PerformLayout()
        Me.ResumeLayout(True)
        Me.PerformLayout()

    End Sub

#End Region

    Private rb_headsetConnection As RadioButton
    Private tb_EmoState As TextBox
    Private label1 As Label
    Private label2 As Label
    Private tb_CognitivData As TextBox
    Private label3 As Label
    Private tb_ExpressivEvent As TextBox
    Private cb_Blink As CheckBox
    Private groupBox_Facial As GroupBox
    Private cb_LookingLeft As CheckBox
    Private cb_LookingRight As CheckBox
    Private cb_WinkRight As CheckBox
    Private cb_WinkLeft As CheckBox
    Private label5 As Label
    Private label4 As Label
    Private tb_LowerFace As TextBox
    Private tb_UpperFace As TextBox
    Private tb_Num_FaceUpper As TextBox
    Private tb_Num_FaceLower As TextBox
    Private tb_Num_EmoState As TextBox
    Private tb_Num_Cognitiv As TextBox
    Private tb_CognitivEvent As TextBox
    Private label6 As Label
    Private tb_ExcitementShortTerm As TextBox
    Private tb_ExcitementLongTerm As TextBox
    Private tb_EngagementBoredom As TextBox
    Private label7 As Label
    Private label8 As Label
    Private label9 As Label
    Private groupBox1 As GroupBox
    Private label10 As Label
    Private tb_ExpressivEventTrainedSignature As TextBox
    Private groupBox2 As GroupBox
    Private progressBar_Battery As ProgressBar
    Private groupBox3 As GroupBox
    Private WithEvents bn_CheckForTrainedExpressivSignature As Button
    Private tb_ExpressivSignature As TextBox
    Private WithEvents rb_UseTrainedExpressiv As RadioButton
    Private WithEvents rb_UseUniversalExpressiv As RadioButton
    Private WithEvents listBox_ExpressivTypes As ListBox
    Private WithEvents bn_RejectTraining As Button
    Private WithEvents bn_StartTraining As Button
    Private WithEvents bn_AcceptTraining As Button
    Private WithEvents bn_EraseTraining As Button
    Private WithEvents bn_SaveUserData As Button
    Private WithEvents bn_LoadUserData As Button
    Private label11 As Label
    Private WithEvents bn_getRaw As Button
    Private cb_goHot As CheckBox
    Private label12 As Label
    Private WithEvents bn_Train As Button
    Private listBox_EmoTypes As ListBox
    Private groupBox4 As GroupBox
    Private progressBar_train As ProgressBar
    Private comboBox_users As ComboBox
    Private label13 As Label
    Private label14 As Label
    Private label15 As Label

End Class
