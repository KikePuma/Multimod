﻿Public Class frmEmotivSharp

#Region "vars"
    Private myEmotivPower As EmotivSharp.EmotivPower
    Private Semaphore_BlockInvoke As New System.Threading.Semaphore(4, 4)

    Public Delegate Sub d1()
    Public Delegate Sub d2(ByVal EmoState_Data As EmotivSharp.EmotivPower.BaseData.EmoState.EmoData)
    Public Delegate Sub d3(ByVal AffectivEvent_Data As EmotivSharp.EmotivPower.BaseData.AffectivState.AffectivData)
    Public Delegate Sub d4(ByVal CognitivEvent_Data As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData)
    Public Delegate Sub d5(ByVal ExpressivEvent_Data As EmotivSharp.EmotivPower.BaseData.FacialState.ExpressivData)
    Public Delegate Sub d6(ByVal FacialState_Data As EmotivSharp.EmotivPower.BaseData.FacialState.FacialData)
    Public Delegate Sub d7(ByVal HeadsetBaseData As EmotivSharp.EmotivPower.BaseData.HeadsetBaseState.HeadsetBaseData)

#End Region ' ---vars---

#Region "con"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        EmotivSharp_Load()
        '        InitializeComponent()
        '        Me.ShowDialog()
    End Sub
#End Region ' ---con---

#Region "Load"
    Private Sub EmotivSharp_Load()
        Try
            ' I don't know how to check for real or fake headset, so ask user

            ' this connects to the Epoc
            '////////////////////
            ' If you are looking at this line and it work in this location but not in your app
            ' Well, EPOC DLL's only work under x86/32bit and not 64bit/x64
            ' so if your on a 64bit system you have to set the project to compile under x86
            ' note: if you are not on a 64bit system, you should set it to compile under x86, else it will no work on 64bit systems
            Try
                myEmotivPower = New EmotivSharp.EmotivPower(EmotivSharp.EmotivPower.headsetConnectionType.AskUser)
                AddHandler myEmotivPower.DIE, AddressOf myEmotivPower_DIE
            Catch
                Me.Dispose()
                Return
            End Try
            '////////////////////

            'this is the Events for getting data
            AddHandler myEmotivPower.NewEmoState, AddressOf EmotivPower_NewEmoState
            AddHandler myEmotivPower.NewCognitivEvent, AddressOf EmotivPower_NewCognitivEvent
            AddHandler myEmotivPower.NewExpressivEvent, AddressOf EmotivPower_NewExpressivEvent
            AddHandler myEmotivPower.NewFacialEvent, AddressOf EmotivPower_NewFacialEvent
            AddHandler myEmotivPower.NewAffectivEvent, AddressOf EmotivPower_NewAffectivEvent
            AddHandler myEmotivPower.NewHeadsetBaseEvent, AddressOf myEmotivPower_NewHeadsetBaseEvent

            'edk.dll does not have access to the RAW DATA
            'myEmotivPower.NewHeadsetRawDataEvent += new the0nex.EmotivPower.BaseData.d_HeadsetRawDataEvent(myEmotivPower_NewHeadsetRawDataEvent);


            ' gui stuff
            rb_headsetConnection.Enabled = True
            rb_headsetConnection.Checked = True

            ' Load List Box(listBox_ExpressixTypes)
            For Each item As String In System.Enum.GetNames(GetType(EmotivSharp.EmotivPower.Training.ExpressivAlgo_enum))
                listBox_ExpressivTypes.Items.Add(item)
            Next item

            listBox_EmoTypes.Items.Clear()
            ' Load List Box(listBox_ExpressixTypes)
            For Each item As Object In System.Enum.GetValues(GetType(EmotivSharp.EmotivPower.Training.CognitivAction))
                listBox_EmoTypes.Items.Add(item)
            Next item

            ' this is just some side stuff that has nothing to do with the project
            myWorkArea()
        Catch e2 As Exception
            ' paint the gui FAIL
            Dim myBitmap As Bitmap = New Bitmap(300, 300)
            Dim g As Graphics = Graphics.FromImage(myBitmap)
            g.DrawString("ERROR FAIL", New Font("Tahoma", 40), Brushes.White, New PointF(0, 0))
            Me.BackgroundImage = myBitmap
            Me.Text = "ERROR FAIL"
            MessageBox.Show("ERROR: Headset did not connect")
        End Try
    End Sub


#End Region ' ---Load---

#Region "Data Events"
    'edk.dll does not have access to the RAW DATA
    Private Sub myEmotivPower_NewHeadsetRawDataEvent(ByVal HeadsetRawDataEvent_Data As EmotivSharp.EmotivPower.BaseData.HeadsetRawDataState.HeadsetRawData_Data)

    End Sub

    Private Sub EmotivPower_NewAffectivEvent(ByVal AffectivEvent_Data As EmotivSharp.EmotivPower.BaseData.AffectivState.AffectivData)
        Semaphore_BlockInvoke.WaitOne()
        Me.Invoke(New d3(AddressOf NewAffectivEvent), New Object() {AffectivEvent_Data})
    End Sub
    Private Sub NewAffectivEvent(ByVal AffectivEvent_Data As EmotivSharp.EmotivPower.BaseData.AffectivState.AffectivData)
        Try
            tb_EngagementBoredom.Text = AffectivEvent_Data.EngagementBoredom.ToString()
            tb_ExcitementLongTerm.Text = AffectivEvent_Data.ExcitementLongTerm.ToString()
            tb_ExcitementShortTerm.Text = AffectivEvent_Data.ExcitementShortTerm.ToString()
        Catch
            MessageBox.Show("NewAffectivEvent Error")
        End Try
        Semaphore_BlockInvoke.Release()

    End Sub

    Private Sub EmotivPower_NewCognitivEvent(ByVal CognitivEvent_Data As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData)
        Semaphore_BlockInvoke.WaitOne()
        Me.Invoke(New d4(AddressOf NewCognitivEvent), New Object() {CognitivEvent_Data})
    End Sub
    Private Sub NewCognitivEvent(ByVal CognitivEvent_Data As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData)
        Try
            tb_CognitivData.Text = CognitivEvent_Data.myCognitivAction.ToString()
            tb_CognitivEvent.Text = CognitivEvent_Data.myCognitivEvent.ToString()
            tb_Num_Cognitiv.Text = CognitivEvent_Data.actionPower.ToString()
        Catch
            MessageBox.Show("EP_NewCognitivEvent Error")
        End Try
        Semaphore_BlockInvoke.Release()

    End Sub

    Private Sub EmotivPower_NewEmoState(ByVal EmoState_Data As EmotivSharp.EmotivPower.BaseData.EmoState.EmoData)
        Semaphore_BlockInvoke.WaitOne()
        Me.Invoke(New d2(AddressOf NewEmoState), New Object() {EmoState_Data})
    End Sub
    Private Sub NewEmoState(ByVal EmoState_Data As EmotivSharp.EmotivPower.BaseData.EmoState.EmoData)
        Try

            '////////////////////////
            '//////////////////////////////////////
            tb_EmoState.Text = EmoState_Data.myEmoAction.ToString()
            tb_Num_EmoState.Text = EmoState_Data.actionPower.ToString()
        Catch
            MessageBox.Show("EP_NewEmoState Error")
        End Try
        Semaphore_BlockInvoke.Release()
    End Sub

    Private Sub EmotivPower_NewExpressivEvent(ByVal ExpressivEvent_Data As EmotivSharp.EmotivPower.BaseData.FacialState.ExpressivData)
        Semaphore_BlockInvoke.WaitOne()
        Me.Invoke(New d5(AddressOf NewExpressivEvent), New Object() {ExpressivEvent_Data})
    End Sub
    Private Sub NewExpressivEvent(ByVal ExpressivEvent_Data As EmotivSharp.EmotivPower.BaseData.FacialState.ExpressivData)
        Try
            tb_ExpressivEvent.Text = ExpressivEvent_Data.myExpressivAction.ToString()
            tb_ExpressivEventTrainedSignature.Text = ExpressivEvent_Data.TrainedSignatureAvailable.ToString()
        Catch
            MessageBox.Show("EP_NewExpressivEvent Error")
        End Try
        Semaphore_BlockInvoke.Release()

    End Sub

    Private Sub EmotivPower_NewFacialEvent(ByVal FacialState_Data As EmotivSharp.EmotivPower.BaseData.FacialState.FacialData)
        Semaphore_BlockInvoke.WaitOne()
        Me.Invoke(New d6(AddressOf NewFacialEvent), New Object() {FacialState_Data})
    End Sub
    Private Sub NewFacialEvent(ByVal FacialState_Data As EmotivSharp.EmotivPower.BaseData.FacialState.FacialData)
        Try
            tb_UpperFace.Text = FacialState_Data.myFaceActionUpper.ToString()
            tb_Num_FaceUpper.Text = FacialState_Data.UpperFaceAmp.ToString()
            tb_LowerFace.Text = FacialState_Data.myFaceActionLower.ToString()
            tb_Num_FaceLower.Text = FacialState_Data.LowerFaceAmp.ToString()
            cb_Blink.Checked = FacialState_Data.Blink
            cb_WinkLeft.Checked = FacialState_Data.WinkLeft
            cb_LookingLeft.Checked = FacialState_Data.LookingLeft
            cb_LookingRight.Checked = FacialState_Data.LookingRight
            cb_WinkRight.Checked = FacialState_Data.WinkRight
            Me.cb_Blink.Update()



        Catch
            MessageBox.Show("EP_NewFacialEvent Error")
        End Try
        Semaphore_BlockInvoke.Release()
    End Sub
    Private Sub myEmotivPower_NewHeadsetBaseEvent(ByVal HeadsetBaseData As EmotivSharp.EmotivPower.BaseData.HeadsetBaseState.HeadsetBaseData)
        Semaphore_BlockInvoke.WaitOne()
        Me.Invoke(New d7(AddressOf NewHeadsetBaseEvent), New Object() {HeadsetBaseData})
    End Sub
    Private Sub NewHeadsetBaseEvent(ByVal HeadsetBaseData As EmotivSharp.EmotivPower.BaseData.HeadsetBaseState.HeadsetBaseData)
        Try
            If HeadsetBaseData.BatteryChargePercentage IsNot Nothing Then
                progressBar_Battery.Value = HeadsetBaseData.BatteryChargePercentage.Value
            Else
                progressBar_Battery.Value = 0
            End If

        Catch
            MessageBox.Show("NewHeadsetBaseEvent Error")
        End Try
        Semaphore_BlockInvoke.Release()
    End Sub
#End Region ' ---Data Events---

#Region "GUI Controls"
    Private Sub bn_CheckForTrainedExpressivSignature_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_CheckForTrainedExpressivSignature.Click
        If myEmotivPower.myTraining.CheckForTrainedExpressivSignature() Then
            tb_ExpressivSignature.Text = "Found"
        Else
            tb_ExpressivSignature.Text = "NOT Found"
        End If
    End Sub

    Private Sub rb_UseTrainedExpressiv_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles rb_UseTrainedExpressiv.CheckedChanged
        If Not myEmotivPower.myTraining.SelectExpressivSignature((Not rb_UseTrainedExpressiv.Checked)) Then
            rb_UseUniversalExpressiv.Checked = True
        End If
    End Sub

    Private Sub rb_UseUniversalExpressiv_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles rb_UseUniversalExpressiv.CheckedChanged
        If Not myEmotivPower.myTraining.SelectExpressivSignature(rb_UseUniversalExpressiv.Checked) Then
            rb_UseTrainedExpressiv.Checked = True
        End If
    End Sub

    Private Sub listBox_ExpressixTypes_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles listBox_ExpressivTypes.SelectedIndexChanged
        Dim item As EmotivSharp.EmotivPower.Training.ExpressivAlgo_enum = CType(System.Enum.Parse(GetType(EmotivSharp.EmotivPower.Training.ExpressivAlgo_enum), listBox_ExpressivTypes.SelectedItem.ToString()), EmotivSharp.EmotivPower.Training.ExpressivAlgo_enum)
        If Not myEmotivPower.myTraining.SelectExpressivType(item) Then
            MessageBox.Show("Could not select Expressiv Type")
        End If
    End Sub

    Private Sub bn_StartTraining_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_StartTraining.Click
        If Not myEmotivPower.myTraining.Start() Then
            MessageBox.Show("Could not Accept Expressiv Training")
        End If
    End Sub

    Private Sub bn_AcceptTraining_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_AcceptTraining.Click
        If Not myEmotivPower.myTraining.Accept() Then
            MessageBox.Show("Could not Accept Expressiv Training")
        End If
    End Sub

    Private Sub bn_RejectTraining_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_RejectTraining.Click
        If Not myEmotivPower.myTraining.Reject() Then
            MessageBox.Show("Could not Reject Expressiv Training")
        End If
    End Sub

    Private Sub bn_EraseTraining_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_EraseTraining.Click
        If Not myEmotivPower.myTraining.Erase() Then
            MessageBox.Show("Could not Erase Expressiv Training")
        End If
    End Sub

    Private Sub bn_LoadUserData_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_LoadUserData.Click
        Dim ofd As OpenFileDialog = New OpenFileDialog()
        ofd.Filter = "EMU|*.EMU"
        ofd.ShowDialog()
        If ofd.FileName IsNot Nothing AndAlso ofd.FileName.Length > 0 Then
            myEmotivPower.myUser.LoadUserProfile(ofd.FileName)
        End If
    End Sub

    Private Sub bn_SaveUserData_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_SaveUserData.Click
        myEmotivPower.myUser.SaveUserProfile("userProfile.txt")
    End Sub

    Private Sub bn_getRaw_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_getRaw.Click
        ' don't have EEG SDK :(
    End Sub
#End Region ' ---CUI Controls---

#Region "Form Closing"
    Private Shadows Disposed As Boolean = False
    Private Sub myEmotivPower_DIE()
        Me.BackColor = Color.Black
    End Sub
    Private Sub EmotivSharp_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        If Disposed Then
            Return
        End If
        e.Cancel = True
        Dim t As New System.Threading.Thread(New System.Threading.ThreadStart(AddressOf FormClosing1))
        t.Start()
    End Sub
    Private Sub FormClosing1()
        Disposed = True
        Semaphore_BlockInvoke.WaitOne()
        Semaphore_BlockInvoke.WaitOne()
        Semaphore_BlockInvoke.WaitOne()
        Semaphore_BlockInvoke.WaitOne()

        If myEmotivPower IsNot Nothing Then
            myEmotivPower.Dispose()
            System.Threading.Thread.Sleep(100)
        End If
        '        Me.Invoke(New d1(AddressOf thisClose))
    End Sub
    Private Sub thisClose()
        Me.Close()

    End Sub
#End Region ' ---Form Closing---

    ' this is extra stuff that should not in be needed
#Region "my temp-work Area"
    Private Function quickAskUserIsRealOrFakeHeadSet() As Boolean
        Dim DR As DialogResult = MessageBox.Show("Use Real Headset = Yes" & vbLf & "UseEmoComposer = NO", "real or fake headset??", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        Return DR = DialogResult.Yes
    End Function


    ' this is just extra stuff for othe project and testing
    Private Sub myWorkArea()
        AddHandler myEmotivPower.NewAffectivEvent, AddressOf myEmotivPower_NewAffectivEvent
    End Sub

    Private ticCold As System.Timers.Timer

    Private Sub EmotivSharp_excHit()
        ' just for fun I connected this to the affect
        Me.Invoke(New d1(AddressOf EmotivSharp_excHit1))
    End Sub
    Private Sub EmotivSharp_excHit1()
        cb_goHot.Checked = True
        If ticCold Is Nothing Then
            ticCold = New System.Timers.Timer(1000)
            AddHandler ticCold.Elapsed, AddressOf ticCold_Elapsed
        End If
        ticCold.Interval = (3000)
        ticCold.Interval = (1000)


        ticCold.Start()
    End Sub

    Private Sub ticCold_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs)
        Me.Invoke(New d1(AddressOf EmotivSharp_excHit2))
    End Sub
    Private Sub EmotivSharp_excHit2()
        cb_goHot.Checked = False
        ticCold.Stop()

    End Sub
    Public Event excHit As d1

    Private excCoundDown As Integer = 10
    Private lastTime? As Date
    Private Sub myEmotivPower_NewAffectivEvent(ByVal AffectivEvent_Data As EmotivSharp.EmotivPower.BaseData.AffectivState.AffectivData)
        If lastTime Is Nothing OrElse lastTime.Value = Date.MinValue Then
            lastTime = Date.Now
            excCoundDown = 10
        Else
            If Date.Now > lastTime.Value.AddSeconds(1) Then
                If AffectivEvent_Data.ExcitementShortTerm > 0.2F Then
                    Dim tempVar As Boolean = excCoundDown < 1
                    excCoundDown -= 1
                    If tempVar Then
                        ' AffectivEvent_Data.ExcitementShortTerm
                        RaiseEvent excHit()
                        lastTime = Date.MinValue
                    Else
                        excCoundDown -= 1
                    End If
                End If
            End If
        End If

    End Sub

#End Region ' my temp-work Area

    Private Sub bn_Train_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_Train.Click
        progressBar_train.Style = ProgressBarStyle.Marquee
        progressBar_train.Visible = True
        Dim action As EmotivSharp.EmotivPower.Training.CognitivAction = CType(listBox_EmoTypes.SelectedItem, EmotivSharp.EmotivPower.Training.CognitivAction)
        myEmotivPower.myTraining.Train(action, 0)
        progressBar_train.Style = ProgressBarStyle.Blocks
        progressBar_train.Visible = False
    End Sub
End Class
