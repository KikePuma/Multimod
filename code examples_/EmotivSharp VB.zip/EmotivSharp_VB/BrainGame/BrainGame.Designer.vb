﻿Namespace BrainGame
	Partial Friend Class BrainGame
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Private disposed As Boolean=False
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			SyncLock Me
				disposed = True
				If disposing AndAlso (components IsNot Nothing) Then
					components.Dispose()
				End If
				MyBase.Dispose(disposing)
			End SyncLock
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.progressBar_action = New ProgressBar()
			Me.progressBar_overAll = New ProgressBar()
			Me.label1 = New Label()
			Me.label2 = New Label()
			Me.progressBar_no = New ProgressBar()
			Me.progressBar_yes = New ProgressBar()
			Me.label3 = New Label()
			Me.label6 = New Label()
			Me.progressBar_Excitement = New ProgressBar()
			Me.lb_win1 = New Label()
			Me.lb_win2 = New Label()
			Me.lb_win4 = New Label()
			Me.lb_win3 = New Label()
			Me.label9 = New Label()
			Me.bn_LoadUserData = New Button()
			Me.label4 = New Label()
			Me.label5 = New Label()
			Me.cb_powerNo = New ComboBox()
			Me.cb_powerYes = New ComboBox()
			Me.label7 = New Label()
			Me.comB_action = New ComboBox()
			Me.label8 = New Label()
			Me.tb_level = New TextBox()
			Me.bn_resetNo = New Button()
			Me.bn_resetAction = New Button()
			Me.bn_resetEngagement = New Button()
			Me.bn_resetYes = New Button()
			Me.SuspendLayout()
			' 
			' progressBar_action
			' 
			Me.progressBar_action.Location = New Point(317, 215)
			Me.progressBar_action.Name = "progressBar_action"
			Me.progressBar_action.Size = New Size(100, 23)
			Me.progressBar_action.TabIndex = 0
			' 
			' progressBar_overAll
			' 
			Me.progressBar_overAll.Location = New Point(149, 31)
			Me.progressBar_overAll.Name = "progressBar_overAll"
			Me.progressBar_overAll.Size = New Size(437, 23)
			Me.progressBar_overAll.TabIndex = 1
			' 
			' label1
			' 
			Me.label1.AutoSize = True
			Me.label1.Location = New Point(343, 199)
			Me.label1.Name = "label1"
			Me.label1.Size = New Size(47, 13)
			Me.label1.TabIndex = 2
			Me.label1.Text = "ACTION"
			Me.label1.TextAlign = ContentAlignment.TopCenter
			' 
			' label2
			' 
			Me.label2.AutoSize = True
			Me.label2.Font = New Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point, (CByte(0)))
			Me.label2.Location = New Point(515, 129)
			Me.label2.Name = "label2"
			Me.label2.Size = New Size(43, 25)
			Me.label2.TabIndex = 4
			Me.label2.Text = "NO"
			Me.label2.TextAlign = ContentAlignment.TopCenter
			' 
			' progressBar_no
			' 
			Me.progressBar_no.Location = New Point(491, 153)
			Me.progressBar_no.Name = "progressBar_no"
			Me.progressBar_no.Size = New Size(100, 23)
			Me.progressBar_no.TabIndex = 3
			' 
			' progressBar_yes
			' 
			Me.progressBar_yes.Location = New Point(145, 153)
			Me.progressBar_yes.Name = "progressBar_yes"
			Me.progressBar_yes.Size = New Size(100, 23)
			Me.progressBar_yes.TabIndex = 5
			' 
			' label3
			' 
			Me.label3.AutoSize = True
			Me.label3.Font = New Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point, (CByte(0)))
			Me.label3.Location = New Point(172, 129)
			Me.label3.Name = "label3"
			Me.label3.Size = New Size(47, 24)
			Me.label3.TabIndex = 6
			Me.label3.Text = "YES"
			Me.label3.TextAlign = ContentAlignment.TopCenter
			' 
			' label6
			' 
			Me.label6.AutoSize = True
			Me.label6.Location = New Point(62, 340)
			Me.label6.Name = "label6"
			Me.label6.Size = New Size(109, 13)
			Me.label6.TabIndex = 24
			Me.label6.Text = "EngagementBoredom"
			' 
			' progressBar_Excitement
			' 
			Me.progressBar_Excitement.Location = New Point(90, 356)
			Me.progressBar_Excitement.Name = "progressBar_Excitement"
			Me.progressBar_Excitement.Size = New Size(554, 23)
			Me.progressBar_Excitement.TabIndex = 25
			' 
			' lb_win1
			' 
			Me.lb_win1.AutoSize = True
			Me.lb_win1.Location = New Point(162, 15)
			Me.lb_win1.Name = "lb_win1"
			Me.lb_win1.Size = New Size(96, 13)
			Me.lb_win1.TabIndex = 26
			Me.lb_win1.Text = "OverAll: Fill to WIN"
			' 
			' lb_win2
			' 
			Me.lb_win2.AutoSize = True
			Me.lb_win2.Location = New Point(268, 15)
			Me.lb_win2.Name = "lb_win2"
			Me.lb_win2.Size = New Size(96, 13)
			Me.lb_win2.TabIndex = 27
			Me.lb_win2.Text = "OverAll: Fill to WIN"
			' 
			' lb_win4
			' 
			Me.lb_win4.AutoSize = True
			Me.lb_win4.Location = New Point(471, 15)
			Me.lb_win4.Name = "lb_win4"
			Me.lb_win4.Size = New Size(96, 13)
			Me.lb_win4.TabIndex = 28
			Me.lb_win4.Text = "OverAll: Fill to WIN"
			' 
			' lb_win3
			' 
			Me.lb_win3.AutoSize = True
			Me.lb_win3.Location = New Point(371, 15)
			Me.lb_win3.Name = "lb_win3"
			Me.lb_win3.Size = New Size(96, 13)
			Me.lb_win3.TabIndex = 29
			Me.lb_win3.Text = "OverAll: Fill to WIN"
			' 
			' label9
			' 
			Me.label9.AutoSize = True
			Me.label9.Location = New Point(600, 340)
			Me.label9.Name = "label9"
			Me.label9.Size = New Size(109, 13)
			Me.label9.TabIndex = 30
			Me.label9.Text = "EngagementBoredom"
			' 
			' bn_LoadUserData
			' 
			Me.bn_LoadUserData.Location = New Point(12, 480)
			Me.bn_LoadUserData.Name = "bn_LoadUserData"
			Me.bn_LoadUserData.Size = New Size(75, 34)
			Me.bn_LoadUserData.TabIndex = 31
			Me.bn_LoadUserData.Text = "Load User Data"
			Me.bn_LoadUserData.UseVisualStyleBackColor = True
'			Me.bn_LoadUserData.Click += New System.EventHandler(Me.bn_LoadUserData_Click)
			' 
			' label4
			' 
			Me.label4.AutoSize = True
			Me.label4.Location = New Point(13, 454)
			Me.label4.Name = "label4"
			Me.label4.Size = New Size(26, 13)
			Me.label4.TabIndex = 35
			Me.label4.Text = "NO:"
			' 
			' label5
			' 
			Me.label5.AutoSize = True
			Me.label5.Location = New Point(13, 420)
			Me.label5.Name = "label5"
			Me.label5.Size = New Size(31, 13)
			Me.label5.TabIndex = 34
			Me.label5.Text = "YES:"
			' 
			' cb_powerNo
			' 
			Me.cb_powerNo.FormattingEnabled = True
			Me.cb_powerNo.Location = New Point(50, 454)
			Me.cb_powerNo.Name = "cb_powerNo"
			Me.cb_powerNo.Size = New Size(121, 21)
			Me.cb_powerNo.TabIndex = 33
'			Me.cb_powerNo.SelectedIndexChanged += New System.EventHandler(Me.cb_powerNo_SelectedIndexChanged)
			' 
			' cb_powerYes
			' 
			Me.cb_powerYes.FormattingEnabled = True
			Me.cb_powerYes.Location = New Point(50, 417)
			Me.cb_powerYes.Name = "cb_powerYes"
			Me.cb_powerYes.Size = New Size(121, 21)
			Me.cb_powerYes.TabIndex = 32
'			Me.cb_powerYes.SelectedIndexChanged += New System.EventHandler(Me.cb_powerYes_SelectedIndexChanged)
			' 
			' label7
			' 
			Me.label7.AutoSize = True
			Me.label7.Location = New Point(197, 423)
			Me.label7.Name = "label7"
			Me.label7.Size = New Size(40, 13)
			Me.label7.TabIndex = 37
			Me.label7.Text = "Action:"
			' 
			' comB_action
			' 
			Me.comB_action.FormattingEnabled = True
			Me.comB_action.Location = New Point(243, 420)
			Me.comB_action.Name = "comB_action"
			Me.comB_action.Size = New Size(121, 21)
			Me.comB_action.TabIndex = 36
'			Me.comB_action.SelectedIndexChanged += New System.EventHandler(Me.comB_action_SelectedIndexChanged)
			' 
			' label8
			' 
			Me.label8.AutoSize = True
			Me.label8.Location = New Point(197, 457)
			Me.label8.Name = "label8"
			Me.label8.Size = New Size(36, 13)
			Me.label8.TabIndex = 39
			Me.label8.Text = "Level:"
			' 
			' tb_level
			' 
			Me.tb_level.Location = New Point(243, 457)
			Me.tb_level.Name = "tb_level"
			Me.tb_level.Size = New Size(100, 20)
			Me.tb_level.TabIndex = 40
'			Me.tb_level.TextChanged += New System.EventHandler(Me.tb_level_TextChanged)
			' 
			' bn_resetNo
			' 
			Me.bn_resetNo.Location = New Point(634, 413)
			Me.bn_resetNo.Name = "bn_resetNo"
			Me.bn_resetNo.Size = New Size(75, 23)
			Me.bn_resetNo.TabIndex = 42
			Me.bn_resetNo.Text = "reset NO"
			Me.bn_resetNo.UseVisualStyleBackColor = True
'			Me.bn_resetNo.Click += New System.EventHandler(Me.bn_resetNo_Click)
			' 
			' bn_resetAction
			' 
			Me.bn_resetAction.Location = New Point(569, 449)
			Me.bn_resetAction.Name = "bn_resetAction"
			Me.bn_resetAction.Size = New Size(75, 34)
			Me.bn_resetAction.TabIndex = 43
			Me.bn_resetAction.Text = "reset ACTION"
			Me.bn_resetAction.UseVisualStyleBackColor = True
'			Me.bn_resetAction.Click += New System.EventHandler(Me.bn_resetAction_Click)
			' 
			' bn_resetEngagement
			' 
			Me.bn_resetEngagement.Location = New Point(541, 491)
			Me.bn_resetEngagement.Name = "bn_resetEngagement"
			Me.bn_resetEngagement.Size = New Size(129, 23)
			Me.bn_resetEngagement.TabIndex = 44
			Me.bn_resetEngagement.Text = "reset Engagement"
			Me.bn_resetEngagement.UseVisualStyleBackColor = True
'			Me.bn_resetEngagement.Click += New System.EventHandler(Me.bn_resetEngagement_Click)
			' 
			' bn_resetYes
			' 
			Me.bn_resetYes.Location = New Point(501, 413)
			Me.bn_resetYes.Name = "bn_resetYes"
			Me.bn_resetYes.Size = New Size(75, 23)
			Me.bn_resetYes.TabIndex = 45
			Me.bn_resetYes.Text = "resetYes"
			Me.bn_resetYes.UseVisualStyleBackColor = True
'			Me.bn_resetYes.Click += New System.EventHandler(Me.bn_resetYes_Click)
			' 
			' BrainGame
			' 
			Me.AutoScaleDimensions = New SizeF(6F, 13F)
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.ClientSize = New Size(791, 526)
			Me.Controls.Add(Me.bn_resetYes)
			Me.Controls.Add(Me.bn_resetEngagement)
			Me.Controls.Add(Me.bn_resetAction)
			Me.Controls.Add(Me.bn_resetNo)
			Me.Controls.Add(Me.tb_level)
			Me.Controls.Add(Me.label8)
			Me.Controls.Add(Me.label7)
			Me.Controls.Add(Me.comB_action)
			Me.Controls.Add(Me.label4)
			Me.Controls.Add(Me.label5)
			Me.Controls.Add(Me.cb_powerNo)
			Me.Controls.Add(Me.cb_powerYes)
			Me.Controls.Add(Me.bn_LoadUserData)
			Me.Controls.Add(Me.label9)
			Me.Controls.Add(Me.lb_win3)
			Me.Controls.Add(Me.lb_win4)
			Me.Controls.Add(Me.lb_win2)
			Me.Controls.Add(Me.lb_win1)
			Me.Controls.Add(Me.progressBar_Excitement)
			Me.Controls.Add(Me.label6)
			Me.Controls.Add(Me.label3)
			Me.Controls.Add(Me.progressBar_yes)
			Me.Controls.Add(Me.progressBar_no)
			Me.Controls.Add(Me.label1)
			Me.Controls.Add(Me.progressBar_overAll)
			Me.Controls.Add(Me.progressBar_action)
			Me.Controls.Add(Me.label2)
			Me.Name = "BrainGame"
			Me.Text = "Brain Game"
'			Me.Load += New System.EventHandler(Me.BrainGame_Load)
'			Me.FormClosing += New System.Windows.Forms.FormClosingEventHandler(Me.BrainGame_FormClosing)
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private progressBar_action As ProgressBar
		Private progressBar_overAll As ProgressBar
		Private label1 As Label
		Private label2 As Label
		Private progressBar_no As ProgressBar
		Private progressBar_yes As ProgressBar
		Private label3 As Label
		Private label6 As Label
		Private progressBar_Excitement As ProgressBar
		Private lb_win1 As Label
		Private lb_win2 As Label
		Private lb_win4 As Label
		Private lb_win3 As Label
		Private label9 As Label
		Private WithEvents bn_LoadUserData As Button
		Private label4 As Label
		Private label5 As Label
		Private WithEvents cb_powerNo As ComboBox
		Private WithEvents cb_powerYes As ComboBox
		Private label7 As Label
		Private WithEvents comB_action As ComboBox
		Private label8 As Label
		Private WithEvents tb_level As TextBox
		Private WithEvents bn_resetNo As Button
		Private WithEvents bn_resetAction As Button
		Private WithEvents bn_resetEngagement As Button
		Private WithEvents bn_resetYes As Button
	End Class
End Namespace

