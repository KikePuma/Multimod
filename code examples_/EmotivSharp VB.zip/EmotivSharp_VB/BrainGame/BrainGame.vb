﻿Imports System.ComponentModel
Imports System.Text

Namespace BrainGame
	Partial Public Class BrainGame
		Inherits Form
				Private typeCogYes As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum = EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum.COG_PUSH
				Private typeCogNo As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum = EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum.COG_PULL
				Private typeCogAction As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum = EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum.COG_LIFT
				Private level As Integer = 50
		Private myEmotivPower As EmotivSharp.EmotivPower

		Private Semaphore_BlockInvoke As New System.Threading.Semaphore(1, 1)

'INSTANT VB NOTE: The variable hot was renamed since Visual Basic does not allow class members with the same name:
		Private hot_Renamed As List(Of Boolean) = New List(Of Boolean)(4)

		' for music
		<System.Runtime.InteropServices.DllImport("winmm.dll")>
		Public Shared Function waveOutSetVolume(ByVal hwo As IntPtr, ByVal dwVolume As UInteger) As Integer
		End Function
		Private win As Boolean = False
		Public Property Hot() As List(Of Boolean)
			Get

				Return hot_Renamed
			End Get
			Set(ByVal value As List(Of Boolean))
				hot_Renamed = value

			End Set
		End Property
		Public Sub checkWin()
			If Not win Then
				Dim total As Integer = 0
				For Each b As Boolean In hot_Renamed
					If b Then
						total += 100 \ 4
					End If
				Next b
				If total = 100 Then
					win = True
					Dim tic As New System.Timers.Timer(1200)
					Dim ran As Random = New Random()
					tic.AutoReset = True
					AddHandler tic.Elapsed, (Sub()
						If Not Me.disposed Then
							Try
								Me.Invoke(CType(Sub() Me.BackColor = Color.FromArgb(ran.Next(255), ran.Next(255), ran.Next(255)), d))
							Catch
							End Try
						End If
					End Sub)
					tic.Start()
					Dim myPlayer As New System.Media.SoundPlayer()
					myPlayer.Stream = New System.IO.MemoryStream(My.Resources.music)
					' Calculate the volume that's being set
					Dim NewVolume As Integer = ((UShort.MaxValue / 10) * 1)
					' Set the same volume for both the left and the right channels
					Dim NewVolumeAllChannels As UInteger = ((CUInt(NewVolume) And &Hffff) Or (CUInt(NewVolume) << 16))
					' Set the volume
					waveOutSetVolume(IntPtr.Zero, NewVolumeAllChannels)
					myPlayer.PlayLooping()

				End If
				progressBar_overAll.Value = total
			End If
		End Sub
		Public Sub New()
			InitializeComponent()

			cb_powerNo.Items.AddRange(System.Enum.GetNames(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)))
			cb_powerNo.SelectedItem = System.Enum.GetName(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), typeCogNo)
			cb_powerYes.Items.AddRange(System.Enum.GetNames(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)))
			cb_powerYes.SelectedItem = System.Enum.GetName(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), typeCogYes)
			comB_action.Items.AddRange(System.Enum.GetNames(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)))
			comB_action.SelectedItem = System.Enum.GetName(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), typeCogAction)

			tb_level.Text = level.ToString()
			Dim b As Boolean=False
			Hot.Add(b)
			Hot.Add(b)
			Hot.Add(b)
			Hot.Add(b)
		End Sub

		Private Sub setLableWin(ByVal labelIN As Label)
			labelIN.Text = "GOOD JOB"
			labelIN.BackColor = Color.Red
		End Sub
		Private Sub unsetLabelWin(ByVal labelIN As Label, ByVal textIN As String)
			labelIN.Text = textIN
			labelIN.BackColor = SystemColors.Control
		End Sub
		Private Sub BrainGame_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
			' If you are looking at this line and it work in this location but not in your app
			' Well, EPOC DLL's only work under x86/32bit and not 64bit
			' so if your on a 64bit system you have to set the project to compile under x86
			' note: if you are not on a 64bit system you should set it to compile under x86 or it will no work on 64bit systems
			Try
				myEmotivPower = New EmotivSharp.EmotivPower(EmotivSharp.EmotivPower.headsetConnectionType.AskUser)
				AddHandler myEmotivPower.DIE, AddressOf myEmotivPower_DIE
			Catch
				Me.Close()
				Me.Dispose()
				Return
			End Try
			'    myEmotivPower.NewEmoState += new EmotivSharp.EmotivPower.BaseData.d_EmoState(EmotivPower_NewEmoState);
			AddHandler myEmotivPower.NewCognitivEvent, AddressOf myEmotivPower_NewCognitivEvent
			'    myEmotivPower.NewExpressivEvent += new EmotivSharp.EmotivPower.BaseData.d_ExpressivEvent(EmotivPower_NewExpressivEvent);
			AddHandler myEmotivPower.NewFacialEvent, AddressOf myEmotivPower_NewFacialEvent
			AddHandler myEmotivPower.NewAffectivEvent, AddressOf myEmotivPower_NewAffectivEvent
			'    myEmotivPower.NewHeadsetBaseEvent += new EmotivSharp.EmotivPower.BaseData.d_HeadsetBaseEvent(myEmotivPower_NewHeadsetBaseEvent);

		End Sub
		Private Sub DoTypeCogYes(ByVal CognitivEvent_Data As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData)

			Try
						If Hot(3) = False Then
							Me.Invoke((d)Sub()
								progressBar_yes.Value = CInt(Fix(CognitivEvent_Data.actionPower))
								If CInt(Fix(CognitivEvent_Data.actionPower)) >= level Then
									If Hot(3) = False Then
										Hot(3) = True
										setLableWin(lb_win4)
										setLableWin(label3)
										checkWin()
									End If
								End If
							End Sub)
						End If
			Catch
				MessageBox.Show("myEmotivPower_NewFacialEvent Error")
			End Try

		End Sub
		Private Sub DoTypeCogNo(ByVal CognitivEvent_Data As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData)
			Try

						If Hot(2) = False Then
							Me.Invoke((d)Sub()
								progressBar_no.Value = CInt(Fix(CognitivEvent_Data.actionPower))
								If CInt(Fix(CognitivEvent_Data.actionPower)) >= level Then
									If Hot(2) = False Then
										Hot(2) = True
										setLableWin(label2)
										setLableWin(lb_win3)
										checkWin()
									End If
								End If
							End Sub)
						End If
			Catch
				MessageBox.Show("myEmotivPower_NewFacialEvent Error")
			End Try
		End Sub
		Private Sub DoTypeCogAction(ByVal CognitivEvent_Data As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData)
			Try
				If Hot(1) = False Then

					Me.Invoke((d)Sub()
						progressBar_action.Value = CInt(Fix(CognitivEvent_Data.actionPower))
						If CInt(Fix(CognitivEvent_Data.actionPower)) >= level Then
							If Hot(1) = False Then
								Hot(1) = True
								setLableWin(lb_win2)
								setLableWin(label1)
								checkWin()
							End If
						End If
					End Sub)
				End If
			Catch
			End Try
		End Sub




		Private lastVal() As Single = { 0, 0, 0 }
		Private dropCount As Integer = 5
		Private Delegate Sub d()
		Private Sub myEmotivPower_NewCognitivEvent(ByVal CognitivEvent_Data As EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData)
			SyncLock Me
				If Not disposed Then
					If CognitivEvent_Data.myCognitivAction = typeCogNo Then
						DoTypeCogNo(CognitivEvent_Data)
						lastVal(0) = dropCount
					Else
						If lastVal(0) < 0 Then
							If lastVal(0) = -1 Then
								lastVal(0) -= 1
								Dim v = New EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData()
								DoTypeCogNo(v)
							End If
						Else
							lastVal(0) -= 1
						End If
						If CognitivEvent_Data.myCognitivAction = typeCogYes Then
							DoTypeCogYes(CognitivEvent_Data)
							lastVal(1) = dropCount
						Else
							If lastVal(1) < 0 Then
								If lastVal(1) = -1 Then
									lastVal(1) -= 1
									Dim v = New EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData()
									DoTypeCogYes(v)
								End If
							Else
								lastVal(1) -= 1
								If CognitivEvent_Data.myCognitivAction = typeCogAction Then
									DoTypeCogAction(CognitivEvent_Data)
									lastVal(2) = dropCount
								Else
									If lastVal(2) < 0 Then
										If lastVal(2) = -1 Then
											lastVal(2) -= 1
											Dim v = New EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivData()
											DoTypeCogAction(v)
										End If
									End If
								End If
							End If
						End If
					End If
				End If
			End SyncLock
		End Sub


		Private Sub myEmotivPower_NewAffectivEvent(ByVal AffectivEvent_Data As EmotivSharp.EmotivPower.BaseData.AffectivState.AffectivData)
			SyncLock Me
				If Not disposed Then
					Try
						If Hot(0) = False Then
							Me.Invoke((d)Sub()
								progressBar_Excitement.Value = CInt(Fix(AffectivEvent_Data.EngagementBoredom * 100))
								If CInt(Fix(AffectivEvent_Data.EngagementBoredom * 100)) >= level Then
									If Hot(0) = False Then
										Hot(0) = True
										setLableWin(label9)
										setLableWin(label6)
										setLableWin(lb_win1)
										checkWin()
									End If
								End If
							End Sub)
						End If
					Catch
						MessageBox.Show("myEmotivPower_NewFacialEvent Error")
					End Try
				End If
			End SyncLock
		End Sub

		Private Sub myEmotivPower_NewFacialEvent(ByVal FacialEvent_Data As EmotivSharp.EmotivPower.BaseData.FacialState.FacialData)
			Return
			SyncLock Me
				If Not disposed Then

					Me.Invoke((d)Sub()
						Try
							If FacialEvent_Data.WinkLeft Then
								progressBar_yes.Value = level
								Else
									progressBar_yes.Value = 0
								End If
									If FacialEvent_Data.WinkLeft Then
										If Hot(3) = False Then
											Hot(3) = True
											lb_win4.Text = "GOOD JOB"
										End If
									ElseIf Hot(3) = True Then
										Hot(3) = False
										lb_win4.Text = "---------"
									End If
						Catch
							MessageBox.Show("myEmotivPower_NewFacialEvent Error")
						End Try
					End Sub)
				End If
			End SyncLock
		End Sub

		Private Sub BrainGame_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
			myEmotivPower.Dispose()
		End Sub
		Private Sub myEmotivPower_DIE()
			Me.BackColor = Color.Black
		End Sub

		Private Sub bn_LoadUserData_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_LoadUserData.Click
			Dim ofd As OpenFileDialog = New OpenFileDialog()
			ofd.Filter = "EMU|*.EMU"
			ofd.ShowDialog()
			If ofd.FileName IsNot Nothing AndAlso ofd.FileName.Length > 0 Then
				myEmotivPower.myUser.LoadUserProfile(ofd.FileName)
			End If
		End Sub

		Private Sub cb_powerYes_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cb_powerYes.SelectedIndexChanged
			Dim v = System.Enum.Parse(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), cb_powerYes.SelectedItem.ToString())
			If v IsNot Nothing Then
				typeCogYes = CType(v, EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)
			End If
		End Sub

		Private Sub cb_powerNo_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cb_powerNo.SelectedIndexChanged
			Dim v = System.Enum.Parse(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), cb_powerNo.SelectedItem.ToString())
			If v IsNot Nothing Then
				typeCogNo = CType(v, EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)
			End If
		End Sub

		Private Sub comB_action_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles comB_action.SelectedIndexChanged
			Dim v = System.Enum.Parse(GetType(EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum), comB_action.SelectedItem.ToString())
			If v IsNot Nothing Then
				typeCogAction = CType(v, EmotivSharp.EmotivPower.BaseData.CognitivState.CognitivAction_enum)
			End If

		End Sub

		Private Sub tb_level_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles tb_level.TextChanged
			Try
				Dim tempVal As Integer = Convert.ToInt16(tb_level.Text)
				level = tempVal
			Catch
			End Try
		End Sub


		Private Sub bn_resetNo_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_resetNo.Click
			Hot(2) = False
			unsetLabelWin(label2, "NO")
			unsetLabelWin(lb_win3, "-------")
			progressBar_no.Value = 0
			checkWin()
		End Sub

		Private Sub bn_resetAction_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_resetAction.Click
			Hot(1) = False
			unsetLabelWin(label1, "ACTION")
			unsetLabelWin(lb_win1, "-------")
			progressBar_action.Value = 0
			checkWin()
		End Sub
		Private Sub bn_resetYes_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_resetYes.Click
			Hot(3) = False
			unsetLabelWin(label3, "YES")
			unsetLabelWin(lb_win4, "-------")
			progressBar_yes.Value = 0
			checkWin()
		End Sub

		Private Sub bn_resetEngagement_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bn_resetEngagement.Click
			Hot(0) = False
			unsetLabelWin(label9, "EngagementBoredom")
			unsetLabelWin(label6, "EngagementBoredom")
			unsetLabelWin(lb_win1, "-------")
			progressBar_Excitement.Value = 0
			checkWin()
		End Sub

	End Class
End Namespace
