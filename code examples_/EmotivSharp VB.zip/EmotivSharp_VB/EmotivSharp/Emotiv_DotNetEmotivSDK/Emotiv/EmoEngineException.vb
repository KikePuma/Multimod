﻿Imports System.Runtime.Serialization

Namespace Emotiv

	Public Class EmoEngineException
		Inherits ApplicationException
'INSTANT VB NOTE: The variable errorCode was renamed since Visual Basic does not allow class members with the same name:
		Private errorCode_Renamed As Integer

		Public Sub New()
		End Sub

		Public Sub New(ByVal message As String)
			MyBase.New(message)
		End Sub

		Protected Sub New(ByVal info As SerializationInfo, ByVal context As StreamingContext)
			MyBase.New(info, context)
		End Sub

		Public Sub New(ByVal message As String, ByVal inner As Exception)
			MyBase.New(message, inner)
		End Sub

		Public Property ErrorCode() As Integer
			Get
				Return Me.errorCode_Renamed
			End Get
			Set(ByVal value As Integer)
				Me.errorCode_Renamed = value
			End Set
		End Property
	End Class
End Namespace

