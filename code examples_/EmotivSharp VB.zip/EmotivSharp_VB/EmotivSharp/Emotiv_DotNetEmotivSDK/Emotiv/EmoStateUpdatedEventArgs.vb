﻿Namespace Emotiv

	Public Class EmoStateUpdatedEventArgs
		Inherits EmoEngineEventArgs
'INSTANT VB NOTE: The variable emoState was renamed since Visual Basic does not handle variables named the same as their type well:
		Public emoState_Renamed As EmoState

		Public Sub New(ByVal userId As UInteger, ByVal emoState_Renamed As EmoState)
			MyBase.New(userId)
			Me.emoState_Renamed = emoState_Renamed
		End Sub
	End Class
End Namespace

