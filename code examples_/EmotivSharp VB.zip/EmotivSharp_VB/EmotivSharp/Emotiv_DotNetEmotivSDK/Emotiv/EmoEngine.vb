﻿Imports System.Text
Imports System.Runtime.InteropServices
Imports System.Runtime.CompilerServices

Namespace Emotiv

	Public Class EmoEngine
		Private hData As IntPtr = EdkDll.EE_DataCreate()
		Private hEvent As IntPtr = EdkDll.EE_EmoEngineEventCreate()
'INSTANT VB NOTE: The variable instance was renamed since Visual Basic does not allow class members with the same name:
		Private Shared instance_Renamed As EmoEngine
		Private lastEmoState As New Dictionary(Of UInteger, EmoState)()

		Public Event AffectivEmoStateUpdated As AffectivEmoStateUpdatedEventHandler

		Public Event CognitivAutoSamplingNeutralCompleted As CognitivAutoSamplingNeutralCompletedEventHandler

		Public Event CognitivEmoStateUpdated As CognitivEmoStateUpdatedEventHandler

		Public Event CognitivSignatureUpdated As CognitivSignatureUpdatedEventHandler

		Public Event CognitivTrainingCompleted As CognitivTrainingCompletedEventHandler

		Public Event CognitivTrainingDataErased As CognitivTrainingDataErasedEventHandler

		Public Event CognitivTrainingFailed As CognitivTrainingFailedEventHandler

		Public Event CognitivTrainingRejected As CognitivTrainingRejectedEventHandler

		Public Event CognitivTrainingReset As CognitivTrainingResetEventHandler

		Public Event CognitivTrainingStarted As CognitivTrainingStartedEventEventHandler

		Public Event CognitivTrainingSucceeded As CognitivTrainingSucceededEventHandler

		Public Event EmoEngineConnected As EmoEngineConnectedEventHandler

		Public Event EmoEngineDisconnected As EmoEngineDisconnectedEventHandler

		Public Event EmoEngineEmoStateUpdated As EmoEngineEmoStateUpdatedEventHandler

		Public Event EmoStateUpdated As EmoStateUpdatedEventHandler

		Public Event ExpressivEmoStateUpdated As ExpressivEmoStateUpdatedEventHandler

		Public Event ExpressivTrainingCompleted As ExpressivTrainingCompletedEventHandler

		Public Event ExpressivTrainingDataErased As ExpressivTrainingDataErasedEventHandler

		Public Event ExpressivTrainingFailed As ExpressivTrainingFailedEventHandler

		Public Event ExpressivTrainingRejected As ExpressivTrainingRejectedEventHandler

		Public Event ExpressivTrainingReset As ExpressivTrainingResetEventHandler

		Public Event ExpressivTrainingStarted As ExpressivTrainingStartedEventEventHandler

		Public Event ExpressivTrainingSucceeded As ExpressivTrainingSucceededEventHandler

		Public Event InternalStateChanged As InternalStateChangedEventHandler

		Public Event UserAdded As UserAddedEventHandler

		Public Event UserRemoved As UserRemovedEventHandler

		Private Sub New()
		End Sub

		Public Sub CognitivGetActionSensitivity(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pAction1SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction2SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction3SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction4SensitivityOut As Integer)
			errorHandler(EdkDll.EE_CognitivGetActionSensitivity(userId, pAction1SensitivityOut, pAction2SensitivityOut, pAction3SensitivityOut, pAction4SensitivityOut))
		End Sub

		Public Function CognitivGetActionSkillRating(ByVal userId As UInteger, ByVal action As EdkDll.EE_CognitivAction_t) As Single
			Dim pActionSkillRatingOut As Single = 0f
			errorHandler(EdkDll.EE_CognitivGetActionSkillRating(userId, action, pActionSkillRatingOut))
			Return pActionSkillRatingOut
		End Function

		Public Function CognitivGetActivationLevel(ByVal userId As UInteger) As Integer
			Dim pLevelOut As Integer = 0
			errorHandler(EdkDll.EE_CognitivGetActivationLevel(userId, pLevelOut))
			Return pLevelOut
		End Function

		Public Function CognitivGetActiveActions(ByVal userId As UInteger) As UInteger
			Dim pActiveActionsOut As UInteger = 0
			errorHandler(EdkDll.EE_CognitivGetActiveActions(userId, pActiveActionsOut))
			Return pActiveActionsOut
		End Function

		Public Function CognitivGetOverallSkillRating(ByVal userId As UInteger) As Single
			Dim pOverallSkillRatingOut As Single = 0f
			errorHandler(EdkDll.EE_CognitivGetOverallSkillRating(userId, pOverallSkillRatingOut))
			Return pOverallSkillRatingOut
		End Function

		Public Function CognitivGetSignatureCacheSize(ByVal userId As UInteger) As UInteger
			Dim pSizeOut As UInteger = 0
			errorHandler(EdkDll.EE_CognitivGetSignatureCacheSize(userId, pSizeOut))
			Return pSizeOut
		End Function

		Public Function CognitivGetSignatureCaching(ByVal userId As UInteger) As UInteger
			Dim pEnabledOut As UInteger = 0
			errorHandler(EdkDll.EE_CognitivGetSignatureCaching(userId, pEnabledOut))
			Return pEnabledOut
		End Function

		Public Function CognitivGetTrainedSignatureActions(ByVal userId As UInteger) As UInteger
			Dim pTrainedActionsOut As UInteger = 0
			errorHandler(EdkDll.EE_CognitivGetTrainedSignatureActions(userId, pTrainedActionsOut))
			Return pTrainedActionsOut
		End Function

		Public Function CognitivGetTrainingAction(ByVal userId As UInteger) As EdkDll.EE_CognitivAction_t
			Dim _t As EdkDll.EE_CognitivAction_t
			errorHandler(EdkDll.EE_CognitivGetTrainingAction(userId, _t))
			Return _t
		End Function

		Public Function CognitivGetTrainingTime(ByVal userId As UInteger) As UInteger
			Dim pTrainingTimeOut As UInteger = 0
			errorHandler(EdkDll.EE_CognitivGetTrainingTime(userId, pTrainingTimeOut))
			Return pTrainingTimeOut
		End Function

		Public Sub CognitivSetActionSensitivity(ByVal userId As UInteger, ByVal action1Sensitivity As Integer, ByVal action2Sensitivity As Integer, ByVal action3Sensitivity As Integer, ByVal action4Sensitivity As Integer)
			errorHandler(EdkDll.EE_CognitivSetActionSensitivity(userId, action1Sensitivity, action2Sensitivity, action3Sensitivity, action4Sensitivity))
		End Sub

		Public Sub CognitivSetActivationLevel(ByVal userId As UInteger, ByVal level As Integer)
			errorHandler(EdkDll.EE_CognitivSetActivationLevel(userId, level))
		End Sub

		Public Sub CognitivSetActiveActions(ByVal userId As UInteger, ByVal activeActions As UInteger)
			errorHandler(EdkDll.EE_CognitivSetActiveActions(userId, activeActions))
		End Sub

		Public Sub CognitivSetSignatureCacheSize(ByVal userId As UInteger, ByVal size As UInteger)
			errorHandler(EdkDll.EE_CognitivSetSignatureCacheSize(userId, size))
		End Sub

		Public Sub CognitivSetSignatureCaching(ByVal userId As UInteger, ByVal enabled As UInteger)
			errorHandler(EdkDll.EE_CognitivSetSignatureCaching(userId, enabled))
		End Sub

		Public Sub CognitivSetTrainingAction(ByVal userId As UInteger, ByVal action As EdkDll.EE_CognitivAction_t)
			errorHandler(EdkDll.EE_CognitivSetTrainingAction(userId, action))
		End Sub

		Public Sub CognitivSetTrainingControl(ByVal userId As UInteger, ByVal control As EdkDll.EE_CognitivTrainingControl_t)
			errorHandler(EdkDll.EE_CognitivSetTrainingControl(userId, control))
		End Sub

		Public Sub CognitivStartSamplingNeutral(ByVal userId As UInteger)
			errorHandler(EdkDll.EE_CognitivStartSamplingNeutral(userId))
		End Sub

		Public Sub CognitivStopSamplingNeutral(ByVal userId As UInteger)
			errorHandler(EdkDll.EE_CognitivStopSamplingNeutral(userId))
		End Sub

		Public Sub Connect()
			errorHandler(EdkDll.EE_EngineConnect())
			Me.OnEmoEngineConnected(New EmoEngineEventArgs(UInteger.MaxValue))
		End Sub

		Public Sub Disconnect()
			errorHandler(EdkDll.EE_EngineDisconnect())
			Me.OnEmoEngineDisconnected(New EmoEngineEventArgs(UInteger.MaxValue))
		End Sub

		Public Sub EE_SaveUserProfile(ByVal userID As UInteger, ByVal szOutputFilename As String)
			errorHandler(EdkDll.EE_SaveUserProfile(userID, szOutputFilename))
		End Sub

		Public Function EngineGetNumUser() As UInteger
			Dim pNumUserOut As UInteger = 0
			errorHandler(EdkDll.EE_EngineGetNumUser(pNumUserOut))
			Return pNumUserOut
		End Function

		Public Shared Sub errorHandler(ByVal errorCode As Integer)
			If errorCode <> 0 Then
				Dim message As String = ""
				Select Case errorCode
					Case &H300
						message = "A supplied buffer is not large enough"

					Case &H301
						message = "Parameter is out of range"

					Case 770
						message = "Parameter is invalid"

					Case &H303
						message = "Parameter is locked"

					Case &H200
						message = "EmoEngine is unable to acquire EEG input data"

					Case &H101
						message = "Invalid profile archive"

					Case &H102
						message = "The base profile does not have a user ID"

					Case 1
						message = "Unknown error"

					Case &H500
						message = "EmoEngine has not been initialized"

					Case &H501
						message = "Connection with remote instance of EmoEngine has been lost"

					Case &H502
						message = "Unable to establish connection with remote instance of EmoEngine."

					Case &H400
						message = "User ID supplied to the function is invalid"

					Case &H600
						message = "There are no new EmoEngine events at this time."

					Case &H700
						message = "The gyro could not be calibrated.  The headset must remain still for at least 0.5 secs."

					Case &H800
						message = "The requested operation failed due to optimization settings."

					Case Else
						message = "Unknown error"
				End Select
				Dim exception As New EmoEngineException(message)
				exception.ErrorCode = errorCode
				Throw exception
			End If
		End Sub

		Public Function ExpressivGetSignatureType(ByVal userId As UInteger) As EdkDll.EE_ExpressivSignature_t
			Dim _t As EdkDll.EE_ExpressivSignature_t
			errorHandler(EdkDll.EE_ExpressivGetSignatureType(userId, _t))
			Return _t
		End Function

		Public Function ExpressivGetThreshold(ByVal userId As UInteger, ByVal algoName As EdkDll.EE_ExpressivAlgo_t, ByVal thresholdName As EdkDll.EE_ExpressivThreshold_t) As Integer
			Dim pValueOut As Integer = 0
			errorHandler(EdkDll.EE_ExpressivGetThreshold(userId, algoName, thresholdName, pValueOut))
			Return pValueOut
		End Function

		Public Function ExpressivGetTrainedSignatureActions(ByVal userId As UInteger) As UInteger
			Dim pTrainedActionsOut As UInteger = 0
			errorHandler(EdkDll.EE_ExpressivGetTrainedSignatureActions(userId, pTrainedActionsOut))
			Return pTrainedActionsOut
		End Function

		Public Function ExpressivGetTrainedSignatureAvailable(ByVal userId As UInteger) As Integer
			Dim pfAvailableOut As Integer = 0
			errorHandler(EdkDll.EE_ExpressivGetTrainedSignatureAvailable(userId, pfAvailableOut))
			Return pfAvailableOut
		End Function

		Public Function ExpressivGetTrainingAction(ByVal userId As UInteger) As EdkDll.EE_ExpressivAlgo_t
			Dim _t As EdkDll.EE_ExpressivAlgo_t
			errorHandler(EdkDll.EE_ExpressivGetTrainingAction(userId, _t))
			Return _t
		End Function

		Public Function ExpressivGetTrainingTime(ByVal userId As UInteger) As UInteger
			Dim pTrainingTimeOut As UInteger = 0
			errorHandler(EdkDll.EE_ExpressivGetTrainingTime(userId, pTrainingTimeOut))
			Return pTrainingTimeOut
		End Function

		Public Sub ExpressivSetSignatureType(ByVal userId As UInteger, ByVal sigType As EdkDll.EE_ExpressivSignature_t)
			errorHandler(EdkDll.EE_ExpressivSetSignatureType(userId, sigType))
		End Sub

		Public Sub ExpressivSetThreshold(ByVal userId As UInteger, ByVal algoName As EdkDll.EE_ExpressivAlgo_t, ByVal thresholdName As EdkDll.EE_ExpressivThreshold_t, ByVal value As Integer)
			errorHandler(EdkDll.EE_ExpressivSetThreshold(userId, algoName, thresholdName, value))
		End Sub

		Public Sub ExpressivSetTrainingAction(ByVal userId As UInteger, ByVal action As EdkDll.EE_ExpressivAlgo_t)
			errorHandler(EdkDll.EE_ExpressivSetTrainingAction(userId, action))
		End Sub

		Public Sub ExpressivSetTrainingControl(ByVal userId As UInteger, ByVal control As EdkDll.EE_ExpressivTrainingControl_t)
			errorHandler(EdkDll.EE_ExpressivSetTrainingControl(userId, control))
		End Sub

		Protected Overrides Sub Finalize()
			If Me.hEvent <> IntPtr.Zero Then
				EdkDll.EE_EmoEngineEventFree(Me.hEvent)
			End If
			If Me.hData <> IntPtr.Zero Then
				EdkDll.EE_DataFree(Me.hData)
			End If
		End Sub

		Public Function GetUserProfile(ByVal userId As UInteger) As Profile
			Dim profile_Renamed As New Profile()
			errorHandler(EdkDll.EE_GetUserProfile(userId, profile_Renamed.GetHandle()))
			Return profile_Renamed
		End Function

		Public Function HardwareGetVersion(ByVal userId As UInteger) As UInteger
			Dim num As UInteger
			errorHandler(EdkDll.EE_HardwareGetVersion(userId, num))
			Return num
		End Function

		Public Sub HeadsetGetGyroDelta(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pXOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pYOut As Integer)
			errorHandler(EdkDll.EE_HeadsetGetGyroDelta(userId, pXOut, pYOut))
		End Sub

		Public Function HeadsetGetSensorDetails(ByVal channelId As EdkDll.EE_InputChannels_t) As EdkDll.InputSensorDescriptor_t
			Dim _t As EdkDll.InputSensorDescriptor_t
			errorHandler(EdkDll.EE_HeadsetGetSensorDetails(channelId, _t))
			Return _t
		End Function

		Public Sub HeadsetGyroRezero(ByVal userId As UInteger)
			errorHandler(EdkDll.EE_HeadsetGyroRezero(userId))
		End Sub

		Public Sub LoadUserProfile(ByVal userID As UInteger, ByVal szInputFilename As String)
			errorHandler(EdkDll.EE_LoadUserProfile(userID, szInputFilename))
		End Sub

		Protected Overridable Sub OnAffectivEmoStateUpdated(ByVal e As EmoStateUpdatedEventArgs)
			RaiseEvent AffectivEmoStateUpdated(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivAutoSamplingNeutralCompleted(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivAutoSamplingNeutralCompleted(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivEmoStateUpdated(ByVal e As EmoStateUpdatedEventArgs)
			RaiseEvent CognitivEmoStateUpdated(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivSignatureUpdated(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivSignatureUpdated(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivTrainingCompleted(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivTrainingCompleted(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivTrainingDataErased(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivTrainingDataErased(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivTrainingFailed(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivTrainingFailed(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivTrainingRejected(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivTrainingRejected(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivTrainingReset(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivTrainingReset(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivTrainingStarted(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivTrainingStarted(Me, e)
		End Sub

		Protected Overridable Sub OnCognitivTrainingSucceeded(ByVal e As EmoEngineEventArgs)
			RaiseEvent CognitivTrainingSucceeded(Me, e)
		End Sub

		Protected Overridable Sub OnEmoEngineConnected(ByVal e As EmoEngineEventArgs)
			Me.lastEmoState.Clear()
			RaiseEvent EmoEngineConnected(Me, e)
		End Sub

		Protected Overridable Sub OnEmoEngineDisconnected(ByVal e As EmoEngineEventArgs)
			RaiseEvent EmoEngineDisconnected(Me, e)
		End Sub

		Protected Overridable Sub OnEmoEngineEmoStateUpdated(ByVal e As EmoStateUpdatedEventArgs)
			RaiseEvent EmoEngineEmoStateUpdated(Me, e)
		End Sub

		Protected Overridable Sub OnEmoStateUpdated(ByVal e As EmoStateUpdatedEventArgs)
			RaiseEvent EmoStateUpdated(Me, e)
		End Sub

		Protected Overridable Sub OnExpressivEmoStateUpdated(ByVal e As EmoStateUpdatedEventArgs)
			RaiseEvent ExpressivEmoStateUpdated(Me, e)
		End Sub

		Protected Overridable Sub OnExpressivTrainingCompleted(ByVal e As EmoEngineEventArgs)
			RaiseEvent ExpressivTrainingCompleted(Me, e)
		End Sub

		Protected Overridable Sub OnExpressivTrainingDataErased(ByVal e As EmoEngineEventArgs)
			RaiseEvent ExpressivTrainingDataErased(Me, e)
		End Sub

		Protected Overridable Sub OnExpressivTrainingFailed(ByVal e As EmoEngineEventArgs)
			RaiseEvent ExpressivTrainingFailed(Me, e)
		End Sub

		Protected Overridable Sub OnExpressivTrainingRejected(ByVal e As EmoEngineEventArgs)
			RaiseEvent ExpressivTrainingRejected(Me, e)
		End Sub

		Protected Overridable Sub OnExpressivTrainingReset(ByVal e As EmoEngineEventArgs)
			RaiseEvent ExpressivTrainingReset(Me, e)
		End Sub

		Protected Overridable Sub OnExpressivTrainingStarted(ByVal e As EmoEngineEventArgs)
			RaiseEvent ExpressivTrainingStarted(Me, e)
		End Sub

		Protected Overridable Sub OnExpressivTrainingSucceeded(ByVal e As EmoEngineEventArgs)
			RaiseEvent ExpressivTrainingSucceeded(Me, e)
		End Sub

		Protected Overridable Sub OnInternalStateChanged(ByVal e As EmoEngineEventArgs)
			RaiseEvent InternalStateChanged(Me, e)
		End Sub

		Protected Overridable Sub OnUserAdded(ByVal e As EmoEngineEventArgs)
			Me.lastEmoState.Add(e.userId, New EmoState())
			RaiseEvent UserAdded(Me, e)
		End Sub

		Protected Overridable Sub OnUserRemoved(ByVal e As EmoEngineEventArgs)
			Me.lastEmoState.Remove(e.userId)
			RaiseEvent UserRemoved(Me, e)
		End Sub

		Public Sub OptimizationDisable()
			errorHandler(EdkDll.EE_OptimizationDisable())
		End Sub

		Public Sub OptimizationEnable(ByVal param As OptimizationParam)
			If param Is Nothing Then
				Throw New NullReferenceException()
			End If
			errorHandler(EdkDll.EE_OptimizationEnable(param.GetHandle()))
		End Sub

		Public Function OptimizationGetParam() As OptimizationParam
			Dim param As New OptimizationParam()
			errorHandler(EdkDll.EE_OptimizationGetParam(param.GetHandle()))
			Return param
		End Function

		Public Function OptimizationIsEnabled() As Boolean
			Dim pEnabledOut As Boolean = False
			errorHandler(EdkDll.EE_OptimizationIsEnabled(pEnabledOut))
			Return pEnabledOut
		End Function

		Public Sub ProcessEvents()
			Me.ProcessEvents(0)
		End Sub

		Public Sub ProcessEvents(ByVal maxTimeMilliseconds As Integer)
			Dim stopwatch_Renamed As New Stopwatch()
			stopwatch_Renamed.Start()
			Do While EdkDll.EE_EngineGetNextEvent(Me.hEvent) = 0
				If (maxTimeMilliseconds <> 0) AndAlso (stopwatch_Renamed.ElapsedMilliseconds >= maxTimeMilliseconds) Then
					Return
				End If
				Dim pUserIdOut As UInteger = 0
				EdkDll.EE_EmoEngineEventGetUserId(Me.hEvent, pUserIdOut)
				Dim e As New EmoEngineEventArgs(pUserIdOut)
				Select Case EdkDll.EE_EmoEngineEventGetType(Me.hEvent)
					Case EdkDll.EE_Event_t.EE_CognitivEvent
						Select Case EdkDll.EE_CognitivEventGetType(Me.hEvent)
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivTrainingStarted
								Me.OnCognitivTrainingStarted(e)
								Continue Do
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivTrainingSucceeded
								Me.OnCognitivTrainingSucceeded(e)
								Continue Do
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivTrainingFailed
								Me.OnCognitivTrainingFailed(e)
								Continue Do
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivTrainingCompleted
								Me.OnCognitivTrainingCompleted(e)
								Continue Do
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivTrainingDataErased
								Me.OnCognitivTrainingDataErased(e)
								Continue Do
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivTrainingRejected
								Me.OnCognitivTrainingRejected(e)
								Continue Do
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivTrainingReset
								Me.OnCognitivTrainingReset(e)
								Continue Do
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivAutoSamplingNeutralCompleted
								Me.OnCognitivAutoSamplingNeutralCompleted(e)
								Continue Do
							Case EdkDll.EE_CognitivEvent_t.EE_CognitivSignatureUpdated
								Me.OnCognitivSignatureUpdated(e)
								Continue Do
						End Select
						Continue Do
					Case EdkDll.EE_Event_t.EE_ExpressivEvent
						Select Case EdkDll.EE_ExpressivEventGetType(Me.hEvent)
							Case EdkDll.EE_ExpressivEvent_t.EE_ExpressivTrainingStarted
								Me.OnExpressivTrainingStarted(e)
								Continue Do
							Case EdkDll.EE_ExpressivEvent_t.EE_ExpressivTrainingSucceeded
								Me.OnExpressivTrainingSucceeded(e)
								Continue Do
							Case EdkDll.EE_ExpressivEvent_t.EE_ExpressivTrainingFailed
								Me.OnExpressivTrainingFailed(e)
								Continue Do
							Case EdkDll.EE_ExpressivEvent_t.EE_ExpressivTrainingCompleted
								Me.OnExpressivTrainingCompleted(e)
								Continue Do
							Case EdkDll.EE_ExpressivEvent_t.EE_ExpressivTrainingDataErased
								Me.OnExpressivTrainingDataErased(e)
								Continue Do
							Case EdkDll.EE_ExpressivEvent_t.EE_ExpressivTrainingRejected
								Me.OnExpressivTrainingRejected(e)
								Continue Do
							Case EdkDll.EE_ExpressivEvent_t.EE_ExpressivTrainingReset
								Me.OnExpressivTrainingReset(e)
								Continue Do
						End Select
						Continue Do
					Case EdkDll.EE_Event_t.EE_InternalStateChanged

					Case EdkDll.EE_Event_t.EE_UserAdded
						Me.OnUserAdded(e)
						Continue Do
					Case EdkDll.EE_Event_t.EE_UserRemoved
						Me.OnUserRemoved(e)
						Continue Do
					Case EdkDll.EE_Event_t.EE_EmoStateUpdated
						Dim emoState_Renamed As New EmoState()
						errorHandler(EdkDll.EE_EmoEngineEventGetEmoState(Me.hEvent, emoState_Renamed.GetHandle()))
						Dim args2 As New EmoStateUpdatedEventArgs(pUserIdOut, emoState_Renamed)
						Me.OnEmoStateUpdated(args2)
						If Not emoState_Renamed.EmoEngineEqual(Me.lastEmoState(pUserIdOut)) Then
							args2 = New EmoStateUpdatedEventArgs(pUserIdOut, New EmoState(emoState_Renamed))
							Me.OnEmoEngineEmoStateUpdated(args2)
						End If
						If Not emoState_Renamed.AffectivEqual(Me.lastEmoState(pUserIdOut)) Then
							args2 = New EmoStateUpdatedEventArgs(pUserIdOut, New EmoState(emoState_Renamed))
							Me.OnAffectivEmoStateUpdated(args2)
						End If
						If Not emoState_Renamed.CognitivEqual(Me.lastEmoState(pUserIdOut)) Then
							args2 = New EmoStateUpdatedEventArgs(pUserIdOut, New EmoState(emoState_Renamed))
							Me.OnCognitivEmoStateUpdated(args2)
						End If
						If Not emoState_Renamed.ExpressivEqual(Me.lastEmoState(pUserIdOut)) Then
							args2 = New EmoStateUpdatedEventArgs(pUserIdOut, New EmoState(emoState_Renamed))
							Me.OnExpressivEmoStateUpdated(args2)
						End If
						Me.lastEmoState(pUserIdOut) = CType(emoState_Renamed.Clone(), EmoState)
						Continue Do
					Case Else
						Continue Do
				End Select
				Me.OnInternalStateChanged(e)
			Loop
		End Sub

		Public Sub RemoteConnect(ByVal ip As String, ByVal port As UShort)
			errorHandler(EdkDll.EE_EngineRemoteConnect(ip, port))
			Me.OnEmoEngineConnected(New EmoEngineEventArgs(UInteger.MaxValue))
		End Sub

		Public Sub ResetDetection(ByVal userId As UInteger, ByVal suite As EdkDll.EE_EmotivSuite_t, ByVal detectionBitVector As UInteger)
			errorHandler(EdkDll.EE_ResetDetection(userId, suite, detectionBitVector))
		End Sub

		Public Sub SetHardwarePlayerDisplay(ByVal userId As UInteger, ByVal playerNum As UInteger)
			errorHandler(EdkDll.EE_SetHardwarePlayerDisplay(userId, playerNum))
		End Sub

		Public Sub SetUserProfile(ByVal userId As UInteger, ByVal profile_Renamed As Profile)
			If profile_Renamed Is Nothing Then
				Throw New NullReferenceException()
			End If
			Dim bytes() As Byte = profile_Renamed.GetBytes()
			errorHandler(EdkDll.EE_SetUserProfile(userId, bytes, CUInt(bytes.Length)))
		End Sub

		Public Sub SoftwareGetVersion(<System.Runtime.InteropServices.Out()> ByRef pszVersionOut As String, <System.Runtime.InteropServices.Out()> ByRef pBuildNumOut As UInteger)
			Dim builder As New StringBuilder(&H80)
			errorHandler(EdkDll.EE_SoftwareGetVersion(builder, CUInt(builder.Capacity), pBuildNumOut))
			pszVersionOut = builder.ToString()
		End Sub

		Public Shared ReadOnly Property Instance() As EmoEngine
			Get
				If instance_Renamed Is Nothing Then
					instance_Renamed = New EmoEngine()
				End If
				Return instance_Renamed
			End Get
		End Property

		Public Delegate Sub AffectivEmoStateUpdatedEventHandler(ByVal sender As Object, ByVal e As EmoStateUpdatedEventArgs)

		Public Delegate Sub CognitivAutoSamplingNeutralCompletedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub CognitivEmoStateUpdatedEventHandler(ByVal sender As Object, ByVal e As EmoStateUpdatedEventArgs)

		Public Delegate Sub CognitivSignatureUpdatedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub CognitivTrainingCompletedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub CognitivTrainingDataErasedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub CognitivTrainingFailedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub CognitivTrainingRejectedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub CognitivTrainingResetEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub CognitivTrainingStartedEventEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub CognitivTrainingSucceededEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub EmoEngineConnectedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub EmoEngineDisconnectedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub EmoEngineEmoStateUpdatedEventHandler(ByVal sender As Object, ByVal e As EmoStateUpdatedEventArgs)

		Public Delegate Sub EmoStateUpdatedEventHandler(ByVal sender As Object, ByVal e As EmoStateUpdatedEventArgs)

		Public Delegate Sub ExpressivEmoStateUpdatedEventHandler(ByVal sender As Object, ByVal e As EmoStateUpdatedEventArgs)

		Public Delegate Sub ExpressivTrainingCompletedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub ExpressivTrainingDataErasedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub ExpressivTrainingFailedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub ExpressivTrainingRejectedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub ExpressivTrainingResetEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub ExpressivTrainingStartedEventEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub ExpressivTrainingSucceededEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub InternalStateChangedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub ProfileEventEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub UserAddedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)

		Public Delegate Sub UserRemovedEventHandler(ByVal sender As Object, ByVal e As EmoEngineEventArgs)
	End Class
End Namespace

