﻿Imports System.Text
Imports System.Runtime.InteropServices

Namespace Emotiv

	Public Class EdkDll
		Public Const EDK_BUFFER_TOO_SMALL As Integer = &H300
		Public Const EDK_CANNOT_ACQUIRE_DATA As Integer = &H200
		Public Const EDK_COG_EXCESS_MAX_ACTIONS As Integer = &H307
		Public Const EDK_COG_INVALID_ACTIVE_ACTION As Integer = &H306
		Public Const EDK_COG_INVALID_TRAINING_ACTION As Integer = &H304
		Public Const EDK_COG_INVALID_TRAINING_CONTROL As Integer = &H305
		Public Const EDK_EMOENGINE_DISCONNECTED As Integer = &H501
		Public Const EDK_EMOENGINE_PROXY_ERROR As Integer = &H502
		Public Const EDK_EMOENGINE_UNINITIALIZED As Integer = &H500
		Public Const EDK_EXP_NO_SIG_AVAILABLE As Integer = &H308
		Public Const EDK_FILESYSTEM_ERROR As Integer = &H309
		Public Const EDK_GYRO_NOT_CALIBRATED As Integer = &H700
		Public Const EDK_INVALID_PARAMETER As Integer = 770
		Public Const EDK_INVALID_PROFILE_ARCHIVE As Integer = &H101
		Public Const EDK_INVALID_USER_ID As Integer = &H400
		Public Const EDK_NO_EVENT As Integer = &H600
		Public Const EDK_NO_USER_FOR_BASEPROFILE As Integer = &H102
		Public Const EDK_OK As Integer = 0
		Public Const EDK_OPTIMIZATION_IS_ON As Integer = &H800
		Public Const EDK_OUT_OF_RANGE As Integer = &H301
		Public Const EDK_PARAMETER_LOCKED As Integer = &H303
		Public Const EDK_RESERVED1 As Integer = &H900
		Public Const EDK_UNKNOWN_ERROR As Integer = 1

		Public Shared Function EE_CognitivEventGetType(ByVal hEvent As IntPtr) As EE_CognitivEvent_t
			Return Unmanged_EE_CognitivEventGetType(hEvent)
		End Function

		Public Shared Function EE_CognitivGetActionSensitivity(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pAction1SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction2SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction3SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction4SensitivityOut As Integer) As Integer
			Return Unmanged_EE_CognitivGetActionSensitivity(userId, pAction1SensitivityOut, pAction2SensitivityOut, pAction3SensitivityOut, pAction4SensitivityOut)
		End Function

		Public Shared Function EE_CognitivGetActionSkillRating(ByVal userId As UInteger, ByVal action As EE_CognitivAction_t, <System.Runtime.InteropServices.Out()> ByRef pActionSkillRatingOut As Single) As Integer
			Return Unmanged_EE_CognitivGetActionSkillRating(userId, action, pActionSkillRatingOut)
		End Function

		Public Shared Function EE_CognitivGetActivationLevel(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pLevelOut As Integer) As Integer
			Return Unmanged_EE_CognitivGetActivationLevel(userId, pLevelOut)
		End Function

		Public Shared Function EE_CognitivGetActiveActions(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pActiveActionsOut As UInteger) As Integer
			Return Unmanged_EE_CognitivGetActiveActions(userId, pActiveActionsOut)
		End Function

		Public Shared Function EE_CognitivGetOverallSkillRating(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pOverallSkillRatingOut As Single) As Integer
			Return Unmanged_EE_CognitivGetOverallSkillRating(userId, pOverallSkillRatingOut)
		End Function

		Public Shared Function EE_CognitivGetSignatureCacheSize(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pSizeOut As UInteger) As Integer
			Return Unmanged_EE_CognitivGetSignatureCacheSize(userId, pSizeOut)
		End Function

		Public Shared Function EE_CognitivGetSignatureCaching(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pEnabledOut As UInteger) As Integer
			Return Unmanged_EE_CognitivGetSignatureCaching(userId, pEnabledOut)
		End Function

		Public Shared Function EE_CognitivGetTrainedSignatureActions(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pTrainedActionsOut As UInteger) As Integer
			Return Unmanged_EE_CognitivGetTrainedSignatureActions(userId, pTrainedActionsOut)
		End Function

		Public Shared Function EE_CognitivGetTrainingAction(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pActionOut As EE_CognitivAction_t) As Integer
			Return Unmanged_EE_CognitivGetTrainingAction(userId, pActionOut)
		End Function

		Public Shared Function EE_CognitivGetTrainingTime(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pTrainingTimeOut As UInteger) As Integer
			Return Unmanged_EE_CognitivGetTrainingTime(userId, pTrainingTimeOut)
		End Function

		Public Shared Function EE_CognitivSetActionSensitivity(ByVal userId As UInteger, ByVal action1Sensitivity As Integer, ByVal action2Sensitivity As Integer, ByVal action3Sensitivity As Integer, ByVal action4Sensitivity As Integer) As Integer
			Return Unmanged_EE_CognitivSetActionSensitivity(userId, action1Sensitivity, action2Sensitivity, action3Sensitivity, action4Sensitivity)
		End Function

		Public Shared Function EE_CognitivSetActivationLevel(ByVal userId As UInteger, ByVal level As Integer) As Integer
			Return Unmanged_EE_CognitivSetActivationLevel(userId, level)
		End Function

		Public Shared Function EE_CognitivSetActiveActions(ByVal userId As UInteger, ByVal activeActions As UInteger) As Integer
			Return Unmanged_EE_CognitivSetActiveActions(userId, activeActions)
		End Function

		Public Shared Function EE_CognitivSetSignatureCacheSize(ByVal userId As UInteger, ByVal size As UInteger) As Integer
			Return Unmanged_EE_CognitivSetSignatureCacheSize(userId, size)
		End Function

		Public Shared Function EE_CognitivSetSignatureCaching(ByVal userId As UInteger, ByVal enabled As UInteger) As Integer
			Return Unmanged_EE_CognitivSetSignatureCaching(userId, enabled)
		End Function

		Public Shared Function EE_CognitivSetTrainingAction(ByVal userId As UInteger, ByVal action As EE_CognitivAction_t) As Integer
			Return Unmanged_EE_CognitivSetTrainingAction(userId, action)
		End Function

		Public Shared Function EE_CognitivSetTrainingControl(ByVal userId As UInteger, ByVal control As EE_CognitivTrainingControl_t) As Integer
			Return Unmanged_EE_CognitivSetTrainingControl(userId, control)
		End Function

		Public Shared Function EE_CognitivStartSamplingNeutral(ByVal userId As UInteger) As Integer
			Return Unmanged_EE_CognitivStartSamplingNeutral(userId)
		End Function

		Public Shared Function EE_CognitivStopSamplingNeutral(ByVal userId As UInteger) As Integer
			Return Unmanged_EE_CognitivStopSamplingNeutral(userId)
		End Function

		Public Shared Function EE_DataAcquisitionEnable(ByVal userId As UInteger, ByVal enable As Boolean) As Integer
			Return Unmanaged_EE_DataAcquisitionEnable(userId, enable)
		End Function

		Public Shared Function EE_DataAcquisitionIsEnabled(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pEnableOut As Boolean) As Integer
			Return Unmanaged_EE_DataAcquisitionIsEnabled(userId, pEnableOut)
		End Function

		Public Shared Function EE_DataCreate() As IntPtr
			Return Unmanaged_EE_DataCreate()
		End Function

		Public Shared Sub EE_DataFree(ByVal hData As IntPtr)
			Unmanaged_EE_DataFree(hData)
		End Sub

		Public Shared Function EE_DataGet(ByVal hData As IntPtr, ByVal channel As EE_DataChannel_t, ByVal buffer() As Double, ByVal bufferSizeInSample As UInteger) As Integer
			Return Unmanaged_EE_DataGet(hData, channel, buffer, bufferSizeInSample)
		End Function

		Public Shared Function EE_DataGetBufferSizeInSec(<System.Runtime.InteropServices.Out()> ByRef pBufferSizeInSecOut As Single) As Integer
			Return Unmanaged_EE_DataGetBufferSizeInSec(pBufferSizeInSecOut)
		End Function

		Public Shared Function EE_DataGetNumberOfSample(ByVal hData As IntPtr, <System.Runtime.InteropServices.Out()> ByRef nSampleOut As UInteger) As Integer
			Return Unmanaged_EE_DataGetNumberOfSample(hData, nSampleOut)
		End Function

		Public Shared Function EE_DataGetSamplingRate(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pSamplingRateOut As UInteger) As Integer
			Return Unmanaged_EE_DataGetSamplingRate(userId, pSamplingRateOut)
		End Function

		Public Shared Function EE_DataSetBufferSizeInSec(ByVal bufferSizeInSec As Single) As Integer
			Return Unmanaged_EE_DataSetBufferSizeInSec(bufferSizeInSec)
		End Function

		Public Shared Function EE_DataSetMarker(ByVal userId As UInteger, ByVal marker As Integer) As Integer
			Return Unmanaged_EE_DataSetMarker(userId, marker)
		End Function

		Public Shared Function EE_DataSetSychronizationSignal(ByVal userId As UInteger, ByVal signal As Integer) As Integer
			Return Unmanaged_EE_DataSetSychronizationSignal(userId, signal)
		End Function

		Public Shared Function EE_DataUpdateHandle(ByVal userId As UInteger, ByVal hData As IntPtr) As Integer
			Return Unmanaged_EE_DataUpdateHandle(userId, hData)
		End Function

		Public Shared Function EE_EmoEngineEventCreate() As IntPtr
			Return Unmanged_EE_EmoEngineEventCreate()
		End Function

		Public Shared Sub EE_EmoEngineEventFree(ByVal hEvent As IntPtr)
			Unmanged_EE_EmoEngineEventFree(hEvent)
		End Sub

		Public Shared Function EE_EmoEngineEventGetEmoState(ByVal hEvent As IntPtr, ByVal hEmoState As IntPtr) As Integer
			Return Unmanged_EE_EmoEngineEventGetEmoState(hEvent, hEmoState)
		End Function

		Public Shared Function EE_EmoEngineEventGetType(ByVal hEvent As IntPtr) As EE_Event_t
			Return Unmanged_EE_EmoEngineEventGetType(hEvent)
		End Function

		Public Shared Function EE_EmoEngineEventGetUserId(ByVal hEvent As IntPtr, <System.Runtime.InteropServices.Out()> ByRef pUserIdOut As UInteger) As Integer
			Return Unmanged_EE_EmoEngineEventGetUserId(hEvent, pUserIdOut)
		End Function

		Public Shared Function EE_EmoStateCreate() As IntPtr
			Return Unmanged_EE_EmoStateCreate()
		End Function

		Public Shared Sub EE_EmoStateFree(ByVal hState As IntPtr)
			Unmanged_EE_EmoStateFree(hState)
		End Sub

		Public Shared Function EE_EnableDiagnostics(ByVal szFilename As String, ByVal fEnable As Integer, ByVal nReserved As Integer) As Integer
			Return Unmanged_EE_EnableDiagnostics(szFilename, fEnable, nReserved)
		End Function

		Public Shared Function EE_EngineClearEventQueue(ByVal eventTypes As Integer) As Integer
			Return Unmanged_EE_EngineClearEventQueue(eventTypes)
		End Function

		Public Shared Function EE_EngineConnect() As Integer
			Return Unmanged_EE_EngineConnect()
		End Function

		Public Shared Function EE_EngineDisconnect() As Integer
			Return Unmanged_EE_EngineDisconnect()
		End Function

		Public Shared Function EE_EngineGetNextEvent(ByVal hEvent As IntPtr) As Integer
			Return Unmanged_EE_EngineGetNextEvent(hEvent)
		End Function

		Public Shared Function EE_EngineGetNumUser(<System.Runtime.InteropServices.Out()> ByRef pNumUserOut As UInteger) As Integer
			Return Unmanged_EE_EngineGetNumUser(pNumUserOut)
		End Function

		Public Shared Function EE_EngineRemoteConnect(ByVal szHost As String, ByVal port As UShort) As Integer
			Return Unmanged_EE_EngineRemoteConnect(szHost, port)
		End Function

		Public Shared Function EE_ExpressivEventGetType(ByVal hEvent As IntPtr) As EE_ExpressivEvent_t
			Return Unmanged_EE_ExpressivEventGetType(hEvent)
		End Function

		Public Shared Function EE_ExpressivGetSignatureType(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pSigTypeOut As EE_ExpressivSignature_t) As Integer
			Return Unmanged_EE_ExpressivGetSignatureType(userId, pSigTypeOut)
		End Function

		Public Shared Function EE_ExpressivGetThreshold(ByVal userId As UInteger, ByVal algoName As EE_ExpressivAlgo_t, ByVal thresholdName As EE_ExpressivThreshold_t, <System.Runtime.InteropServices.Out()> ByRef pValueOut As Integer) As Integer
			Return Unmanged_EE_ExpressivGetThreshold(userId, algoName, thresholdName, pValueOut)
		End Function

		Public Shared Function EE_ExpressivGetTrainedSignatureActions(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pTrainedActionsOut As UInteger) As Integer
			Return Unmanged_EE_ExpressivGetTrainedSignatureActions(userId, pTrainedActionsOut)
		End Function

		Public Shared Function EE_ExpressivGetTrainedSignatureAvailable(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pfAvailableOut As Integer) As Integer
			Return Unmanged_EE_ExpressivGetTrainedSignatureAvailable(userId, pfAvailableOut)
		End Function

		Public Shared Function EE_ExpressivGetTrainingAction(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pActionOut As EE_ExpressivAlgo_t) As Integer
			Return Unmanged_EE_ExpressivGetTrainingAction(userId, pActionOut)
		End Function

		Public Shared Function EE_ExpressivGetTrainingTime(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pTrainingTimeOut As UInteger) As Integer
			Return Unmanged_EE_ExpressivGetTrainingTime(userId, pTrainingTimeOut)
		End Function

		Public Shared Function EE_ExpressivSetSignatureType(ByVal userId As UInteger, ByVal sigType As EE_ExpressivSignature_t) As Integer
			Return Unmanged_EE_ExpressivSetSignatureType(userId, sigType)
		End Function

		Public Shared Function EE_ExpressivSetThreshold(ByVal userId As UInteger, ByVal algoName As EE_ExpressivAlgo_t, ByVal thresholdName As EE_ExpressivThreshold_t, ByVal value As Integer) As Integer
			Return Unmanged_EE_ExpressivSetThreshold(userId, algoName, thresholdName, value)
		End Function

		Public Shared Function EE_ExpressivSetTrainingAction(ByVal userId As UInteger, ByVal action As EE_ExpressivAlgo_t) As Integer
			Return Unmanged_EE_ExpressivSetTrainingAction(userId, action)
		End Function

		Public Shared Function EE_ExpressivSetTrainingControl(ByVal userId As UInteger, ByVal control As EE_ExpressivTrainingControl_t) As Integer
			Return Unmanged_EE_ExpressivSetTrainingControl(userId, control)
		End Function

		Public Shared Function EE_GetBaseProfile(ByVal hEvent As IntPtr) As Integer
			Return Unmanged_EE_GetBaseProfile(hEvent)
		End Function

		Public Shared Function EE_GetUserProfile(ByVal userId As UInteger, ByVal hEvent As IntPtr) As Integer
			Return Unmanged_EE_GetUserProfile(userId, hEvent)
		End Function

		Public Shared Function EE_GetUserProfileBytes(ByVal hEvt As IntPtr, ByVal destBuffer() As Byte, ByVal length As UInteger) As Integer
			Return Unmanged_EE_GetUserProfileBytes(hEvt, destBuffer, length)
		End Function

		Public Shared Function EE_GetUserProfileSize(ByVal hEvt As IntPtr, <System.Runtime.InteropServices.Out()> ByRef pProfileSizeOut As UInteger) As Integer
			Return Unmanged_EE_GetUserProfileSize(hEvt, pProfileSizeOut)
		End Function

		Public Shared Function EE_HardwareGetVersion(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pHwVersionOut As UInteger) As Integer
			Return Unmanged_EE_HardwareGetVersion(userId, pHwVersionOut)
		End Function

		Public Shared Function EE_HeadsetGetGyroDelta(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pXOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pYOut As Integer) As Integer
			Return Unmanged_EE_HeadsetGetGyroDelta(userId, pXOut, pYOut)
		End Function

		Public Shared Function EE_HeadsetGetSensorDetails(ByVal channelId As EE_InputChannels_t, <System.Runtime.InteropServices.Out()> ByRef pDescriptorOut As InputSensorDescriptor_t) As Integer
			Return Unmanged_EE_HeadsetGetSensorDetails(channelId, pDescriptorOut)
		End Function

		Public Shared Function EE_HeadsetGyroRezero(ByVal userId As UInteger) As Integer
			Return Unmanged_EE_HeadsetGyroRezero(userId)
		End Function

		Public Shared Function EE_LoadUserProfile(ByVal userID As UInteger, ByVal szInputFilename As String) As Integer
			Return Unmanged_EE_LoadUserProfile(userID, szInputFilename)
		End Function

		Public Shared Function EE_OptimizationDisable() As Integer
			Return Unmanged_EE_OptimizationDisable()
		End Function

		Public Shared Function EE_OptimizationEnable(ByVal hParam As IntPtr) As Integer
			Return Unmanged_EE_OptimizationEnable(hParam)
		End Function

		Public Shared Function EE_OptimizationGetParam(ByVal hParam As IntPtr) As Integer
			Return Unmanged_EE_OptimizationGetParam(hParam)
		End Function

		Public Shared Function EE_OptimizationGetVitalAlgorithm(ByVal hParam As IntPtr, ByVal suite As EE_EmotivSuite_t, <System.Runtime.InteropServices.Out()> ByRef pVitalAlgorithmBitVectorOut As UInteger) As Integer
			Return Unmanged_EE_OptimizationGetVitalAlgorithm(hParam, suite, pVitalAlgorithmBitVectorOut)
		End Function

		Public Shared Function EE_OptimizationIsEnabled(<System.Runtime.InteropServices.Out()> ByRef pEnabledOut As Boolean) As Integer
			Return Unmanged_EE_OptimizationIsEnabled(pEnabledOut)
		End Function

		Public Shared Function EE_OptimizationParamCreate() As IntPtr
			Return Unmanged_EE_OptimizationParamCreate()
		End Function

		Public Shared Sub EE_OptimizationParamFree(ByVal hParam As IntPtr)
			Unmanged_EE_OptimizationParamFree(hParam)
		End Sub

		Public Shared Function EE_OptimizationSetVitalAlgorithm(ByVal hParam As IntPtr, ByVal suite As EE_EmotivSuite_t, ByVal vitalAlgorithmBitVector As UInteger) As Integer
			Return Unmanged_EE_OptimizationSetVitalAlgorithm(hParam, suite, vitalAlgorithmBitVector)
		End Function

		Public Shared Function EE_ProfileEventCreate() As IntPtr
			Return Unmanged_EE_ProfileEventCreate()
		End Function

		Public Shared Function EE_ResetDetection(ByVal userId As UInteger, ByVal suite As EE_EmotivSuite_t, ByVal detectionBitVector As UInteger) As Integer
			Return Unmanged_EE_ResetDetection(userId, suite, detectionBitVector)
		End Function

		Public Shared Function EE_SaveUserProfile(ByVal userID As UInteger, ByVal szOutputFilename As String) As Integer
			Return Unmanged_EE_SaveUserProfile(userID, szOutputFilename)
		End Function

		Public Shared Function EE_SetHardwarePlayerDisplay(ByVal userId As UInteger, ByVal playerNum As UInteger) As Integer
			Return Unmanged_EE_SetHardwarePlayerDisplay(userId, playerNum)
		End Function

		Public Shared Function EE_SetUserProfile(ByVal userId As UInteger, ByVal profileBuffer() As Byte, ByVal length As UInteger) As Integer
			Return Unmanged_EE_SetUserProfile(userId, profileBuffer, length)
		End Function

		Public Shared Function EE_SoftwareGetVersion(ByVal pszVersionOut As StringBuilder, ByVal nVersionChars As UInteger, <System.Runtime.InteropServices.Out()> ByRef pBuildNumOut As UInteger) As Integer
			Return Unmanged_EE_SoftwareGetVersion(pszVersionOut, nVersionChars, pBuildNumOut)
		End Function

		Public Shared Function ES_AffectivEqual(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
			Return Unmanaged_ES_AffectivEqual(a, b)
		End Function

		Public Shared Function ES_AffectivGetEngagementBoredomScore(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_AffectivGetEngagementBoredomScore(state)
		End Function

		Public Shared Function ES_AffectivGetExcitementLongTermScore(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_AffectivGetExcitementLongTermScore(state)
		End Function

		Public Shared Function ES_AffectivGetExcitementShortTermScore(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_AffectivGetExcitementShortTermScore(state)
		End Function

		Public Shared Function ES_AffectivGetFrustrationScore(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_AffectivGetFrustrationScore(state)
		End Function

		Public Shared Function ES_AffectivGetMeditationScore(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_AffectivGetMeditationScore(state)
		End Function

		Public Shared Function ES_AffectivIsActive(ByVal state As IntPtr, ByVal type As EE_AffectivAlgo_t) As Boolean
			Return Unmanaged_ES_AffectivIsActive(state, type)
		End Function

		Public Shared Function ES_CognitivEqual(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
			Return Unmanaged_ES_CognitivEqual(a, b)
		End Function

		Public Shared Function ES_CognitivGetCurrentAction(ByVal state As IntPtr) As EE_CognitivAction_t
			Return Unmanaged_ES_CognitivGetCurrentAction(state)
		End Function

		Public Shared Function ES_CognitivGetCurrentActionPower(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_CognitivGetCurrentActionPower(state)
		End Function

		Public Shared Function ES_CognitivGetCurrentLevelRating(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_CognitivGetCurrentLevelRating(state)
		End Function

		Public Shared Function ES_CognitivIsActive(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_CognitivIsActive(state)
		End Function

		Public Shared Sub ES_Copy(ByVal a As IntPtr, ByVal b As IntPtr)
			Unmanaged_ES_Copy(a, b)
		End Sub

		Public Shared Function ES_Create() As IntPtr
			Return Unmanaged_ES_Create()
		End Function

		Public Shared Function ES_EmoEngineEqual(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
			Return Unmanaged_ES_EmoEngineEqual(a, b)
		End Function

		Public Shared Function ES_Equal(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
			Return Unmanaged_ES_Equal(a, b)
		End Function

		Public Shared Function ES_ExpressivEqual(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivEqual(a, b)
		End Function

		Public Shared Function ES_ExpressivGetClenchExtent(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_ExpressivGetClenchExtent(state)
		End Function

		Public Shared Function ES_ExpressivGetEyebrowExtent(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_ExpressivGetEyebrowExtent(state)
		End Function

		Public Shared Sub ES_ExpressivGetEyelidState(ByVal state As IntPtr, <System.Runtime.InteropServices.Out()> ByRef leftEye As Single, <System.Runtime.InteropServices.Out()> ByRef rightEye As Single)
			Unmanaged_ES_ExpressivGetEyelidState(state, leftEye, rightEye)
		End Sub

		Public Shared Sub ES_ExpressivGetEyeLocation(ByVal state As IntPtr, <System.Runtime.InteropServices.Out()> ByRef x As Single, <System.Runtime.InteropServices.Out()> ByRef y As Single)
			Unmanaged_ES_ExpressivGetEyeLocation(state, x, y)
		End Sub

		Public Shared Function ES_ExpressivGetLowerFaceAction(ByVal state As IntPtr) As EE_ExpressivAlgo_t
			Return Unmanaged_ES_ExpressivGetLowerFaceAction(state)
		End Function

		Public Shared Function ES_ExpressivGetLowerFaceActionPower(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_ExpressivGetLowerFaceActionPower(state)
		End Function

		Public Shared Function ES_ExpressivGetSmileExtent(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_ExpressivGetSmileExtent(state)
		End Function

		Public Shared Function ES_ExpressivGetUpperFaceAction(ByVal state As IntPtr) As EE_ExpressivAlgo_t
			Return Unmanaged_ES_ExpressivGetUpperFaceAction(state)
		End Function

		Public Shared Function ES_ExpressivGetUpperFaceActionPower(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_ExpressivGetUpperFaceActionPower(state)
		End Function

		Public Shared Function ES_ExpressivIsActive(ByVal state As IntPtr, ByVal type As EE_ExpressivAlgo_t) As Boolean
			Return Unmanaged_ES_ExpressivIsActive(state, type)
		End Function

		Public Shared Function ES_ExpressivIsBlink(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivIsBlink(state)
		End Function

		Public Shared Function ES_ExpressivIsEyesOpen(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivIsEyesOpen(state)
		End Function

		Public Shared Function ES_ExpressivIsLeftWink(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivIsLeftWink(state)
		End Function

		Public Shared Function ES_ExpressivIsLookingDown(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivIsLookingDown(state)
		End Function

		Public Shared Function ES_ExpressivIsLookingLeft(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivIsLookingLeft(state)
		End Function

		Public Shared Function ES_ExpressivIsLookingRight(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivIsLookingRight(state)
		End Function

		Public Shared Function ES_ExpressivIsLookingUp(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivIsLookingUp(state)
		End Function

		Public Shared Function ES_ExpressivIsRightWink(ByVal state As IntPtr) As Boolean
			Return Unmanaged_ES_ExpressivIsRightWink(state)
		End Function

		Public Shared Sub ES_Free(ByVal state As IntPtr)
			Unmanaged_ES_Free(state)
		End Sub

		Public Shared Sub ES_GetBatteryChargeLevel(ByVal state As IntPtr, <System.Runtime.InteropServices.Out()> ByRef chargeLevel As Integer, <System.Runtime.InteropServices.Out()> ByRef maxChargeLevel As Integer)
			Unmanaged_ES_GetBatteryChargeLevel(state, chargeLevel, maxChargeLevel)
		End Sub

		Public Shared Function ES_GetContactQuality(ByVal state As IntPtr, ByVal electroIdx As Integer) As EE_EEG_ContactQuality_t
			Return Unmanaged_ES_GetContactQuality(state, electroIdx)
		End Function

		Public Shared Function ES_GetContactQualityFromAllChannels(ByVal state As IntPtr, <System.Runtime.InteropServices.Out()> ByRef contactQuality() As EE_EEG_ContactQuality_t) As Integer
			Dim num As Integer = ES_GetNumContactQualityChannels(state)
			contactQuality = New EE_EEG_ContactQuality_t(num - 1){}
			Return Unmanaged_ES_GetContactQualityFromAllChannels(state, contactQuality, CUInt(contactQuality.Length))
		End Function

		Public Shared Function ES_GetHeadsetOn(ByVal state As IntPtr) As Integer
			Return Unmanaged_ES_GetHeadsetOn(state)
		End Function

		Public Shared Function ES_GetNumContactQualityChannels(ByVal state As IntPtr) As Integer
			Return Unmanaged_ES_GetNumContactQualityChannels(state)
		End Function

		Public Shared Function ES_GetTimeFromStart(ByVal state As IntPtr) As Single
			Return Unmanaged_ES_GetTimeFromStart(state)
		End Function

		Public Shared Function ES_GetWirelessSignalStatus(ByVal state As IntPtr) As EE_SignalStrength_t
			Return Unmanaged_ES_GetWirelessSignalStatus(state)
		End Function

		Public Shared Sub ES_Init(ByVal state As IntPtr)
			Unmanaged_ES_Init(state)
		End Sub

        <DllImport("edk.dll", EntryPoint:="EE_DataAcquisitionEnable")> _
        Private Shared Function Unmanaged_EE_DataAcquisitionEnable(ByVal userId As UInteger, ByVal enable As Boolean) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataAcquisitionIsEnabled")> _
        Private Shared Function Unmanaged_EE_DataAcquisitionIsEnabled(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pEnableOut As Boolean) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataCreate")> _
        Private Shared Function Unmanaged_EE_DataCreate() As IntPtr
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataFree")> _
        Private Shared Sub Unmanaged_EE_DataFree(ByVal hData As IntPtr)
        End Sub
        <DllImport("edk.dll", EntryPoint:="EE_DataGet")> _
        Private Shared Function Unmanaged_EE_DataGet(ByVal hData As IntPtr, ByVal channel As EE_DataChannel_t, ByVal buffer() As Double, ByVal bufferSizeInSample As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataGetBufferSizeInSec")> _
        Private Shared Function Unmanaged_EE_DataGetBufferSizeInSec(<System.Runtime.InteropServices.Out()> ByRef pBufferSizeInSecOut As Single) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataGetNumberOfSample")> _
        Private Shared Function Unmanaged_EE_DataGetNumberOfSample(ByVal hData As IntPtr, <System.Runtime.InteropServices.Out()> ByRef nSampleOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataGetSamplingRate")> _
        Private Shared Function Unmanaged_EE_DataGetSamplingRate(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pSamplingRate As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataSetBufferSizeInSec")> _
        Private Shared Function Unmanaged_EE_DataSetBufferSizeInSec(ByVal bufferSizeInSec As Single) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataSetMarker")> _
        Private Shared Function Unmanaged_EE_DataSetMarker(ByVal userId As UInteger, ByVal marker As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataSetSychronizationSignal")> _
        Private Shared Function Unmanaged_EE_DataSetSychronizationSignal(ByVal userId As UInteger, ByVal signal As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_DataUpdateHandle")> _
        Private Shared Function Unmanaged_EE_DataUpdateHandle(ByVal userId As UInteger, ByVal hData As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_AffectivEqual")> _
        Private Shared Function Unmanaged_ES_AffectivEqual(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_AffectivGetEngagementBoredomScore")> _
        Private Shared Function Unmanaged_ES_AffectivGetEngagementBoredomScore(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_AffectivGetExcitementLongTermScore")> _
        Private Shared Function Unmanaged_ES_AffectivGetExcitementLongTermScore(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_AffectivGetExcitementShortTermScore")> _
        Private Shared Function Unmanaged_ES_AffectivGetExcitementShortTermScore(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_AffectivGetFrustrationScore")> _
        Private Shared Function Unmanaged_ES_AffectivGetFrustrationScore(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_AffectivGetMeditationScore")> _
        Private Shared Function Unmanaged_ES_AffectivGetMeditationScore(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_AffectivIsActive")> _
        Private Shared Function Unmanaged_ES_AffectivIsActive(ByVal state As IntPtr, ByVal type As EE_AffectivAlgo_t) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_CognitivEqual")> _
        Private Shared Function Unmanaged_ES_CognitivEqual(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_CognitivGetCurrentAction")> _
        Private Shared Function Unmanaged_ES_CognitivGetCurrentAction(ByVal state As IntPtr) As EE_CognitivAction_t
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_CognitivGetCurrentActionPower")> _
        Private Shared Function Unmanaged_ES_CognitivGetCurrentActionPower(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_CognitivGetCurrentLevelRating")> _
        Private Shared Function Unmanaged_ES_CognitivGetCurrentLevelRating(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_CognitivIsActive")> _
        Private Shared Function Unmanaged_ES_CognitivIsActive(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_Copy")> _
        Private Shared Sub Unmanaged_ES_Copy(ByVal a As IntPtr, ByVal b As IntPtr)
        End Sub
        <DllImport("edk.dll", EntryPoint:="ES_Create")> _
        Private Shared Function Unmanaged_ES_Create() As IntPtr
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_EmoEngineEqual")> _
        Private Shared Function Unmanaged_ES_EmoEngineEqual(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_Equal")> _
        Private Shared Function Unmanaged_ES_Equal(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivEqual")> _
        Private Shared Function Unmanaged_ES_ExpressivEqual(ByVal a As IntPtr, ByVal b As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetClenchExtent")> _
        Private Shared Function Unmanaged_ES_ExpressivGetClenchExtent(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetEyebrowExtent")> _
        Private Shared Function Unmanaged_ES_ExpressivGetEyebrowExtent(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetEyelidState")> _
        Private Shared Sub Unmanaged_ES_ExpressivGetEyelidState(ByVal state As IntPtr, <System.Runtime.InteropServices.Out()> ByRef leftEye As Single, <System.Runtime.InteropServices.Out()> ByRef rightEye As Single)
        End Sub
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetEyeLocation")> _
        Private Shared Sub Unmanaged_ES_ExpressivGetEyeLocation(ByVal state As IntPtr, <System.Runtime.InteropServices.Out()> ByRef x As Single, <System.Runtime.InteropServices.Out()> ByRef y As Single)
        End Sub
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetLowerFaceAction")> _
        Private Shared Function Unmanaged_ES_ExpressivGetLowerFaceAction(ByVal state As IntPtr) As EE_ExpressivAlgo_t
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetLowerFaceActionPower")> _
        Private Shared Function Unmanaged_ES_ExpressivGetLowerFaceActionPower(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetSmileExtent")> _
        Private Shared Function Unmanaged_ES_ExpressivGetSmileExtent(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetUpperFaceAction")> _
        Private Shared Function Unmanaged_ES_ExpressivGetUpperFaceAction(ByVal state As IntPtr) As EE_ExpressivAlgo_t
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivGetUpperFaceActionPower")> _
        Private Shared Function Unmanaged_ES_ExpressivGetUpperFaceActionPower(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsActive")> _
        Private Shared Function Unmanaged_ES_ExpressivIsActive(ByVal state As IntPtr, ByVal type As EE_ExpressivAlgo_t) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsBlink")> _
        Private Shared Function Unmanaged_ES_ExpressivIsBlink(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsEyesOpen")> _
        Private Shared Function Unmanaged_ES_ExpressivIsEyesOpen(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsLeftWink")> _
        Private Shared Function Unmanaged_ES_ExpressivIsLeftWink(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsLookingDown")> _
        Private Shared Function Unmanaged_ES_ExpressivIsLookingDown(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsLookingLeft")> _
        Private Shared Function Unmanaged_ES_ExpressivIsLookingLeft(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsLookingRight")> _
        Private Shared Function Unmanaged_ES_ExpressivIsLookingRight(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsLookingUp")> _
        Private Shared Function Unmanaged_ES_ExpressivIsLookingUp(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_ExpressivIsRightWink")> _
        Private Shared Function Unmanaged_ES_ExpressivIsRightWink(ByVal state As IntPtr) As Boolean
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_Free")> _
        Private Shared Sub Unmanaged_ES_Free(ByVal state As IntPtr)
        End Sub
        <DllImport("edk.dll", EntryPoint:="ES_GetBatteryChargeLevel")> _
        Private Shared Sub Unmanaged_ES_GetBatteryChargeLevel(ByVal state As IntPtr, <System.Runtime.InteropServices.Out()> ByRef chargeLevel As Integer, <System.Runtime.InteropServices.Out()> ByRef maxChargeLevel As Integer)
        End Sub
        <DllImport("edk.dll", EntryPoint:="ES_GetContactQuality")> _
        Private Shared Function Unmanaged_ES_GetContactQuality(ByVal state As IntPtr, ByVal electroIdx As Integer) As EE_EEG_ContactQuality_t
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_GetContactQualityFromAllChannels")> _
        Private Shared Function Unmanaged_ES_GetContactQualityFromAllChannels(ByVal state As IntPtr, ByVal contactQuality() As EE_EEG_ContactQuality_t, ByVal numChannels As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_GetHeadsetOn")> _
        Private Shared Function Unmanaged_ES_GetHeadsetOn(ByVal state As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_GetNumContactQualityChannels")> _
        Private Shared Function Unmanaged_ES_GetNumContactQualityChannels(ByVal state As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_GetTimeFromStart")> _
        Private Shared Function Unmanaged_ES_GetTimeFromStart(ByVal state As IntPtr) As Single
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_GetWirelessSignalStatus")> _
        Private Shared Function Unmanaged_ES_GetWirelessSignalStatus(ByVal state As IntPtr) As EE_SignalStrength_t
        End Function
        <DllImport("edk.dll", EntryPoint:="ES_Init")> _
        Private Shared Sub Unmanaged_ES_Init(ByVal state As IntPtr)
        End Sub
        <DllImport("edk.dll", EntryPoint:="EE_CognitivEventGetType")> _
        Private Shared Function Unmanged_EE_CognitivEventGetType(ByVal hEvent As IntPtr) As EE_CognitivEvent_t
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetActionSensitivity")> _
        Private Shared Function Unmanged_EE_CognitivGetActionSensitivity(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pAction1SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction2SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction3SensitivityOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pAction4SensitivityOut As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetActionSkillRating")> _
        Private Shared Function Unmanged_EE_CognitivGetActionSkillRating(ByVal userId As UInteger, ByVal action As EE_CognitivAction_t, <System.Runtime.InteropServices.Out()> ByRef pActionSkillRatingOut As Single) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetActivationLevel")> _
        Private Shared Function Unmanged_EE_CognitivGetActivationLevel(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pLevelOut As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetActiveActions")> _
        Private Shared Function Unmanged_EE_CognitivGetActiveActions(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pActiveActionsOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetOverallSkillRating")> _
        Private Shared Function Unmanged_EE_CognitivGetOverallSkillRating(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pOverallSkillRatingOut As Single) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetSignatureCacheSize")> _
        Private Shared Function Unmanged_EE_CognitivGetSignatureCacheSize(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pSizeOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetSignatureCaching")> _
        Private Shared Function Unmanged_EE_CognitivGetSignatureCaching(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pEnabledOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetTrainedSignatureActions")> _
        Private Shared Function Unmanged_EE_CognitivGetTrainedSignatureActions(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pTrainedActionsOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetTrainingAction")> _
        Private Shared Function Unmanged_EE_CognitivGetTrainingAction(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pActionOut As EE_CognitivAction_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivGetTrainingTime")> _
        Private Shared Function Unmanged_EE_CognitivGetTrainingTime(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pTrainingTimeOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivSetActionSensitivity")> _
        Private Shared Function Unmanged_EE_CognitivSetActionSensitivity(ByVal userId As UInteger, ByVal action1Sensitivity As Integer, ByVal action2Sensitivity As Integer, ByVal action3Sensitivity As Integer, ByVal action4Sensitivity As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivSetActivationLevel")> _
        Private Shared Function Unmanged_EE_CognitivSetActivationLevel(ByVal userId As UInteger, ByVal level As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivSetActiveActions")> _
        Private Shared Function Unmanged_EE_CognitivSetActiveActions(ByVal userId As UInteger, ByVal activeActions As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivSetSignatureCacheSize")> _
        Private Shared Function Unmanged_EE_CognitivSetSignatureCacheSize(ByVal userId As UInteger, ByVal size As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivSetSignatureCaching")> _
        Private Shared Function Unmanged_EE_CognitivSetSignatureCaching(ByVal userId As UInteger, ByVal enabled As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivSetTrainingAction")> _
        Private Shared Function Unmanged_EE_CognitivSetTrainingAction(ByVal userId As UInteger, ByVal action As EE_CognitivAction_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivSetTrainingControl")> _
        Private Shared Function Unmanged_EE_CognitivSetTrainingControl(ByVal userId As UInteger, ByVal control As EE_CognitivTrainingControl_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivStartSamplingNeutral")> _
        Private Shared Function Unmanged_EE_CognitivStartSamplingNeutral(ByVal userId As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_CognitivStopSamplingNeutral")> _
        Private Shared Function Unmanged_EE_CognitivStopSamplingNeutral(ByVal userId As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EmoEngineEventCreate")> _
        Private Shared Function Unmanged_EE_EmoEngineEventCreate() As IntPtr
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EmoEngineEventFree")> _
        Private Shared Sub Unmanged_EE_EmoEngineEventFree(ByVal hEvent As IntPtr)
        End Sub
        <DllImport("edk.dll", EntryPoint:="EE_EmoEngineEventGetEmoState")> _
        Private Shared Function Unmanged_EE_EmoEngineEventGetEmoState(ByVal hEvent As IntPtr, ByVal hEmoState As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EmoEngineEventGetType")> _
        Private Shared Function Unmanged_EE_EmoEngineEventGetType(ByVal hEvent As IntPtr) As EE_Event_t
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EmoEngineEventGetUserId")> _
        Private Shared Function Unmanged_EE_EmoEngineEventGetUserId(ByVal hEvent As IntPtr, <System.Runtime.InteropServices.Out()> ByRef pUserIdOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EmoStateCreate")> _
        Private Shared Function Unmanged_EE_EmoStateCreate() As IntPtr
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EmoStateFree")> _
        Private Shared Sub Unmanged_EE_EmoStateFree(ByVal hState As IntPtr)
        End Sub
        <DllImport("edk.dll", EntryPoint:="EE_EnableDiagnostics")> _
        Private Shared Function Unmanged_EE_EnableDiagnostics(ByVal szFilename As String, ByVal fEnable As Integer, ByVal nReserved As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EngineClearEventQueue")> _
        Private Shared Function Unmanged_EE_EngineClearEventQueue(ByVal eventTypes As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EngineConnect")> _
        Private Shared Function Unmanged_EE_EngineConnect() As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EngineDisconnect")> _
        Private Shared Function Unmanged_EE_EngineDisconnect() As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EngineGetNextEvent")> _
        Private Shared Function Unmanged_EE_EngineGetNextEvent(ByVal hEvent As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EngineGetNumUser")> _
        Private Shared Function Unmanged_EE_EngineGetNumUser(<System.Runtime.InteropServices.Out()> ByRef pNumUserOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_EngineRemoteConnect")> _
        Private Shared Function Unmanged_EE_EngineRemoteConnect(ByVal szHost As String, ByVal port As UShort) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivEventGetType")> _
        Private Shared Function Unmanged_EE_ExpressivEventGetType(ByVal hEvent As IntPtr) As EE_ExpressivEvent_t
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivGetSignatureType")> _
        Private Shared Function Unmanged_EE_ExpressivGetSignatureType(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pSigTypeOut As EE_ExpressivSignature_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivGetThreshold")> _
        Private Shared Function Unmanged_EE_ExpressivGetThreshold(ByVal userId As UInteger, ByVal algoName As EE_ExpressivAlgo_t, ByVal thresholdName As EE_ExpressivThreshold_t, <System.Runtime.InteropServices.Out()> ByRef pValueOut As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivGetTrainedSignatureActions")> _
        Private Shared Function Unmanged_EE_ExpressivGetTrainedSignatureActions(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pTrainedActionsOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivGetTrainedSignatureAvailable")> _
        Private Shared Function Unmanged_EE_ExpressivGetTrainedSignatureAvailable(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pfAvailableOut As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivGetTrainingAction")> _
        Private Shared Function Unmanged_EE_ExpressivGetTrainingAction(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pActionOut As EE_ExpressivAlgo_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivGetTrainingTime")> _
        Private Shared Function Unmanged_EE_ExpressivGetTrainingTime(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pTrainingTimeOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivSetSignatureType")> _
        Private Shared Function Unmanged_EE_ExpressivSetSignatureType(ByVal userId As UInteger, ByVal sigType As EE_ExpressivSignature_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivSetThreshold")> _
        Private Shared Function Unmanged_EE_ExpressivSetThreshold(ByVal userId As UInteger, ByVal algoName As EE_ExpressivAlgo_t, ByVal thresholdName As EE_ExpressivThreshold_t, ByVal value As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivSetTrainingAction")> _
        Private Shared Function Unmanged_EE_ExpressivSetTrainingAction(ByVal userId As UInteger, ByVal action As EE_ExpressivAlgo_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ExpressivSetTrainingControl")> _
        Private Shared Function Unmanged_EE_ExpressivSetTrainingControl(ByVal userId As UInteger, ByVal control As EE_ExpressivTrainingControl_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_GetBaseProfile")> _
        Private Shared Function Unmanged_EE_GetBaseProfile(ByVal hEvent As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_GetUserProfile")> _
        Private Shared Function Unmanged_EE_GetUserProfile(ByVal userId As UInteger, ByVal hEvent As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_GetUserProfileBytes")> _
        Private Shared Function Unmanged_EE_GetUserProfileBytes(ByVal hEvt As IntPtr, ByVal destBuffer() As Byte, ByVal length As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_GetUserProfileSize")> _
        Private Shared Function Unmanged_EE_GetUserProfileSize(ByVal hEvt As IntPtr, <System.Runtime.InteropServices.Out()> ByRef pProfileSizeOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_HardwareGetVersion")> _
        Private Shared Function Unmanged_EE_HardwareGetVersion(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pHwVersionOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_HeadsetGetGyroDelta")> _
        Private Shared Function Unmanged_EE_HeadsetGetGyroDelta(ByVal userId As UInteger, <System.Runtime.InteropServices.Out()> ByRef pXOut As Integer, <System.Runtime.InteropServices.Out()> ByRef pYOut As Integer) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_HeadsetGetSensorDetails")> _
        Private Shared Function Unmanged_EE_HeadsetGetSensorDetails(ByVal channelId As EE_InputChannels_t, <System.Runtime.InteropServices.Out()> ByRef pDescriptorOut As InputSensorDescriptor_t) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_HeadsetGyroRezero")> _
        Private Shared Function Unmanged_EE_HeadsetGyroRezero(ByVal userId As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_LoadUserProfile")> _
        Private Shared Function Unmanged_EE_LoadUserProfile(ByVal userID As UInteger, ByVal szInputFilename As String) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_OptimizationDisable")> _
        Private Shared Function Unmanged_EE_OptimizationDisable() As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_OptimizationEnable")> _
        Private Shared Function Unmanged_EE_OptimizationEnable(ByVal hParam As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_OptimizationGetParam")> _
        Private Shared Function Unmanged_EE_OptimizationGetParam(ByVal hParam As IntPtr) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_OptimizationGetVitalAlgorithm")> _
        Private Shared Function Unmanged_EE_OptimizationGetVitalAlgorithm(ByVal hParam As IntPtr, ByVal suite As EE_EmotivSuite_t, <System.Runtime.InteropServices.Out()> ByRef pVitalAlgorithmBitVectorOut As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_OptimizationIsEnabled")> _
        Private Shared Function Unmanged_EE_OptimizationIsEnabled(<System.Runtime.InteropServices.Out()> ByRef pEnabledOut As Boolean) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_OptimizationParamCreate")> _
        Private Shared Function Unmanged_EE_OptimizationParamCreate() As IntPtr
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_OptimizationParamFree")> _
        Private Shared Sub Unmanged_EE_OptimizationParamFree(ByVal hParam As IntPtr)
        End Sub
        <DllImport("edk.dll", EntryPoint:="EE_OptimizationSetVitalAlgorithm")> _
        Private Shared Function Unmanged_EE_OptimizationSetVitalAlgorithm(ByVal hParam As IntPtr, ByVal suite As EE_EmotivSuite_t, ByVal vitalAlgorithmBitVector As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ProfileEventCreate")> _
        Private Shared Function Unmanged_EE_ProfileEventCreate() As IntPtr
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_ResetDetection")> _
        Private Shared Function Unmanged_EE_ResetDetection(ByVal userId As UInteger, ByVal suite As EE_EmotivSuite_t, ByVal detectionBitVector As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_SaveUserProfile")> _
        Private Shared Function Unmanged_EE_SaveUserProfile(ByVal userID As UInteger, ByVal szOutputFilename As String) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_SetHardwarePlayerDisplay")> _
        Private Shared Function Unmanged_EE_SetHardwarePlayerDisplay(ByVal userId As UInteger, ByVal playerNum As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_SetUserProfile")> _
        Private Shared Function Unmanged_EE_SetUserProfile(ByVal userId As UInteger, ByVal profileBuffer() As Byte, ByVal length As UInteger) As Integer
        End Function
        <DllImport("edk.dll", EntryPoint:="EE_SoftwareGetVersion")> _
        Private Shared Function Unmanged_EE_SoftwareGetVersion(ByVal pszVersionOut As StringBuilder, ByVal nVersionChars As UInteger, <System.Runtime.InteropServices.Out()> ByRef pBuildNumOut As UInteger) As Integer
        End Function

		Public Enum EE_AffectivAlgo_t
			AFF_ENGAGEMENT_BOREDOM = 8
			AFF_EXCITEMENT = 1
			AFF_FRUSTRATION = 4
			AFF_MEDITATION = 2
		End Enum

		Public Enum EE_CognitivAction_t
			COG_DISAPPEAR = &H2000
			COG_DROP = &H10
			COG_LEFT = &H20
			COG_LIFT = 8
			COG_NEUTRAL = 1
			COG_PULL = 4
			COG_PUSH = 2
			COG_RIGHT = &H40
			COG_ROTATE_CLOCKWISE = &H200
			COG_ROTATE_COUNTER_CLOCKWISE = &H400
			COG_ROTATE_FORWARDS = &H800
			COG_ROTATE_LEFT = &H80
			COG_ROTATE_REVERSE = &H1000
			COG_ROTATE_RIGHT = &H100
		End Enum

		Public Enum EE_CognitivEvent_t
			EE_CognitivNoEvent
			EE_CognitivTrainingStarted
			EE_CognitivTrainingSucceeded
			EE_CognitivTrainingFailed
			EE_CognitivTrainingCompleted
			EE_CognitivTrainingDataErased
			EE_CognitivTrainingRejected
			EE_CognitivTrainingReset
			EE_CognitivAutoSamplingNeutralCompleted
			EE_CognitivSignatureUpdated
		End Enum

		Public Enum EE_CognitivTrainingControl_t
			COG_NONE
			COG_START
			COG_ACCEPT
			COG_REJECT
			COG_ERASE
			COG_RESET
		End Enum

		Public Enum EE_DataChannel_t
			COUNTER
			INTERPOLATED
			RAW_CQ
			AF3
			F7
			F3
			FC5
			T7
			P7
			O1
			O2
			P8
			T8
			FC6
			F4
			F8
			AF4
			GYROX
			GYROY
			TIMESTAMP
			ES_TIMESTAMP
			FUNC_ID
			FUNC_VALUE
			MARKER
			SYNC_SIGNAL
		End Enum

		Public Enum EE_EEG_ContactQuality_t
			EEG_CQ_NO_SIGNAL
			EEG_CQ_VERY_BAD
			EEG_CQ_POOR
			EEG_CQ_FAIR
			EEG_CQ_GOOD
		End Enum

		Public Enum EE_EmotivSuite_t
			EE_EXPRESSIV
			EE_AFFECTIV
			EE_COGNITIV
		End Enum

		Public Enum EE_Event_t
			EE_AllEvent = &H7f0
			EE_CognitivEvent = &H100
			EE_EmoStateUpdated = &H40
			EE_EmulatorError = 1
			EE_ExpressivEvent = &H200
			EE_InternalStateChanged = &H400
			EE_ProfileEvent = &H80
			EE_ReservedEvent = 2
			EE_UnknownEvent = 0
			EE_UserAdded = &H10
			EE_UserRemoved = &H20
		End Enum

		Public Enum EE_ExpressivAlgo_t
			EXP_BLINK = 2
			EXP_CLENCH = &H100
			EXP_EYEBROW = &H20
			EXP_FURROW = &H40
			EXP_HORIEYE = &H10
			EXP_LAUGH = &H200
			EXP_NEUTRAL = 1
			EXP_SMILE = &H80
			EXP_SMIRK_LEFT = &H400
			EXP_SMIRK_RIGHT = &H800
			EXP_WINK_LEFT = 4
			EXP_WINK_RIGHT = 8
		End Enum

		Public Enum EE_ExpressivEvent_t
			EE_ExpressivNoEvent
			EE_ExpressivTrainingStarted
			EE_ExpressivTrainingSucceeded
			EE_ExpressivTrainingFailed
			EE_ExpressivTrainingCompleted
			EE_ExpressivTrainingDataErased
			EE_ExpressivTrainingRejected
			EE_ExpressivTrainingReset
		End Enum

		Public Enum EE_ExpressivSignature_t
			EXP_SIG_UNIVERSAL
			EXP_SIG_TRAINED
		End Enum

		Public Enum EE_ExpressivThreshold_t
			EXP_SENSITIVITY
		End Enum

		Public Enum EE_ExpressivTrainingControl_t
			EXP_NONE
			EXP_START
			EXP_ACCEPT
			EXP_REJECT
			EXP_ERASE
			EXP_RESET
		End Enum

		Public Enum EE_InputChannels_t
			EE_CHAN_CMS
			EE_CHAN_DRL
			EE_CHAN_FP1
			EE_CHAN_AF3
			EE_CHAN_F7
			EE_CHAN_F3
			EE_CHAN_FC5
			EE_CHAN_T7
			EE_CHAN_P7
			EE_CHAN_O1
			EE_CHAN_O2
			EE_CHAN_P8
			EE_CHAN_T8
			EE_CHAN_FC6
			EE_CHAN_F4
			EE_CHAN_F8
			EE_CHAN_AF4
			EE_CHAN_FP2
		End Enum

		Public Enum EE_SignalStrength_t
			NO_SIGNAL
			BAD_SIGNAL
			GOOD_SIGNAL
		End Enum

        <StructLayout(LayoutKind.Sequential)> _
  Public Class InputSensorDescriptor_t
            Public channelId As EdkDll.EE_InputChannels_t
            Public fExists As Integer
            Public pszLabel As String
            Public xLoc As Double
            Public yLoc As Double
            Public zLoc As Double
        End Class
	End Class
End Namespace

