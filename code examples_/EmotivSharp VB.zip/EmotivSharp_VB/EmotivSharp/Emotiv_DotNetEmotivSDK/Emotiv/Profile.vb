﻿Namespace Emotiv

	Public Class Profile
		Private hProfile As IntPtr = EdkDll.EE_ProfileEventCreate()

		Public Sub New()
			EdkDll.EE_GetBaseProfile(Me.hProfile)
		End Sub

		Protected Overrides Sub Finalize()
			EdkDll.EE_EmoEngineEventFree(Me.hProfile)
		End Sub

		Public Function GetBytes() As Byte()
			Dim pProfileSizeOut As UInteger = 0
			EmoEngine.errorHandler(EdkDll.EE_GetUserProfileSize(Me.hProfile, pProfileSizeOut))
			Dim destBuffer(pProfileSizeOut - 1) As Byte
			EmoEngine.errorHandler(EdkDll.EE_GetUserProfileBytes(Me.hProfile, destBuffer, pProfileSizeOut))
			Return destBuffer
		End Function

		Public Function GetHandle() As IntPtr
			Return Me.hProfile
		End Function
	End Class
End Namespace

