﻿Namespace Emotiv

	Public Class OptimizationParam
		Private hOptimizationParam As IntPtr = EdkDll.EE_OptimizationParamCreate()

		Protected Overrides Sub Finalize()
			EdkDll.EE_OptimizationParamFree(Me.hOptimizationParam)
		End Sub

		Public Function GetHandle() As IntPtr
			Return Me.hOptimizationParam
		End Function

		Public Function GetVitalAlgorithm(ByVal suite As EdkDll.EE_EmotivSuite_t) As UInteger
			Dim pVitalAlgorithmBitVectorOut As UInteger = 0
			EmoEngine.errorHandler(EdkDll.EE_OptimizationGetVitalAlgorithm(Me.hOptimizationParam, suite, pVitalAlgorithmBitVectorOut))
			Return pVitalAlgorithmBitVectorOut
		End Function

		Public Sub SetVitalAlgorithm(ByVal suite As EdkDll.EE_EmotivSuite_t, ByVal vitalAlgorithmBitVector As UInteger)
			EmoEngine.errorHandler(EdkDll.EE_OptimizationSetVitalAlgorithm(Me.hOptimizationParam, suite, vitalAlgorithmBitVector))
		End Sub
	End Class
End Namespace

