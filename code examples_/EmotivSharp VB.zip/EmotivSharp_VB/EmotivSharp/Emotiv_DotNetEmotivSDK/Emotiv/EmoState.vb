﻿Imports System.Runtime.InteropServices

Namespace Emotiv

	Public Class EmoState
		Implements ICloneable
		Private hEmoState As IntPtr

		Public Sub New()
			Me.hEmoState = EdkDll.ES_Create()
		End Sub

		Public Sub New(ByVal es As EmoState)
			Me.hEmoState = EdkDll.ES_Create()
			EdkDll.ES_Copy(Me.hEmoState, es.GetHandle())
		End Sub

		Public Function AffectivEqual(ByVal state As EmoState) As Boolean
			Return EdkDll.ES_AffectivEqual(Me.GetHandle(), state.GetHandle())
		End Function

		Public Function AffectivGetEngagementBoredomScore() As Single
			Return EdkDll.ES_AffectivGetEngagementBoredomScore(Me.hEmoState)
		End Function

		Public Function AffectivGetExcitementLongTermScore() As Single
			Return EdkDll.ES_AffectivGetExcitementLongTermScore(Me.hEmoState)
		End Function

		Public Function AffectivGetExcitementShortTermScore() As Single
			Return EdkDll.ES_AffectivGetExcitementShortTermScore(Me.hEmoState)
		End Function

		Public Function AffectivGetFrustrationScore() As Single
			Return EdkDll.ES_AffectivGetFrustrationScore(Me.hEmoState)
		End Function

		Public Function AffectivGetMeditationScore() As Single
			Return EdkDll.ES_AffectivGetMeditationScore(Me.hEmoState)
		End Function

		Public Function AffectivIsActive(ByVal type As EdkDll.EE_AffectivAlgo_t) As Boolean
			Return EdkDll.ES_AffectivIsActive(Me.hEmoState, type)
		End Function

		Public Function Clone() As Object Implements ICloneable.Clone
			Return New EmoState(Me)
		End Function

		Public Function CognitivEqual(ByVal state As EmoState) As Boolean
			Return EdkDll.ES_CognitivEqual(Me.GetHandle(), state.GetHandle())
		End Function

		Public Function CognitivGetCurrentAction() As EdkDll.EE_CognitivAction_t
			Return EdkDll.ES_CognitivGetCurrentAction(Me.hEmoState)
		End Function

		Public Function CognitivGetCurrentActionPower() As Single
			Return EdkDll.ES_CognitivGetCurrentActionPower(Me.hEmoState)
		End Function

		Public Function CognitivIsActive() As Boolean
			Return EdkDll.ES_CognitivIsActive(Me.hEmoState)
		End Function

		Public Function EmoEngineEqual(ByVal state As EmoState) As Boolean
			Return EdkDll.ES_EmoEngineEqual(Me.GetHandle(), state.GetHandle())
		End Function

		Public Overloads Function Equals(ByVal a As EmoState, ByVal b As EmoState) As Boolean
			Return EdkDll.ES_Equal(a.GetHandle(), b.GetHandle())
		End Function

		Public Function ExpressivEqual(ByVal state As EmoState) As Boolean
			Return EdkDll.ES_ExpressivEqual(Me.GetHandle(), state.GetHandle())
		End Function

		Public Function ExpressivGetClenchExtent() As Single
			Return EdkDll.ES_ExpressivGetClenchExtent(Me.hEmoState)
		End Function

		Public Function ExpressivGetEyebrowExtent() As Single
			Return EdkDll.ES_ExpressivGetEyebrowExtent(Me.hEmoState)
		End Function

		Public Sub ExpressivGetEyelidState(<System.Runtime.InteropServices.Out()> ByRef leftEye As Single, <System.Runtime.InteropServices.Out()> ByRef rightEye As Single)
			EdkDll.ES_ExpressivGetEyelidState(Me.hEmoState, leftEye, rightEye)
		End Sub

		Public Sub ExpressivGetEyeLocation(<System.Runtime.InteropServices.Out()> ByRef x As Single, <System.Runtime.InteropServices.Out()> ByRef y As Single)
			EdkDll.ES_ExpressivGetEyeLocation(Me.hEmoState, x, y)
		End Sub

		Public Function ExpressivGetLowerFaceAction() As EdkDll.EE_ExpressivAlgo_t
			Return EdkDll.ES_ExpressivGetLowerFaceAction(Me.hEmoState)
		End Function

		Public Function ExpressivGetLowerFaceActionPower() As Single
			Return EdkDll.ES_ExpressivGetLowerFaceActionPower(Me.hEmoState)
		End Function

		Public Function ExpressivGetSmileExtent() As Single
			Return EdkDll.ES_ExpressivGetSmileExtent(Me.hEmoState)
		End Function

		Public Function ExpressivGetUpperFaceAction() As EdkDll.EE_ExpressivAlgo_t
			Return EdkDll.ES_ExpressivGetUpperFaceAction(Me.hEmoState)
		End Function

		Public Function ExpressivGetUpperFaceActionPower() As Single
			Return EdkDll.ES_ExpressivGetUpperFaceActionPower(Me.hEmoState)
		End Function

		Public Function ExpressivIsActive(ByVal type As EdkDll.EE_ExpressivAlgo_t) As Boolean
			Return EdkDll.ES_ExpressivIsActive(Me.hEmoState, type)
		End Function

		Public Function ExpressivIsBlink() As Boolean
			Return EdkDll.ES_ExpressivIsBlink(Me.hEmoState)
		End Function

		Public Function ExpressivIsEyesOpen() As Boolean
			Return EdkDll.ES_ExpressivIsEyesOpen(Me.hEmoState)
		End Function

		Public Function ExpressivIsLeftWink() As Boolean
			Return EdkDll.ES_ExpressivIsLeftWink(Me.hEmoState)
		End Function

		Public Function ExpressivIsLookingDown() As Boolean
			Return EdkDll.ES_ExpressivIsLookingDown(Me.hEmoState)
		End Function

		Public Function ExpressivIsLookingLeft() As Boolean
			Return EdkDll.ES_ExpressivIsLookingLeft(Me.hEmoState)
		End Function

		Public Function ExpressivIsLookingRight() As Boolean
			Return EdkDll.ES_ExpressivIsLookingRight(Me.hEmoState)
		End Function

		Public Function ExpressivIsLookingUp() As Boolean
			Return EdkDll.ES_ExpressivIsLookingUp(Me.hEmoState)
		End Function

		Public Function ExpressivIsRightWink() As Boolean
			Return EdkDll.ES_ExpressivIsRightWink(Me.hEmoState)
		End Function

		Protected Overrides Sub Finalize()
			EdkDll.ES_Free(Me.hEmoState)
		End Sub

		Public Sub GetBatteryChargeLevel(<System.Runtime.InteropServices.Out()> ByRef chargeLevel As Integer, <System.Runtime.InteropServices.Out()> ByRef maxChargeLevel As Integer)
			EdkDll.ES_GetBatteryChargeLevel(Me.hEmoState, chargeLevel, maxChargeLevel)
		End Sub

		Public Function GetContactQuality(ByVal electroIdx As Integer) As EdkDll.EE_EEG_ContactQuality_t
			Return EdkDll.ES_GetContactQuality(Me.hEmoState, electroIdx)
		End Function

		Public Function GetContactQualityFromAllChannels() As EdkDll.EE_EEG_ContactQuality_t()
			Dim _tArray() As EdkDll.EE_EEG_ContactQuality_t
			EdkDll.ES_GetContactQualityFromAllChannels(Me.hEmoState, _tArray)
			Return _tArray
		End Function

		Public Function GetHandle() As IntPtr
			Return Me.hEmoState
		End Function

		Public Function GetHeadsetOn() As Integer
			Return EdkDll.ES_GetHeadsetOn(Me.hEmoState)
		End Function

		Public Function GetNumContactQualityChannels() As Integer
			Return EdkDll.ES_GetNumContactQualityChannels(Me.hEmoState)
		End Function

		Public Function GetTimeFromStart() As Single
			Return EdkDll.ES_GetTimeFromStart(Me.hEmoState)
		End Function

		Public Function GetWirelessSignalStatus() As EdkDll.EE_SignalStrength_t
			Return EdkDll.ES_GetWirelessSignalStatus(Me.hEmoState)
		End Function
	End Class
End Namespace

