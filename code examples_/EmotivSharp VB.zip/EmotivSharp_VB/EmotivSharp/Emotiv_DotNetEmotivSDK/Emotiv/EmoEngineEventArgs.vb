﻿Namespace Emotiv

	Public Class EmoEngineEventArgs
		Inherits EventArgs
		Public userId As UInteger

		Public Sub New(ByVal userId As UInteger)
			Me.userId = userId
		End Sub
	End Class
End Namespace

