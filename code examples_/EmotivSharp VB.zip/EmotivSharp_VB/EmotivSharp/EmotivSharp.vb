﻿Imports System.Text

Namespace EmotivSharp
	Public Class EmotivPower
		Implements IDisposable
		#Region "vars"
		#Region "base"
		Public Event DIE As d1
		Public Event NewCognitivEvent As BaseData.d_CognitivEvent
		Public Event NewEmoState As BaseData.d_EmoState
		Public Event NewExpressivEvent As BaseData.d_ExpressivEvent
		Public Event NewFacialEvent As BaseData.d_FacialEvent
		Public Event NewAffectivEvent As BaseData.d_AffectivEvent
		Public Event NewHeadsetRawDataEvent As BaseData.d_HeadsetRawDataEvent
		Public Event NewHeadsetBaseEvent As BaseData.d_HeadsetBaseEvent
		Private IP As String = "127.0.0.1"
		Private PortFake As UShort = 1726
		Private PortReal As UShort = 3008

		Private InputThread As System.Threading.Thread

		Public Enum headsetConnectionType
			Real
			Fake
			AskUser
		End Enum
		#End Region ' ---base---

		Private m_EmoEnginEvent As IntPtr
		Private m_EmoState As IntPtr
		Private m_EmoEngine As Emotiv.EmoEngine
		Private headsetDataFound As Boolean = False
	   Public Delegate Sub d1()
		Private UserID As UInteger
		Public Sub UpdateUserID()
			Try
				' hold the spinning thread
				Semaphore_ThreadTakeInput.WaitOne()

				Dim UserID_Temp As UInteger
				Emotiv.EdkDll.EE_EmoEngineEventGetUserId(m_EmoEnginEvent, UserID_Temp)

				UserID = UserID_Temp

			Finally
				' restart spinning thread
				Semaphore_ThreadTakeInput.Release()
			End Try
		End Sub

		Public timeStamp As Single

		Public myRawData As HeadsetRawData
		Public myHeadsetBase As HeadsetBase
		Public myTraining As Training
		Public myCognitiv As Cognitiv
		Public myExpressiv As Expressiv
		Public myAffectiv As Affectiv
		Public myUser As User
		#End Region ' ---vars---
		#Region "ERROR_CODE"
		Public Enum ERROR_CODE_emun
			'! Default success value
			EDK_OK = &H0
			'! An internal error occurred
			EDK_UNKNOWN_ERROR = &H1

			'! The contents of the buffer supplied to EE_SetUserProfile aren't a valid, serialized EmoEngine profile.
			EDK_INVALID_PROFILE_ARCHIVE = &H101
			'! Returned from EE_EmoEngineEventGetUserId if the event supplied contains a base profile (which isn't associated with specific user).
			EDK_NO_USER_FOR_BASEPROFILE = &H102

			'! The EmoEngine is unable to acquire EEG data for processing.
			EDK_CANNOT_ACQUIRE_DATA = &H200

			'! The buffer supplied to the function isn't large enough
			EDK_BUFFER_TOO_SMALL = &H300
			'! A parameter supplied to the function is out of range
			EDK_OUT_OF_RANGE = &H301
			'! One of the parameters supplied to the function is invalid
			EDK_INVALID_PARAMETER = &H302
			'! The parameter value is currently locked by a running detection and cannot be modified at this time.
			EDK_PARAMETER_LOCKED = &H303
			'! The current training action is not in the list of expected training actions
			EDK_COG_INVALID_TRAINING_ACTION = &H304
			'! The current training control is not in the list of expected training controls
			EDK_COG_INVALID_TRAINING_CONTROL = &H305
			'! One of the field in the action bits vector is invalid
			EDK_COG_INVALID_ACTIVE_ACTION = &H306
			'! The current action bits vector contains more action types than it is allowed
			EDK_COG_EXCESS_MAX_ACTIONS = &H307
			'! A trained signature is not currently available for use - addition actions (including neutral) may be required
			EDK_EXP_NO_SIG_AVAILABLE = &H308
			'! A filesystem error occurred that prevented the function from succeeding
			EDK_FILESYSTEM_ERROR = &H309

			'! The user ID supplied to the function is invalid
			EDK_INVALID_USER_ID = &H400

			'! The EDK needs to be initialized via EE_EngineConnect or EE_EngineRemoteConnect
			EDK_EMOENGINE_UNINITIALIZED = &H500
			'! The connection with a remote instance of the EmoEngine (made via EE_EngineRemoteConnect) has been lost
			EDK_EMOENGINE_DISCONNECTED = &H501
			'! The API was unable to establish a connection with a remote instance of the EmoEngine.
			EDK_EMOENGINE_PROXY_ERROR = &H502

			'! There are no new EmoEngine events at this time
			EDK_NO_EVENT = &H600

			'! The gyro is not calibrated. Ask the user to stay still for at least 0.5s
			EDK_GYRO_NOT_CALIBRATED = &H700

			'! Operation failure due to optimization
			EDK_OPTIMIZATION_IS_ON = &H800

			'! Reserved return value
			EDK_RESERVED1 = &H900
		End Enum

		#End Region ' ---ERROR_CODE---
		#Region "Thread Sync stuff"
		Private Shared Semaphore_ThreadTakeInput As New System.Threading.Semaphore(1, 1)
		Private Shared Semaphore_ThreadTakeInput1 As New System.Threading.Semaphore(1, 1)
		Private Shared Semaphore_ThreadTakeInput2 As New System.Threading.Semaphore(1, 1)
		Private Shared Semaphore_ThreadTakeInput3 As New System.Threading.Semaphore(1, 1)
		Private Shared Semaphore_ThreadTakeInput4 As New System.Threading.Semaphore(1, 1)

		Private callBack1 As New AsyncCallback(AddressOf unLock1)
		Private callBack2 As New AsyncCallback(AddressOf unLock2)
		Private callBack3 As New AsyncCallback(AddressOf unLock3)
		Private callBack4 As New AsyncCallback(AddressOf unLock4)
		Private Shared Sub unLock1(ByVal ar As IAsyncResult)
			Semaphore_ThreadTakeInput1.Release()
		End Sub
		Private Shared Sub unLock2(ByVal ar As IAsyncResult)
			Semaphore_ThreadTakeInput2.Release()
		End Sub
		Private Shared Sub unLock3(ByVal ar As IAsyncResult)
			Semaphore_ThreadTakeInput3.Release()
		End Sub
		Private Shared Sub unLock4(ByVal ar As IAsyncResult)
			Semaphore_ThreadTakeInput4.Release()
		End Sub
		Private async1 As System.ComponentModel.AsyncOperation = System.ComponentModel.AsyncOperationManager.CreateOperation(Nothing)
		Private async2 As System.ComponentModel.AsyncOperation = System.ComponentModel.AsyncOperationManager.CreateOperation(Nothing)
		Private async3 As System.ComponentModel.AsyncOperation = System.ComponentModel.AsyncOperationManager.CreateOperation(Nothing)
		Private async4 As System.ComponentModel.AsyncOperation = System.ComponentModel.AsyncOperationManager.CreateOperation(Nothing)
		'   AsyncCallback completedCallback = new AsyncCallback(null);
		#End Region ' ---Thread Sync stuff---
		#Region "BaseData"
		Public Class BaseData
			#Region "delegates"
			Public Delegate Sub d_AffectivEvent(ByVal AffectivEvent_Data As AffectivState.AffectivData)
			Public Delegate Sub d_CognitivEvent(ByVal CognitivEvent_Data As CognitivState.CognitivData)
			Public Delegate Sub d_EmoState(ByVal EmoState_Data As EmoState.EmoData)
			Public Delegate Sub d_ExpressivEvent(ByVal ExpressivEvent_Data As FacialState.ExpressivData)
			Public Delegate Sub d_FacialEvent(ByVal FacialEvent_Data As FacialState.FacialData)
			Public Delegate Sub d_HeadsetRawDataEvent(ByVal AffectivEvent_Data As HeadsetRawDataState.HeadsetRawData_Data)
			Public Delegate Sub d_HeadsetBaseEvent(ByVal HeadsetBaseData As HeadsetBaseState.HeadsetBaseData)
			#End Region ' ---delegates---

			#Region "EmoState"
			Public Class EmoState
				Public Class EmoData
					Public TimeStamp As Single
					Public myEmoAction As EmoAction_emun
					Public actionPower As Single
				End Class
				Public Enum EmoAction_emun
					COG_DISAPPEAR = &H2000
					COG_DROP = &H10
					COG_LEFT = &H20
					COG_LIFT = 8
					COG_NEUTRAL = 1
					COG_PULL = 4
					COG_PUSH = 2
					COG_RIGHT = &H40
					COG_ROTATE_CLOCKWISE = &H200
					COG_ROTATE_COUNTER_CLOCKWISE = &H400
					COG_ROTATE_FORWARDS = &H800
					COG_ROTATE_LEFT = &H80
					COG_ROTATE_REVERSE = &H1000
					COG_ROTATE_RIGHT = &H100
				End Enum
			End Class
			#End Region ' ---EmoState---
			#Region "CognitivState"
			Public Class CognitivState
				Public Class CognitivData
					Public myCognitivAction As CognitivAction_enum
					Public myCognitivEvent As CognitivEvent_enum
					Public actionPower As Single
					Public TimeStamp As Single
				End Class

				Public ActionSensitivity() As Integer
				Private ActionSkillRating As Single
				Private ActivationLevel As Integer
				Private ActiveActions As UInteger
				Private OverallSkillRating As Single
				Private SignatureCacheSize As UInteger
				Private SignatureCaching As UInteger
				Private TrainedSignatureActions As UInteger
				Private TrainingAction As BaseData.CognitivState.CognitivAction_enum
				Private TrainingTime As UInteger

				Public Enum CognitivEvent_enum
					EE_CognitivNoEvent
					EE_CognitivTrainingStarted
					EE_CognitivTrainingSucceeded
					EE_CognitivTrainingFailed
					EE_CognitivTrainingCompleted
					EE_CognitivTrainingDataErased
					EE_CognitivTrainingRejected
					EE_CognitivTrainingReset
					EE_CognitivAutoSamplingNeutralCompleted
					EE_CognitivSignatureUpdated
				End Enum
				Public Enum CognitivAction_enum
					COG_DISAPPEAR = &H2000
					COG_DROP = &H10
					COG_LEFT = &H20
					COG_LIFT = 8
					COG_NEUTRAL = 1
					COG_PULL = 4
					COG_PUSH = 2
					COG_RIGHT = &H40
					COG_ROTATE_CLOCKWISE = &H200
					COG_ROTATE_COUNTER_CLOCKWISE = &H400
					COG_ROTATE_FORWARDS = &H800
					COG_ROTATE_LEFT = &H80
					COG_ROTATE_REVERSE = &H1000
					COG_ROTATE_RIGHT = &H100
				End Enum
				Public Enum CognitivTrainingControl_enum
					COG_NONE
					COG_START
					COG_ACCEPT
					COG_REJECT
					COG_ERASE
					COG_RESET
				End Enum
			End Class
			#End Region ' ---CognitivState---
			#Region "FacialState"
			Public Class FacialState
				Public Class FacialData
					Public TimeStamp As Single
					Public myFaceActionUpper As FaceExpressiv_enum
					Public myFaceActionLower As FaceExpressiv_enum
					Public UpperFaceAmp As Single
					Public LowerFaceAmp As Single


					Public Blink As Boolean
					Public WinkLeft As Boolean
					Public WinkRight As Boolean
					Public LookingLeft As Boolean
					Public LookingRight As Boolean
				End Class
				Public Class ExpressivData
					Public TimeStamp As Single
					Public myExpressivAction As ExpressivEvent_enum
					Public TrainedSignatureAvailable As Boolean
				End Class
				Public Enum FaceExpressiv_enum
					EXP_NEUTRAL = &H1
					EXP_BLINK = &H2
					EXP_WINK_LEFT = &H4
					EXP_WINK_RIGHT = &H8
					EXP_HORIEYE = &H10
					EXP_EYEBROW = &H20
					EXP_FURROW = &H40
					EXP_SMILE = &H80
					EXP_CLENCH = &H100
					EXP_LAUGH = &H200
					EXP_SMIRK_LEFT = &H400
					EXP_SMIRK_RIGHT = &H800
				End Enum
				Public Enum ExpressivEvent_enum
					EE_ExpressivNoEvent
					EE_ExpressivTrainingStarted
					EE_ExpressivTrainingSucceeded
					EE_ExpressivTrainingFailed
					EE_ExpressivTrainingCompleted
					EE_ExpressivTrainingDataErased
					EE_ExpressivTrainingRejected
					EE_ExpressivTrainingReset
				End Enum
			End Class
			#End Region ' ---FacialState---
			#Region "AffectivState"
			Public Class AffectivState
				Public Class AffectivData
					Public TimeStamp As Single
					Public ExcitementShortTerm As Single
					Public ExcitementLongTerm As Single
					Public EngagementBoredom As Single
				End Class
				Public Enum AffectivAlgo_enum
					AFF_ENGAGEMENT_BOREDOM = 8
					AFF_EXCITEMENT = 1
					AFF_FRUSTRATION = 4
					AFF_MEDITATION = 2
				End Enum
			End Class
			#End Region ' ---AffectivState---
			#Region "HeadsetState"
			Public Class HeadsetBaseState
				Public Class HeadsetBaseData
					Public TimeStamp As Single
					Public SignalStrength As SignalStrength_enum
					Public HeadsetOn As Boolean

					Public BatteryChargeLevel As Integer
					Public BatteryChargeMax As Integer
					Public BatteryChargePercentage? As Integer
				End Class
				Public Enum SignalStrength_enum
					NO_SIGNAL
					BAD_SIGNAL
					GOOD_SIGNAL
				End Enum
				Public Enum EEG_ContactQuality_enum
					EEG_CQ_NO_SIGNAL
					EEG_CQ_VERY_BAD
					EEG_CQ_POOR
					EEG_CQ_FAIR
					EEG_CQ_GOOD
				End Enum
			End Class
			#End Region ' ---HeadsetState---
			#Region "GyrotState"
			Public Class GyroState
				Public Class GyroData
					Public X As Integer
					Public Y As Integer
				End Class
			End Class
			#End Region ' ---GyroState---
			#Region "HeadsetRawDataState"
			''' <summary>
			''' mock
			''' </summary>
			Public Class HeadsetRawDataState
				Public Class HeadsetRawData_Data

				End Class

				Public Enum InputChannels_enum
					EE_CHAN_CMS
					EE_CHAN_DRL
					EE_CHAN_FP1
					EE_CHAN_AF3
					EE_CHAN_F7
					EE_CHAN_F3
					EE_CHAN_FC5
					EE_CHAN_T7
					EE_CHAN_P7
					EE_CHAN_O1
					EE_CHAN_O2
					EE_CHAN_P8
					EE_CHAN_T8
					EE_CHAN_FC6
					EE_CHAN_F4
					EE_CHAN_F8
					EE_CHAN_AF4
					EE_CHAN_FP2
				End Enum
                <System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)> _
    Public Class InputSensorDescriptor_pack
                    Public channelID As InputChannels_enum
                    Public Exists As Integer
                    Public zLabel As String
                    Public xLoc As Double
                    Public yLoc As Double
                    Public zLoc As Double
                End Class
			End Class
			#End Region ' ---HeadsetRawDataState---

			#Region "TrainingState"
			Public Class TrainingState
				Public Class TrainingData

				End Class
			End Class
			#End Region ' ---TrainingState---
		End Class
		#End Region ' ---BaseData---

		#Region "con"
		Public Sub New(ByVal useRealHeadSet As headsetConnectionType)
			m_EmoEnginEvent = Emotiv.EdkDll.EE_EmoEngineEventCreate()
			m_EmoState = Emotiv.EdkDll.EE_EmoStateCreate()
			m_EmoEngine = Emotiv.EmoEngine.Instance

			myRawData = New HeadsetRawData(Me)
			myHeadsetBase = New HeadsetBase(Me)

			myCognitiv = New Cognitiv(Me)
			myAffectiv = New Affectiv(Me)
			myExpressiv = New Expressiv(Me)
			myUser = New User(Me)

			myTraining = New Training(Me)


			UpdateUserID()


			If InputThread Is Nothing Then
				ThreadTakeInput()
			End If

			Dim conected As Boolean = False
			Do While Not conected
				If useRealHeadSet = headsetConnectionType.Real Then
					Emotiv.EdkDll.EE_EngineConnect()
					System.Threading.Thread.SpinWait(10)
					If Not headsetDataFound Then
						System.Threading.Thread.Sleep(500)
						If Not headsetDataFound Then
							conected = True
						End If
					Else
						conected = True
					End If
				Else
					If useRealHeadSet = headsetConnectionType.Fake Then
						If Emotiv.EdkDll.EE_EngineRemoteConnect(IP, PortFake) = Emotiv.EdkDll.EDK_OK Then
							conected = True
						End If
					Else
						If useRealHeadSet = headsetConnectionType.AskUser Then
							Dim DR As DialogResult = MessageBox.Show("Connect to head set:" & vbLf & "Use Real Headset = Yes" & vbLf & "UseEmoComposer = NO" & vbLf & "Use Control Panal= Cancle", "real or fake headset??", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

							If DialogResult.Yes = DR Then
								Emotiv.EdkDll.EE_EngineConnect()
								System.Threading.Thread.Sleep(100)
								If Not headsetDataFound Then
									System.Threading.Thread.Sleep(500)
									If headsetDataFound Then
										conected = True
									End If
								Else
									conected = True
								End If
							Else
								If DialogResult.No = DR Then
									If Emotiv.EdkDll.EE_EngineRemoteConnect(IP, PortFake) = Emotiv.EdkDll.EDK_OK Then
										conected = True
									End If
								Else
									If Emotiv.EdkDll.EE_EngineRemoteConnect(IP, PortReal) = Emotiv.EdkDll.EDK_OK Then
										conected = True
									End If
								End If
							End If
						End If
					End If
				End If
				If Not conected Then
					Dim DR As DialogResult = MessageBox.Show("Could not connect to EPOC" & vbLf & "Try again??", "Try Fake Headset again??", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
					If DialogResult.Yes = DR Then

					Else
						Throw New Exception("Fail: to Connect Headset")
					End If
				End If

			Loop


		End Sub
		#End Region ' ---con---

		#Region "pollInput"
		Private Sub ThreadTakeInput()
            InputThread = New System.Threading.Thread(New System.Threading.ThreadStart(AddressOf ThreadTakeInput1))
			InputThread.IsBackground = True
			InputThread.Start()

		End Sub
		Private Sub ThreadTakeInput1()
'			#Region "vars"
			Dim fails As Integer = 0
            '#If DEBUG Then
            Dim lagOut As Integer = 0
            '#End If
			Dim lastTics_Update As Long = 0
			Dim lastFail_Time As Long = Date.Now.Ticks
			Dim OnUserID As UInteger
			Dim DataPackStartTicks As Long
			Dim eventTypeIN As Emotiv.EdkDll.EE_Event_t
			Dim dataRate_updateTime As Long = 1500000
			Dim dataRate_dropLagTimeout As Long = 1000000000

'			#End Region ' ---vars---

				Do
					Try
'						#Region "while"
'						#Region "head lock"
						Dim sleep As Long = dataRate_updateTime - (Date.Now.Ticks - lastTics_Update)
						If Date.Now.Ticks - dataRate_updateTime < lastTics_Update Then
							If sleep > 0 AndAlso sleep < dataRate_updateTime * 2 Then
								System.Threading.Thread.Sleep(CInt(Fix(sleep \ TimeSpan.TicksPerMillisecond)))
							End If
						End If
'						#End Region ' ---head lock---

						Semaphore_ThreadTakeInput.WaitOne()
						lastTics_Update = Date.Now.Ticks

'						#Region "get data"

                    ' 99.9% this is ok but it can crash
                    If Emotiv.EdkDll.EE_EngineGetNextEvent(m_EmoEnginEvent) <> 0 Then
                        Dim tempVar As Boolean = fails > 5
                        fails += 1
                        If tempVar Then

                            Dim dif As Long = Date.Now.Ticks - lastFail_Time
                            If dif < dataRate_updateTime * 10 AndAlso headsetDataFound Then
                                Dim DR As DialogResult = MessageBox.Show("Connection to helmet lost!!" & vbLf & "Reconnect headset??", "Reconnect headset??", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                                If DialogResult.Yes = DR Then
                                    fails = 0
                                Else
                                    RaiseEvent DIE()
                                    Return
                                End If
                            Else

                                fails = 0
                            End If
                            lastFail_Time = Date.Now.Ticks

                        End If
                        Throw New Exception("VB Fails")
                    Else
                        fails = 0
                    End If

                    DataPackStartTicks = Date.Now.Ticks

                    OnUserID = 99999
                    Emotiv.EdkDll.EE_EmoEngineEventGetUserId(m_EmoEnginEvent, OnUserID)
                    ' set Time Stamp
                    timeStamp = Emotiv.EdkDll.ES_GetTimeFromStart(m_EmoState)

                    If Date.Now.Ticks - DataPackStartTicks > dataRate_dropLagTimeout Then
                        '#If DEBUG Then
                        Dim tempVar2 As Boolean = lagOut > 1000
                        lagOut += 1
                        If tempVar2 Then
                            lagOut = 0
                            Throw New Exception("Lag Fails Data stream #u9f8dsgf8igy7ds")
                        End If

                        '#End If
                        Continue Do
                    End If

                    '						#End Region ' ---get data---

                    ' update EmoState
                    Emotiv.EdkDll.EE_EmoEngineEventGetEmoState(m_EmoEnginEvent, m_EmoState)
                    eventTypeIN = Emotiv.EdkDll.EE_EmoEngineEventGetType(m_EmoEnginEvent)

                    '						#Region "switch"
                    Select Case eventTypeIN
                        '							#Region "EE_CognitivEvent"
                        Case Emotiv.EdkDll.EE_Event_t.EE_CognitivEvent
                            Dim val As Training.TrainingTypes = CType(System.Enum.ToObject(GetType(Training.TrainingTypes), eventTypeIN), Training.TrainingTypes)
                            myTraining.FireEvent(val, UserID)
                            Exit Select
                            '							#End Region ' ---EE_CognitivEvent---

                            '							#Region "EE_ExpressivEvent"
                        Case Emotiv.EdkDll.EE_Event_t.EE_ExpressivEvent
                            Dim val As Expressiv.ExpressivTypes = CType(System.Enum.ToObject(GetType(Expressiv.ExpressivTypes), eventTypeIN), Expressiv.ExpressivTypes)
                            myExpressiv.FireEvent(val, UserID)
                            Exit Select

                            '							#End Region ' ---EE_ExpressivEvent---

                            '							#Region "Device"
                        Case Emotiv.EdkDll.EE_Event_t.EE_InternalStateChanged

                        Case Emotiv.EdkDll.EE_Event_t.EE_UserAdded, Emotiv.EdkDll.EE_Event_t.EE_UserRemoved
                            Dim val As User.UserTypes = CType(System.Enum.ToObject(GetType(User.UserTypes), eventTypeIN), User.UserTypes)
                            myUser.FireEvent(val, UserID)
                            Exit Select
                            '							#End Region ' ---Device---

                            '							#Region "EE_EmoStateUpdated"
                        Case Emotiv.EdkDll.EE_Event_t.EE_EmoStateUpdated
                            headsetDataFound = True

                            '/////////////////////////
                            'BaseData.BaseData.HeadsetState HeadsetDate = new BaseData.HeadsetState();
                            '////////////////////////////////////////
                            '////////////////////////////////

                            '									#Region "NewEmoState"
                            '	If NewEmoState IsNot Nothing Then
                            '     the0nex.EmotivPower.BaseData.EmoState.EmoData EmoData = null;


                            '    Emotiv.EdkDll.EE_CognitivAction_t actionType = Emotiv.EdkDll.ES_CognitivGetCurrentAction(m_EmoState);
                            '   float actionPower = Emotiv.EdkDll.ES_CognitivGetCurrentActionPower(m_EmoState);

                            '   EmoData = new the0nex.EmotivPower.BaseData.EmoState.EmoData();
                            '   EmoData.actionPower = actionPower * 100;
                            '  EmoData.myEmoAction = (BaseData.EmoState.EmoAction_emun)actionType;

                            '     Semaphore_ThreadTakeInput1.WaitOne();
                            '      NewEmoState.BeginInvoke(EmoData, callBack1, async1);
                            '	End If
                            '									#End Region ' ---NewEmoState---

                            '									#Region "NewHeadsetRawDataEvent"
                            '                   If NewHeadsetRawDataEvent IsNot Nothing Then
                            Try
                                ' only do this if you have access to raw EEG - $750 research sdk:)
                                'Dim HeadsetRawData_Data As BaseData.HeadsetRawDataState.HeadsetRawData_Data = myRawData.BuildHeadsetRawDataState
                                'RaiseEvent NewHeadsetRawDataEvent(HeadsetRawData_Data)
                            Catch ex As Exception

                            End Try
                            'End If
                            '									#End Region ' ---NewHeadsetRawDataEvent---

                            '									#Region "NewAffectivEvent"
                            ' If NewAffectivEvent IsNot Nothing Then
                            Dim AffectivData As BaseData.AffectivState.AffectivData = myAffectiv.BuildAffectivState
                            RaiseEvent NewAffectivEvent(AffectivData)
                            'End If
                            '									#End Region ' ---NewAffectivEvent---

                            '									#Region "NewCognitivEvent"
                            'If NewCognitivEvent IsNot Nothing Then
                            Dim CognitivData As BaseData.CognitivState.CognitivData = myCognitiv.BuildCognitivState
                            RaiseEvent NewCognitivEvent(CognitivData)
                            ' End If
                            '									#End Region ' ---NewCognitivEvent---

                            '									#Region "face"
                            '        If NewExpressivEvent IsNot Nothing Then
                            Dim ExpressivData As BaseData.FacialState.ExpressivData = myExpressiv.BuildExpressiv
                            RaiseEvent NewExpressivEvent(ExpressivData)
                            'End If

                            '         If NewFacialEvent IsNot Nothing Then
                            Dim FacialData As BaseData.FacialState.FacialData = myExpressiv.BuildFacial
                            RaiseEvent NewFacialEvent(FacialData)
                            'End If
                            '									#End Region ' ---face---

                            '									#Region "base"
                            ' If NewHeadsetBaseEvent IsNot Nothing Then
                            Dim HeadsetBaseData As BaseData.HeadsetBaseState.HeadsetBaseData = myHeadsetBase.GetHeadsetBaseState
                            RaiseEvent NewHeadsetBaseEvent(HeadsetBaseData)
                            'End If
                            '									#End Region ' ---base---
                            Exit Select

                            '							#End Region ' ---EE_EmoStateUpdated---

                        Case Else
                            Exit Select
                    End Select
                    '						#End Region ' ---switch---
                    '						#End Region ' ---while---
                Catch
                    Dim i As Integer = 0
                    Dim s As String = i.ToString()
                Finally
                    Semaphore_ThreadTakeInput.Release()
                End Try
            Loop
		End Sub
		#End Region ' ---pollInput---
		#Region "sub classes"
		#Region "Affectiv"
		Public Class Affectiv
			#Region "AffectivData"
			Public ReadOnly Property BuildAffectivState() As BaseData.AffectivState.AffectivData
				Get
					Dim AffectivData As New BaseData.AffectivState.AffectivData()
					AffectivData.TimeStamp = theEmotivPower.timeStamp
					' Affectiv Suite results
					AffectivData.ExcitementShortTerm = AffectivGetExcitementShortTermScore()
					AffectivData.ExcitementLongTerm = AffectivGetExcitementLongTermScore()

					AffectivData.EngagementBoredom = AffectivGetEngagementBoredomScore()

					Return AffectivData
				End Get
			End Property
			#End Region ' ---AffectivData---

			#Region "vars"
			Private ReadOnly theEmotivPower As EmotivPower
			#End Region ' ---vars---

			#Region "con"
			Public Sub New(ByVal EmotivPowerIN As EmotivPower)
				theEmotivPower = EmotivPowerIN
			End Sub
			#End Region ' ---con---

			#Region "Functions"
			'! Returns the long term excitement level of the user
'            !
'                \param state - EmoStateHandle
'
'                \return excitement level (0.0 to 1.0)
'
'                \sa AffectivGetExcitementShortTermScore
'            
			Private Function AffectivGetExcitementLongTermScore() As Single
				Return Emotiv.EdkDll.ES_AffectivGetExcitementLongTermScore(theEmotivPower.m_EmoState)
			End Function

			'! Returns short term excitement level of the user
'            !
'                \param state - EmoStateHandle
'
'                \return excitement level (0.0 to 1.0)
'
'                \sa ES_AffectivGetExcitementLongTermScore
'            
			Private Function AffectivGetExcitementShortTermScore() As Single
				Return Emotiv.EdkDll.ES_AffectivGetExcitementShortTermScore(theEmotivPower.m_EmoState)
			End Function

			'! Query whether the signal is too noisy for Affectiv detection to be active
'            !
'                \param state - EmoStateHandle
'                \param type  - Affectiv detection type
'
'                \return detection state (0: Not Active, 1: Active)
'
'                \sa EE_AffectivAlgo_t
'            
			Private Function AffectivIsActive(ByVal type As BaseData.AffectivState.AffectivAlgo_enum) As Boolean
				Return Emotiv.EdkDll.ES_AffectivIsActive(theEmotivPower.m_EmoState, CType(type, Emotiv.EdkDll.EE_AffectivAlgo_t))

			End Function

			'! Returns meditation level of the user
'            !
'                \param state - EmoStateHandle
'
'                \return meditation level (0.0 to 1.0)
'            

			Private Function AffectivGetMeditationScore() As Single
				Return Emotiv.EdkDll.ES_AffectivGetMeditationScore(theEmotivPower.m_EmoState)
			End Function
			'! Returns frustration level of the user
'            !
'                \param state - EmoStateHandle
'
'                \return frustration level (0.0 to 1.0)
'            
			Private Function AffectivGetFrustrationScore() As Single
				Return Emotiv.EdkDll.ES_AffectivGetFrustrationScore(theEmotivPower.m_EmoState)
			End Function
			'! Returns engagement/boredom level of the user
'            !
'                \param state - EmoStateHandle
'
'                \return engagement/boredom level (0.0 to 1.0)
'            
			Private Function AffectivGetEngagementBoredomScore() As Single
				Return Emotiv.EdkDll.ES_AffectivGetEngagementBoredomScore(theEmotivPower.m_EmoState)
			End Function
			#End Region ' ---Functions---
		End Class
		#End Region ' ---Affectiv---
		#Region "Cognitiv"
		Public Class Cognitiv
			#Region "CognitivData"
			Public ReadOnly Property BuildCognitivState() As BaseData.CognitivState.CognitivData
				Get
					Dim CognitivData As New BaseData.CognitivState.CognitivData()

					CognitivData.TimeStamp = theEmotivPower.timeStamp

					'------------------------CognitivGetCurrentAction---------------------------
					Dim actionType As BaseData.CognitivState.CognitivAction_enum = CognitivGetCurrentAction()
					Dim actionPower As Single = CognitivGetCurrentActionPower()


					CognitivData.actionPower = actionPower * 100
					CognitivData.myCognitivAction = actionType

					'NewCognitivEvent.BeginInvoke(CognitivData, callBack1, async1);
					'------------------------CognitivGetCurrentAction---------------------------


					Dim eventType As Emotiv.EdkDll.EE_CognitivEvent_t = Emotiv.EdkDll.EE_CognitivEventGetType(theEmotivPower.m_EmoEnginEvent)
					CognitivData.myCognitivEvent = CType(eventType, BaseData.CognitivState.CognitivEvent_enum)

					Return CognitivData
				End Get
			End Property
			#End Region ' ---CognitivData---

			#Region "vars"
			Private ReadOnly theEmotivPower As EmotivPower
			#End Region ' ---vars---

			#Region "con"
			Public Sub New(ByVal EmotivPowerIN As EmotivPower)
				theEmotivPower = EmotivPowerIN
			End Sub
			#End Region ' ---con---

			#Region "GET Functions"
			Public Function CognitivGetCurrentAction() As BaseData.CognitivState.CognitivAction_enum
				Dim actionType As Emotiv.EdkDll.EE_CognitivAction_t = Emotiv.EdkDll.ES_CognitivGetCurrentAction(theEmotivPower.m_EmoState)
				Return CType(actionType, BaseData.CognitivState.CognitivAction_enum)
			End Function
			Public Function CognitivGetCurrentActionPower() As Single
				Return Emotiv.EdkDll.ES_CognitivGetCurrentActionPower(theEmotivPower.m_EmoState)
			End Function
			Public Function CognitivGetActionSensitivity() As Integer()
				Dim pAction1SensitivityOut As Integer
				Dim pAction2SensitivityOut As Integer
				Dim pAction3SensitivityOut As Integer
				Dim pAction4SensitivityOut As Integer
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetActionSensitivity(theEmotivPower.UserID, pAction1SensitivityOut, pAction2SensitivityOut, pAction3SensitivityOut, pAction4SensitivityOut)
				Dim outArray() As Integer = { pAction1SensitivityOut, pAction2SensitivityOut, pAction3SensitivityOut, pAction4SensitivityOut }

				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetActionSensitivity (" & [error] & ") #9pjollw35")
				End If

				Return outArray
			End Function
			Public Function CognitivGetActionSkillRating(ByVal actionType As EmotivPower.BaseData.CognitivState.CognitivAction_enum) As Single
				Dim pActionSkillRatingOut As Single
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetActionSkillRating(theEmotivPower.UserID, CType(actionType, Emotiv.EdkDll.EE_CognitivAction_t), pActionSkillRatingOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetActionSkillRating (" & [error] & ") #gy7igd5r5657")
				End If

				Return pActionSkillRatingOut
			End Function
			Public Function CognitivGetActivationLevel() As Integer
				Dim pLevelOut As Integer
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetActivationLevel(theEmotivPower.UserID, pLevelOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetActivationLevel (" & [error] & ") #7jnr6u76")
				End If

				Return pLevelOut
			End Function
			Public Function CognitivGetActiveActions() As UInteger
				Dim pActiveActionsOut As UInteger
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetActiveActions(theEmotivPower.UserID, pActiveActionsOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetActiveActions (" & [error] & ") #b7rhnn6u7u")
				End If

				Return pActiveActionsOut
			End Function
			Public Function CognitivGetOverallSkillRating() As Single
				Dim pOverallSkillRatingOut As Single
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetOverallSkillRating(theEmotivPower.UserID, pOverallSkillRatingOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetOverallSkillRating (" & [error] & ") #n6uyjnyjg")
				End If

				Return pOverallSkillRatingOut
			End Function
			Public Function CognitivGetSignatureCacheSize() As UInteger
				Dim pSizeOut As UInteger
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetSignatureCacheSize(theEmotivPower.UserID, pSizeOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetSignatureCacheSize (" & [error] & ") #b5s4et4n66")
				End If

				Return pSizeOut
			End Function
			Public Function CognitivGetSignatureCaching() As UInteger
				Dim pEnabledOut As UInteger
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetSignatureCaching(theEmotivPower.UserID, pEnabledOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetSignatureCaching (" & [error] & ") #7nmgm8ur8fm")
				End If

				Return pEnabledOut
			End Function
			Public Function CognitivGetTrainedSignatureActions() As UInteger
				Dim pTrainedActionsOut As UInteger
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetTrainedSignatureActions(theEmotivPower.UserID, pTrainedActionsOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetTrainedSignatureActions (" & [error] & ") #7n86im7yug")
				End If

				Return pTrainedActionsOut
			End Function
			Public Function CognitivGetTrainingAction() As BaseData.CognitivState.CognitivAction_enum
				Dim pActionOut As Emotiv.EdkDll.EE_CognitivAction_t
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetTrainingAction(theEmotivPower.UserID, pActionOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetTrainingAction (" & [error] & ") #i978polh")
				End If

				Return CType(pActionOut, EmotivPower.BaseData.CognitivState.CognitivAction_enum)
			End Function
			Public Function CognitivGetTrainingTime() As UInteger
				Dim pTrainingTimeOut As UInteger
				Dim [error] As Integer = Emotiv.EdkDll.EE_CognitivGetTrainingTime(theEmotivPower.UserID, pTrainingTimeOut)
				If CType([error], ERROR_CODE_emun) <> ERROR_CODE_emun.EDK_OK Then
					Throw New Exception("error: CognitivGetTrainingTime (" & [error] & ") #ig897g")
				End If

				Return pTrainingTimeOut
			End Function
			#End Region ' ---GET Functions---

			#Region "SET Functions"
			Public Function CognitivSetActionSensitivity(ByVal action1Sensitivity As Integer, ByVal action2Sensitivity As Integer, ByVal action3Sensitivity As Integer, ByVal action4Sensitivity As Integer) As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivSetActionSensitivity(theEmotivPower.UserID, action1Sensitivity, action2Sensitivity, action3Sensitivity, action4Sensitivity), ERROR_CODE_emun)
			End Function
			Public Function CognitivSetActivationLevel(ByVal level As Integer) As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivSetActivationLevel(theEmotivPower.UserID, level), ERROR_CODE_emun)
			End Function
			Public Function CognitivSetActivationLevel(ByVal activeActions As UInteger) As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivSetActiveActions(theEmotivPower.UserID, activeActions), ERROR_CODE_emun)
			End Function
			Public Function CognitivSetSignatureCacheSize(ByVal size As UInteger) As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivSetSignatureCacheSize(theEmotivPower.UserID, size), ERROR_CODE_emun)
			End Function
			Public Function CognitivSetSignatureCaching(ByVal enabled As UInteger) As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivSetSignatureCaching(theEmotivPower.UserID, enabled), ERROR_CODE_emun)
			End Function
			Public Function CognitivSetTrainingAction(ByVal action As EmotivPower.BaseData.CognitivState.CognitivAction_enum) As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivSetTrainingAction(theEmotivPower.UserID, CType(action, Emotiv.EdkDll.EE_CognitivAction_t)), ERROR_CODE_emun)
			End Function
			Public Function CognitivSetTrainingControl(ByVal action As EmotivPower.BaseData.CognitivState.CognitivTrainingControl_enum) As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivSetTrainingControl(theEmotivPower.UserID, CType(action, Emotiv.EdkDll.EE_CognitivTrainingControl_t)), ERROR_CODE_emun)
			End Function
			Public Function CognitivStartSamplingNeutral() As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivStartSamplingNeutral(theEmotivPower.UserID), ERROR_CODE_emun)
			End Function
			Public Function CognitivStopSamplingNeutral() As ERROR_CODE_emun
				Return CType(Emotiv.EdkDll.EE_CognitivStopSamplingNeutral(theEmotivPower.UserID), ERROR_CODE_emun)
			End Function
			#End Region ' ---SET Functions---
		End Class
		#End Region ' ---Cognitiv---
		#Region "Expressiv"
		Public Class Expressiv
			#Region "ExpressivData"
			Public ReadOnly Property BuildExpressiv() As BaseData.FacialState.ExpressivData
				Get
					Dim ExpressivData As New BaseData.FacialState.ExpressivData()
					ExpressivData.TimeStamp = theEmotivPower.timeStamp
					ExpressivData.myExpressivAction = ExpressivEventGetType()

					Return ExpressivData
				End Get
			End Property
			Public ReadOnly Property BuildFacial() As BaseData.FacialState.FacialData
				Get
					Dim FacialData As New BaseData.FacialState.FacialData()
					FacialData.TimeStamp = theEmotivPower.timeStamp

					FacialData.myFaceActionUpper = ExpressivGetUpperFaceAction()
					FacialData.myFaceActionLower = ExpressivGetLowerFaceAction()

					FacialData.UpperFaceAmp = ExpressivGetUpperFaceActionPower()
					FacialData.LowerFaceAmp = ExpressivGetLowerFaceActionPower()

					FacialData.Blink = ExpressivIsBlink()
					FacialData.WinkLeft = ExpressivIsLeftWink()
					FacialData.WinkRight = ExpressivIsRightWink()
					FacialData.LookingRight = ExpressivIsLookingRight()
					FacialData.LookingLeft = ExpressivIsLookingLeft()
					Return FacialData
				End Get
			End Property
			#End Region ' ---ExpressivData---
			#Region "event"
			Public Delegate Sub sendUser(ByVal userID As UInteger)
			Public Delegate Sub sendUserAndType(ByVal eventType As ExpressivTypes, ByVal userID As UInteger)
			Public Enum ExpressivTypes
				ExpressivNoEvent
				ExpressivTrainingStarted
				ExpressivTrainingSucceeded
				ExpressivTrainingFailed
				ExpressivTrainingCompleted
				ExpressivTrainingDataErased
				ExpressivTrainingRejected
				ExpressivTrainingReset

			End Enum
			Public Event sendEvent As sendUserAndType
			#Region "FireEvent"
			Public Sub FireEvent(ByVal typeIN As ExpressivTypes, ByVal UserID_IN As UInteger)
				RaiseEvent sendEvent(typeIN, UserID_IN)

			End Sub
			#End Region ' ---FireEvent---
			#End Region ' ---event---

			#Region "vars"
			Private ReadOnly theEmotivPower As EmotivPower
			#End Region ' ---vars---

			#Region "con"
			Public Sub New(ByVal EmotivPowerIN As EmotivPower)
				theEmotivPower = EmotivPowerIN
			End Sub
			#End Region ' ---con---

			#Region "Functions"

			''' <summary>
			''' Returns the Expressiv-specific event type for an EE_ExpressivEvent event already retrieved using EE_EngineGetNextEvent
			''' </summary>
			''' <returns></returns>
			Private Function ExpressivEventGetType() As BaseData.FacialState.ExpressivEvent_enum
				Dim eventType As Emotiv.EdkDll.EE_ExpressivEvent_t = Emotiv.EdkDll.EE_ExpressivEventGetType(theEmotivPower.m_EmoEnginEvent)
				Return CType(eventType, BaseData.FacialState.ExpressivEvent_enum)
			End Function


			'! Query whether the user is blinking at the time the EmoState is captured.
'            !
'                \param state - EmoStateHandle
'
'                \return blink status (1: blink, 0: not blink)
'
'            
			Private Function ExpressivIsBlink() As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsBlink(CType(theEmotivPower.m_EmoState, IntPtr))

			End Function

			'! Query whether the user is winking left at the time the EmoState is captured.
'            !
'                \param state - EmoStateHandle
'
'                \return left wink status (1: wink, 0: not wink)
'
'                \sa ES_ExpressivIsRightWink
'            
			Private Function ExpressivIsLeftWink() As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsLeftWink(theEmotivPower.m_EmoState)
			End Function

			'! Query whether the user is winking right at the time the EmoState is captured.
'            !
'                \param state - EmoStateHandle
'
'                \return right wink status (1: wink, 0: not wink)
'
'                \sa ES_ExpressivIsLeftWink
'            
			Private Function ExpressivIsRightWink() As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsRightWink(theEmotivPower.m_EmoState)

			End Function
			'! Query whether the eyes of the user are opened at the time the EmoState is captured.
'            !
'                \param state - EmoStateHandle
'
'                \return eye open status (1: eyes open, 0: eyes closed)
'
'            
			Private Function ExpressivIsEyesOpen() As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsEyesOpen(theEmotivPower.m_EmoState)

			End Function
			'! Query whether the user is looking up at the time the EmoState is captured.
'            !
'                \param state - EmoStateHandle
'
'                \return eyes position (1: looking up, 0: not looking up)
'
'                \sa ES_ExpressivIsLookingDown
'            
			Private Function ExpressivIsLookingUp() As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsLookingUp(theEmotivPower.m_EmoState)

			End Function

			'! Query whether the user is looking down at the time the EmoState is captured.
'            !
'                \param state - EmoStateHandle
'
'                \return eyes position (1: looking down, 0: not looking down)
'
'                \sa ES_ExpressivIsLookingUp
'            
			Private Function ExpressivIsLookingDown() As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsLookingDown(theEmotivPower.m_EmoState)
			End Function

			'! Query whether the user is looking left at the time the EmoState is captured.
'            !
'                \param state - EmoStatehandle
'
'                \return eye position (1: looking left, 0: not looking left)
'
'                \sa ES_ExpressivIsLookingRight
'            
			Private Function ExpressivIsLookingLeft() As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsLookingLeft(theEmotivPower.m_EmoState)
			End Function

			'! Query whether the user is looking right at the time the EmoState is captured.
'            !
'                \param state - EmoStatehandle
'
'                \return eye position (1: looking right, 0: not looking right)
'
'                \sa ES_ExpressivIsLookingLeft
'            
			Private Function ExpressivIsLookingRight() As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsLookingRight(theEmotivPower.m_EmoState)

			End Function

			'! Query the eyelids state of the user
'            !
'                The left and right eyelid state are stored in the parameter leftEye and rightEye
'                respectively. They are floating point values ranging from 0.0 to 1.0.
'                0.0 indicates that the eyelid is fully opened while 1.0 indicates that the
'                eyelid is fully closed.
'
'                \param state - EmoStatehandle
'                \param leftEye - the left eyelid state (0.0 to 1.0)
'                \param rightEye - the right eyelid state (0.0 to 1.0)
'
'            
			Private Function ExpressivGetEyelidState() As Single()
				Dim tempData(1) As Single
				Emotiv.EdkDll.ES_ExpressivGetEyelidState(theEmotivPower.m_EmoState, tempData(0), tempData(1))
				Return tempData
			End Function
			'! Query the eyes position of the user
'            !
'                The horizontal and vertical position of the eyes are stored in the parameter x and y
'                respectively. They are floating point values ranging from -1.0 to 1.0.
'		
'                For horizontal position, -1.0 indicates that the user is looking left while
'                1.0 indicates that the user is looking right.
'		
'                For vertical position, -1.0 indicates that the user is looking down while
'                1.0 indicatest that the user is looking up.
'
'                This function assumes that both eyes have the same horizontal or vertical positions.
'                (i.e. no cross eyes)
'
'                \param state - EmoStateHandle
'                \param x - the horizontal position of the eyes
'                \param y - the veritcal position of the eyes
'
'            
			Private Function ExpressivGetEyeLocation() As Single()
				Dim tempData(1) As Single
				Emotiv.EdkDll.ES_ExpressivGetEyeLocation(theEmotivPower.m_EmoState, tempData(0), tempData(1))
				Return tempData
			End Function

			'! Returns the eyebrow extent of the user (Obsolete function)
'            !
'                \param state - EmoStateHandle
'		
'                \return eyebrow extent value (0.0 to 1.0)
'
'                \sa ES_ExpressivGetUpperFaceAction, ES_ExpressivGetUpperFaceActionPower
'            
			Private Function ExpressivGetEyebrowExtent() As Single
				Return Emotiv.EdkDll.ES_ExpressivGetEyebrowExtent(theEmotivPower.m_EmoState)

			End Function

			'! Returns the smile extent of the user (Obsolete function)
'            !
'                \param state - EmoStatehandle
'		
'                \return smile extent value (0.0 to 1.0)
'
'                \sa ES_ExpressivGetLowerFaceAction, ES_ExpressivGetLowerFaceActionPower
'            
			Private Function ExpressivGetSmileExtent() As Single
				Return Emotiv.EdkDll.ES_ExpressivGetSmileExtent(theEmotivPower.m_EmoState)

			End Function

			'! Returns the clench extent of the user (Obsolete function)
'            !
'                \param state - EmoStatehandle
'
'                \return clench extent value (0.0 to 1.0)
'
'                \sa ES_ExpressivGetLowerFaceAction, ES_ExpressivGetLowerFaceActionPower
'            
			Private Function ExpressivGetClenchExtent() As Single
				Return Emotiv.EdkDll.ES_ExpressivGetClenchExtent(theEmotivPower.m_EmoState)

			End Function


			'! Returns the detected upper face Expressiv action of the user
'            !
'                \param state - EmoStatehandle
'
'                \return pre-defined Expressiv action types
'
'                \sa ES_ExpressivGetUpperFaceActionPower
'            
			Private Function ExpressivGetUpperFaceAction() As BaseData.FacialState.FaceExpressiv_enum
				Return CType(Emotiv.EdkDll.ES_ExpressivGetUpperFaceAction(theEmotivPower.m_EmoState), BaseData.FacialState.FaceExpressiv_enum)

			End Function

			'! Returns the detected upper face Expressiv action power of the user
'            !
'                \param state - EmoStatehandle
'
'                \return power value (0.0 to 1.0)
'
'                \sa ES_ExpressivGetUpperFaceAction
'            
			Private Function ExpressivGetUpperFaceActionPower() As Single
				Return Emotiv.EdkDll.ES_ExpressivGetUpperFaceActionPower(theEmotivPower.m_EmoState)

			End Function
			'! Returns the detected lower face Expressiv action of the user
'            !
'                \param state - EmoStatehandle
'
'                \return pre-defined Expressiv action types
'
'                \sa ES_ExpressivGetLowerFaceActionPower
'            

			Private Function ExpressivGetLowerFaceAction() As BaseData.FacialState.FaceExpressiv_enum
				Return CType(Emotiv.EdkDll.ES_ExpressivGetLowerFaceAction(theEmotivPower.m_EmoState), BaseData.FacialState.FaceExpressiv_enum)
			End Function
			'! Returns the detected lower face Expressiv action power of the user
'            !
'                \param state - EmoStatehandle
'
'                \return power value (0.0 to 1.0)
'
'                \sa ES_ExpressivGetLowerFaceAction
'            
			Private Function ExpressivGetLowerFaceActionPower() As Single
				Return Emotiv.EdkDll.ES_ExpressivGetLowerFaceActionPower(theEmotivPower.m_EmoState)

			End Function
			'! Query whether the signal is too noisy for Expressiv detection to be active
'            !
'                \param state - EmoStateHandle
'                \param type  - Expressiv detection type
'
'                \return detection state (0: Not Active, 1: Active)
'
'                \sa EE_ExpressivAlgo_t
'            
			Private Function ExpressivIsActive(ByVal type As Training.ExpressivAlgo_enum) As Boolean
				Return Emotiv.EdkDll.ES_ExpressivIsActive(theEmotivPower.m_EmoState, CType(type, Emotiv.EdkDll.EE_ExpressivAlgo_t))
			End Function
			#End Region ' ---Functions---
		End Class
		#End Region ' ---Expressiv---
		#Region "Gyro"
		Public Class Gyro
			#Region "GyroData"
			Public ReadOnly Property BuildGyroState() As BaseData.GyroState.GyroData
				Get
					Dim GyroData As New BaseData.GyroState.GyroData()
					Dim tempVal() As Integer = GetGyroDelta()

					GyroData.X = tempVal(0)
					GyroData.Y = tempVal(1)
					Return GyroData
				End Get
			End Property
			#End Region ' ---GyroData---

			#Region "vars"
			Private ReadOnly theEmotivPower As EmotivPower
			#End Region ' ---vars---

			#Region "con"
			Public Sub New(ByVal EmotivPowerIN As EmotivPower)
				theEmotivPower = EmotivPowerIN
			End Sub
			#End Region ' ---con---

			#Region "Functions"
			''' <summary>
			''' Returns the delta of the movement of the gyro since the previous call
			''' </summary>
			''' <returns>
			''' int[0]  - horizontal displacement
			''' int[1]  - vertical displacment
			''' </returns>
			Public Function GetGyroDelta() As Integer()
				Dim XY(1) As Integer

				Dim [error] As Integer = Emotiv.EdkDll.EE_HeadsetGetGyroDelta(theEmotivPower.UserID, XY(0), XY(1))
				If [error] <> 0 Then
					Throw New Exception("GetGyroDelta Error:" & [error])
				End If
				Return XY
			End Function

			''' <summary>
			''' Re-zero the gyro
			''' </summary>
			Public Sub RezeroGyro()
				Dim [error] As Integer = Emotiv.EdkDll.EE_HeadsetGyroRezero(theEmotivPower.UserID)
				If [error] <> 0 Then
					Throw New Exception("RezeroGyro Error:" & [error])
				End If
			End Sub
			#End Region ' ---Functions---
		End Class
		#End Region ' ---Gyro---
		#Region "HeadsetRawData"
		Public Class HeadsetRawData
			#Region "BuildHeadsetRawDataState"
			Public ReadOnly Property BuildHeadsetRawDataState() As BaseData.HeadsetRawDataState.HeadsetRawData_Data
				Get
					'  throw new System.Exception("do you have the edk.ddl with access to the RAW DATA. take this line out if you do #9hdfio8uh");

					Dim InputChannels_Array As Array = System.Enum.GetValues(GetType(BaseData.HeadsetRawDataState.InputChannels_enum))
					Dim dataArray(InputChannels_Array.Length - 1) As Object

					For i As Integer = InputChannels_Array.Length - 1 To 0 Step -1

						dataArray(i) = HeadsetGetSensorDetails(CType(InputChannels_Array.GetValue(i), BaseData.HeadsetRawDataState.InputChannels_enum))
					Next i







					'SetDataAcquisition(true);

					Dim HeadsetRawData As New BaseData.HeadsetRawDataState.HeadsetRawData_Data()

					Dim data As IntPtr = DataCreate()

					AcquisitionEnabled = CheckDataAcquisitionEnabled()
					NumberOfSample = DataGetNumberOfSample(data)
					BufferSizeInSec = DataGetBufferSizeInSec()
					SamplingRate = DataGetSamplingRate()


					Dim Buffer(NumberOfSample - 1) As Double

					Dim DataChannel_Array As Array = System.Enum.GetValues(GetType(DataChannel_enum))
					RawData = New Integer(DataChannel_Array.Length - 1){}
					For i As Integer = DataChannel_Array.Length - 1 To 0 Step -1
						RawData(i) = DataGet(data, CType(DataChannel_Array.GetValue(i), DataChannel_enum), Buffer, NumberOfSample)
					Next i
					Return HeadsetRawData
				End Get
			End Property
			#End Region ' ---BuildHeadsetRawDataState---

			#Region "vars"
			Private ReadOnly theEmotivPower As EmotivPower

			Private AcquisitionEnabled As Boolean
			Private NumberOfSample As UInteger
			Private BufferSizeInSec As Single
			Private SamplingRate As UInteger
			Private RawData() As Integer
			#End Region ' ---vars---

			#Region "con"
			Public Sub New(ByVal EmotivPowerIN As EmotivPower)
				theEmotivPower = EmotivPowerIN
			End Sub
			#End Region ' ---con---

			#Region "DataChannel_enum"
			Public Enum DataChannel_enum
				COUNTER
				INTERPOLATED
				RAW_CQ
				AF3
				F7
				F3
				FC5
				T7
				P7
				O1
				O2
				P8
				T8
				FC6
				F4
				F8
				AF4
				GYROX
				GYROY
				TIMESTAMP
				ES_TIMESTAMP
				FUNC_ID
				FUNC_VALUE
				MARKER
				SYNC_SIGNAL
			End Enum
			#End Region ' ---DataChannel_enum---

			#Region "functions"
			Private Function HeadsetGetSensorDetails(ByVal channelID As BaseData.HeadsetRawDataState.InputChannels_enum) As BaseData.HeadsetRawDataState.InputSensorDescriptor_pack
				Dim Descriptor As New BaseData.HeadsetRawDataState.InputSensorDescriptor_pack()

				Dim DescriptorOut As New Emotiv.EdkDll.InputSensorDescriptor_t()
				Dim channel As Emotiv.EdkDll.EE_InputChannels_t = CType(channelID, Emotiv.EdkDll.EE_InputChannels_t)

				Dim [error] As Integer = Emotiv.EdkDll.EE_HeadsetGetSensorDetails(channel, DescriptorOut)
				If [error] <> 0 Then
					Throw New Exception("HeadsetGetSensorDetails Error:" & [error])
				End If


				Descriptor.channelID = CType(DescriptorOut.channelId, BaseData.HeadsetRawDataState.InputChannels_enum)
				Descriptor.Exists = DescriptorOut.fExists
				Descriptor.xLoc = DescriptorOut.xLoc
				Descriptor.yLoc = DescriptorOut.yLoc
				Descriptor.zLabel = DescriptorOut.pszLabel
				Descriptor.zLoc = DescriptorOut.zLoc

				Return Descriptor
			End Function

			Private Function CheckDataAcquisitionEnabled() As Boolean
				Dim dataOut As Boolean
				Emotiv.EdkDll.EE_DataAcquisitionIsEnabled(theEmotivPower.UserID, dataOut)
				Return dataOut
			End Function

			Private Function DataCreate() As IntPtr
				Return Emotiv.EdkDll.EE_DataCreate()
			End Function

			Public Function DataGet(ByVal hData As IntPtr, ByVal channel As DataChannel_enum, ByVal buffer() As Double, ByVal bufferSizeInSample As UInteger) As Integer
				Return Emotiv.EdkDll.EE_DataGet(hData, CType(channel, Emotiv.EdkDll.EE_DataChannel_t), buffer, bufferSizeInSample)
			End Function

			Public Function DataGetBufferSizeInSec() As Single
				Dim BufferSizeInSec As Single
				Dim [error] As Integer = Emotiv.EdkDll.EE_DataGetBufferSizeInSec(BufferSizeInSec)
				If [error] <> 0 Then
					Throw New Exception("DataGetBufferSizeInSec Error:" & [error])
				End If
				Return BufferSizeInSec
			End Function

			Public Function DataGetNumberOfSample(ByVal Data As IntPtr) As UInteger
				Dim Sample As UInteger

				Dim [error] As Integer = Emotiv.EdkDll.EE_DataGetNumberOfSample(Data, Sample)
				If [error] <> 0 Then
					Throw New Exception("DataGetNumberOfSample Error:" & [error])
				End If

				Return Sample
			End Function

			Public Function DataGetSamplingRate() As UInteger
				Dim SamplingRate As UInteger

				Dim [error] As Integer = Emotiv.EdkDll.EE_DataGetSamplingRate(theEmotivPower.UserID, SamplingRate)
				If [error] <> 0 Then
					Throw New Exception("DataGetSamplingRate Error:" & [error])
				End If

				Return SamplingRate
			End Function

			Public Sub DataFree(ByVal hData As IntPtr)
				Emotiv.EdkDll.EE_DataFree(hData)
			End Sub




			Private Sub SetDataAcquisition(ByVal SetDataAcquisition As Boolean)
				Emotiv.EdkDll.EE_DataAcquisitionEnable(theEmotivPower.UserID, SetDataAcquisition)
			End Sub
			Public Sub DataSetBufferSizeInSec(ByVal bufferSizeInSec As Single)
				Dim [error] As Integer = Emotiv.EdkDll.EE_DataSetBufferSizeInSec(bufferSizeInSec)
				If [error] <> 0 Then
					Throw New Exception("DataSetBufferSizeInSec Error:" & [error])
				End If
			End Sub

			Public Sub DataSetMarker(ByVal marker As Integer)
				Dim [error] As Integer = Emotiv.EdkDll.EE_DataSetMarker(theEmotivPower.UserID, marker)
				If [error] <> 0 Then
					Throw New Exception("DataSetMarker Error:" & [error])
				End If
			End Sub

			Public Sub DataSetSychronizationSignal(ByVal signal As Integer)
				Dim [error] As Integer = Emotiv.EdkDll.EE_DataSetSychronizationSignal(theEmotivPower.UserID, signal)
				If [error] <> 0 Then
					Throw New Exception("DataSetMarker Error:" & [error])
				End If
			End Sub

			Public Sub DataUpdateHandle(ByVal hData As IntPtr)
				Dim [error] As Integer = Emotiv.EdkDll.EE_DataUpdateHandle(theEmotivPower.UserID, hData)
				If [error] <> 0 Then
					Throw New Exception("DataSetMarker Error:" & [error])
				End If
			End Sub
			#End Region ' ---functions---
		End Class
		#End Region ' ---HeadsetRawData---
		#Region "HeadsetBase"
		Public Class HeadsetBase
			#Region "HeadsetState"
			Public ReadOnly Property GetHeadsetBaseState() As BaseData.HeadsetBaseState.HeadsetBaseData
				Get
					Dim tempHeadsetState As New BaseData.HeadsetBaseState.HeadsetBaseData()
					tempHeadsetState.BatteryChargeLevel = GetBatteryChargeLevel()
					tempHeadsetState.BatteryChargePercentage = GetBatteryChargePercent()
					tempHeadsetState.BatteryChargeMax = GetBatteryChargeMax()
					tempHeadsetState.HeadsetOn = GetHeadsetOn()
					tempHeadsetState.SignalStrength = GetWirelessSignalStatus()
					' tempHeadsetState.TimeStamp
					Return tempHeadsetState
				End Get
			End Property
			#End Region ' ---HeadsetState---

			#Region "vars"
			Private ReadOnly theEmotivPower As EmotivPower
			#End Region ' ---vars---

			#Region "con"
			Public Sub New(ByVal EmotivPowerIN As EmotivPower)
				theEmotivPower = EmotivPowerIN
			End Sub
			#End Region ' ---con---

			#Region "ver data"
			Public Function GetHardwareGetVersion() As UInteger
				Dim HwVersion As UInteger
				Emotiv.EdkDll.EE_HardwareGetVersion(theEmotivPower.UserID, HwVersion)
				Return HwVersion
			End Function
			Public Function SoftwareGetVersion() As String
				Dim SB_Version As New StringBuilder()
				Dim BuildNum As UInteger

				'ToDo: not Sure what this does
				Dim VersionChars As UInteger = 5

				Emotiv.EdkDll.EE_SoftwareGetVersion(SB_Version, VersionChars, BuildNum)
				Return SB_Version.ToString() & " : " & BuildNum.ToString()
			End Function
			#End Region ' ---var data---
			#Region "Battery"
			Public Function GetBatteryChargeLevel() As Integer
				Dim chargeLevel As Integer
				Dim maxChargeLevel As Integer
				Emotiv.EdkDll.ES_GetBatteryChargeLevel(theEmotivPower.m_EmoState, chargeLevel, maxChargeLevel)
				Return chargeLevel
			End Function
			Public Function GetBatteryChargeMax() As Integer
				Dim chargeLevel As Integer
				Dim maxChargeLevel As Integer
				Emotiv.EdkDll.ES_GetBatteryChargeLevel(theEmotivPower.m_EmoState, chargeLevel, maxChargeLevel)
				Return maxChargeLevel
			End Function
			Public Function GetBatteryChargePercent() As Integer?
				Dim chargeLevel As Integer
				Dim maxChargeLevel As Integer
				Emotiv.EdkDll.ES_GetBatteryChargeLevel(theEmotivPower.m_EmoState, chargeLevel, maxChargeLevel)
				If chargeLevel = -1 Then
					Return Nothing
				End If
				Return CInt(Fix(((CSng(chargeLevel) / maxChargeLevel)) * 100))
			End Function
			Public Function GetHeadsetOn() As Boolean
				Return Convert.ToBoolean(Emotiv.EdkDll.ES_GetHeadsetOn(theEmotivPower.m_EmoState))
			End Function
			Public Function GetWirelessSignalStatus() As BaseData.HeadsetBaseState.SignalStrength_enum
				Return CType(Emotiv.EdkDll.ES_GetWirelessSignalStatus(theEmotivPower.m_EmoState), BaseData.HeadsetBaseState.SignalStrength_enum)
			End Function
			#End Region ' ---Battery---

			#Region "Contact"
			Public Function GetContactQuality(ByVal electrodID As Integer) As BaseData.HeadsetBaseState.EEG_ContactQuality_enum
				Return CType(Emotiv.EdkDll.ES_GetContactQuality(theEmotivPower.m_EmoState, electrodID), BaseData.HeadsetBaseState.EEG_ContactQuality_enum)
			End Function

			Public Function GetContactQualityFromAllChannels() As BaseData.HeadsetBaseState.EEG_ContactQuality_enum()
				Dim tempArray() As Emotiv.EdkDll.EE_EEG_ContactQuality_t = Nothing
				Emotiv.EdkDll.ES_GetContactQualityFromAllChannels(theEmotivPower.m_EmoState, tempArray)
				Dim Array(tempArray.Length - 1) As BaseData.HeadsetBaseState.EEG_ContactQuality_enum

				For i As Integer = 0 To tempArray.Length - 1
					Array(i) = CType(tempArray(i), BaseData.HeadsetBaseState.EEG_ContactQuality_enum)
				Next i

				Return Array
			End Function
			#End Region ' ---Contact---

			#Region "ExpressivSignatureTrained"
			Public Function GetExpressivSignatureTrained() As Boolean
				' Ask Helmit if it has TrainedSignatureAvailable
				Dim tempData As Integer
				Dim failToCheck As Boolean = Convert.ToBoolean(Emotiv.EdkDll.EE_ExpressivGetTrainedSignatureAvailable(theEmotivPower.UserID, tempData))

				If failToCheck Then
					Throw New Exception("Fail to check for Trained Signature.#90j0fhfh")
				End If

				Return Convert.ToBoolean(tempData)
			End Function

			Public Function SetExpressivSignatureTypeToTrained(ByVal ExpressivData As EmotivPower.BaseData.FacialState.ExpressivData) As Boolean
				Dim result As Integer = Emotiv.EdkDll.EE_ExpressivSetSignatureType(theEmotivPower.UserID, CType(ExpressivData.myExpressivAction, Emotiv.EdkDll.EE_ExpressivSignature_t))
				Return (result = Emotiv.EdkDll.EDK_EXP_NO_SIG_AVAILABLE)
			End Function
			#End Region ' ---ExpressivSignatureTrained---
		End Class
		#End Region ' ---HeadsetBase---
		#Region "User"
		Public Class User
			#Region "vars"
			Private ReadOnly theEmotivPower As EmotivPower
			Public Delegate Sub sendUser(ByVal userID_IN As UInteger)
			Public Event NewUser As sendUser
			Public Event RemovedUser As sendUser
			#End Region ' ---vars---

			#Region "con"
			Public Sub New(ByVal EmotivPowerIN As EmotivPower)
				theEmotivPower = EmotivPowerIN
				AddHandler theEmotivPower.m_EmoEngine.UserAdded, AddressOf m_EmoEngine_UserAdded
				AddHandler theEmotivPower.m_EmoEngine.UserRemoved, AddressOf m_EmoEngine_UserRemoved
			End Sub
			#End Region ' ---con---

			Private Sub m_EmoEngine_UserAdded(ByVal sender As Object, ByVal e As Emotiv.EmoEngineEventArgs)
				Dim userID As UInteger = e.userId
				RaiseEvent NewUser(userID)
			End Sub

			Private Sub m_EmoEngine_UserRemoved(ByVal sender As Object, ByVal e As Emotiv.EmoEngineEventArgs)
				Dim userID As UInteger = e.userId

				RaiseEvent RemovedUser(userID)
			End Sub

			' not sure if it needs to send event
			#Region "send event"
			Public Delegate Sub sendUserAndType(ByVal eventType As UserTypes, ByVal userID As UInteger)
			Public Enum UserTypes
				UserAdded = &H10
				UserRemoved = &H20
			End Enum
			Public Event sendEvent As sendUserAndType
			#Region "FireEvent"
			Public Sub FireEvent(ByVal typeIN As UserTypes, ByVal UserID_IN As UInteger)
				RaiseEvent sendEvent(typeIN, UserID_IN)
			End Sub
			#End Region ' ---FireEvent---
			#End Region ' ---send event---

			Public Sub SaveUserProfile(ByVal fileNameIN As String)
				Emotiv.EdkDll.EE_SaveUserProfile(theEmotivPower.UserID, fileNameIN)
			End Sub
			Public Sub LoadUserProfile(ByVal fileNameIN As String)
				Emotiv.EdkDll.EE_LoadUserProfile(theEmotivPower.UserID, fileNameIN)
			End Sub
		End Class
		#End Region ' ---User---
		#Region "Training"
		Public Class Training
			#Region "TrainingData"
			Public ReadOnly Property GetTraining() As BaseData.TrainingState.TrainingData
				Get
					Dim tempTrainingState As New BaseData.TrainingState.TrainingData()
					' tempCognitivState.actionPower = 
					Return tempTrainingState
				End Get
			End Property
			#End Region ' ---TrainingData---

			#Region "enum"
			Public Enum ExpressivAlgo_enum
				EXP_NEUTRAL = &H1
				EXP_BLINK = &H2
				EXP_WINK_LEFT = &H4
				EXP_WINK_RIGHT = &H8
				EXP_HORIEYE = &H10
				EXP_EYEBROW = &H20
				EXP_FURROW = &H40
				EXP_SMILE = &H80
				EXP_CLENCH = &H100
				EXP_LAUGH = &H200
				EXP_SMIRK_LEFT = &H400
				EXP_SMIRK_RIGHT = &H800
			End Enum
			Public Enum CognitivAction
				NEUTRAL = 1
				PUSH = 2
				PULL = 4
				LIFT = 8
				DROP = 16
				LEFT = 32
				RIGHT = 64
				ROTATE_LEFT = 128
				ROTATE_RIGHT = 256
				ROTATE_CLOCKWISE = 512
				ROTATE_COUNTER_CLOCKWISE = 1024
				ROTATE_FORWARDS = 2048
				ROTATE_REVERSE = 4096
				DISAPPEAR = 8192
			End Enum

			#End Region ' ---enum---

			#Region "event"
			Public Delegate Sub sendUser(ByVal userID As UInteger)
			Public Delegate Sub sendUserAndType(ByVal eventType As TrainingTypes, ByVal userID As UInteger)
			Public Enum TrainingTypes
				CognitivNoEvent = 0
				CognitivTrainingStarted = 1
				CognitivTrainingSucceeded = 2
				CognitivTrainingFailed = 3
				CognitivTrainingCompleted = 4
				CognitivTrainingDataErased = 5
				CognitivTrainingRejected = 6
				CognitivTrainingReset = 7
				CognitivAutoSamplingNeutralCompleted = 8
				CognitivSignatureUpdated = 9
			End Enum
			Public Event sendEvent As sendUserAndType
			#Region "FireEvent"
			Public Sub FireEvent(ByVal typeIN As TrainingTypes, ByVal UserID_IN As UInteger)
				RaiseEvent sendEvent(typeIN, UserID_IN)

			End Sub
			#End Region ' ---FireEvent---
			#End Region ' ---event---

			#Region "vars"
			Private ReadOnly theEmotivPower As EmotivPower
			#End Region ' ---vars---

			#Region "con"
			Public Sub New(ByVal theEmotivPowerIN As EmotivPower)
				theEmotivPower = theEmotivPowerIN
			End Sub
			#End Region ' ---con---

			#Region "functions"
			Private started As Emotiv.EmoEngine.CognitivTrainingStartedEventEventHandler = Nothing
			Private [stop] As Emotiv.EmoEngine.CognitivTrainingSucceededEventHandler = Nothing
			Private Semaphore_BlockTraining As System.Threading.Semaphore
			Public Sub Train(ByVal CognitivActionIN As CognitivAction, ByVal userID_IN As UInteger)
				SyncLock Me
					Semaphore_BlockTraining = New System.Threading.Semaphore(0, 1)
					' hold fore event to finish training
					started = New Emotiv.EmoEngine.CognitivTrainingStartedEventEventHandler(AddressOf Train1)
					AddHandler theEmotivPower.m_EmoEngine.CognitivTrainingStarted, started

					Dim val As Emotiv.EdkDll.EE_CognitivAction_t = CType(System.Enum.ToObject(GetType(Emotiv.EdkDll.EE_CognitivAction_t), CognitivActionIN), Emotiv.EdkDll.EE_CognitivAction_t)

					If val <> Emotiv.EdkDll.EE_CognitivAction_t.COG_NEUTRAL Then
						theEmotivPower.m_EmoEngine.CognitivSetActiveActions(userID_IN, CUInt(val))
					End If

					theEmotivPower.m_EmoEngine.CognitivSetTrainingAction(userID_IN, val)
					theEmotivPower.m_EmoEngine.CognitivSetTrainingControl(userID_IN, Emotiv.EdkDll.EE_CognitivTrainingControl_t.COG_START)


					Semaphore_BlockTraining.WaitOne()
				End SyncLock
			End Sub
			Private Sub Train1(ByVal sender As Object, ByVal e As Emotiv.EmoEngineEventArgs)
				RemoveHandler theEmotivPower.m_EmoEngine.CognitivTrainingStarted, started
				[stop] = New Emotiv.EmoEngine.CognitivTrainingSucceededEventHandler(AddressOf Train2)
				AddHandler theEmotivPower.m_EmoEngine.CognitivTrainingSucceeded, [stop]
			End Sub
			Private Sub Train2(ByVal sender As Object, ByVal e As Emotiv.EmoEngineEventArgs)
				RemoveHandler theEmotivPower.m_EmoEngine.CognitivTrainingSucceeded, [stop]
				Semaphore_BlockTraining.Release()
			End Sub
			Public Function CheckForTrainedExpressivSignature() As Boolean
				Dim signatureAvailable As Integer

				Dim check As Boolean = (Emotiv.EdkDll.EE_ExpressivGetTrainedSignatureAvailable(theEmotivPower.UserID, signatureAvailable) = Emotiv.EdkDll.EDK_OK)

				If Not check Then
					Throw New Exception("Fail: CheckForTrainedExpressivSignature #iyhf9i8dfh")
				End If

				Return Convert.ToBoolean(signatureAvailable)
			End Function
			Public Function SelectExpressivSignature(ByVal useUniversal As Boolean) As Boolean
				Dim Signature As Emotiv.EdkDll.EE_ExpressivSignature_t

				If useUniversal Then
					Signature = Emotiv.EdkDll.EE_ExpressivSignature_t.EXP_SIG_UNIVERSAL
				Else
					Signature = Emotiv.EdkDll.EE_ExpressivSignature_t.EXP_SIG_TRAINED
				End If

				Dim result As Integer = Emotiv.EdkDll.EE_ExpressivSetSignatureType(theEmotivPower.UserID, CType(Signature, Emotiv.EdkDll.EE_ExpressivSignature_t))
				Return (result <> Emotiv.EdkDll.EDK_EXP_NO_SIG_AVAILABLE)
			End Function
			Public Function SelectExpressivType(ByVal ExpressivType As ExpressivAlgo_enum) As Boolean
				Dim tempVar As Emotiv.EdkDll.EE_ExpressivAlgo_t = CType(ExpressivType, Emotiv.EdkDll.EE_ExpressivAlgo_t)
				Return (Emotiv.EdkDll.EE_ExpressivSetTrainingAction(theEmotivPower.UserID, tempVar) = Emotiv.EdkDll.EDK_OK)
			End Function
			Public Function Start() As Boolean
				Return (Emotiv.EdkDll.EE_ExpressivSetTrainingControl(theEmotivPower.UserID, Emotiv.EdkDll.EE_ExpressivTrainingControl_t.EXP_START) = Emotiv.EdkDll.EDK_OK)
			End Function
			Public Function Accept() As Boolean
				Return (Emotiv.EdkDll.EE_ExpressivSetTrainingControl(theEmotivPower.UserID, Emotiv.EdkDll.EE_ExpressivTrainingControl_t.EXP_ACCEPT) = Emotiv.EdkDll.EDK_OK)
			End Function
			Public Function Reject() As Boolean
				Return (Emotiv.EdkDll.EE_ExpressivSetTrainingControl(theEmotivPower.UserID, Emotiv.EdkDll.EE_ExpressivTrainingControl_t.EXP_REJECT) = Emotiv.EdkDll.EDK_OK)
			End Function
			Public Function [Erase]() As Boolean
				Return (Emotiv.EdkDll.EE_ExpressivSetTrainingControl(theEmotivPower.UserID, Emotiv.EdkDll.EE_ExpressivTrainingControl_t.EXP_ERASE) = Emotiv.EdkDll.EDK_OK)

			End Function
			#End Region ' ---functions---
		End Class
		#End Region ' ---Training---
		#End Region ' ---sub classes---

		#Region "IDisposable Members"
		Private Disposed As Boolean = False
		Public Sub Dispose() Implements IDisposable.Dispose
			If Disposed Then
				Return
			Else
				Disposed = True
			End If

			Semaphore_ThreadTakeInput.WaitOne(100)
			Semaphore_ThreadTakeInput1.WaitOne(100)
			Semaphore_ThreadTakeInput2.WaitOne(100)
			Semaphore_ThreadTakeInput3.WaitOne(100)

			System.Threading.Thread.Sleep(500)

			If InputThread IsNot Nothing Then
				InputThread.Abort()
			End If

			System.Threading.Thread.Sleep(100)

			Emotiv.EdkDll.EE_EngineDisconnect()
			Emotiv.EdkDll.EE_EmoStateFree(m_EmoState)
			Emotiv.EdkDll.EE_EmoEngineEventFree(m_EmoEnginEvent)
		End Sub
		#End Region ' ---IDisposable Members---
	End Class
End Namespace
