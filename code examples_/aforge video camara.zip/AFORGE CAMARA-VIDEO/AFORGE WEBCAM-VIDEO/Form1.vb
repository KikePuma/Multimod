﻿Imports AForge.Video
Imports AForge.Video.DirectShow
Imports AForge.Video.FFMPEG

Public Class Form1

    Dim CAMARA As VideoCaptureDevice 'CAMARA QUE ESTAMOS USANDO
    Dim BMP As Bitmap 'PARA GENERACION DE IMAGENES
    Dim ESCRITOR As New VideoFileWriter() 'GUARDA LAS IMAGENES EN MEMORIA

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom ' POR SI OLVIDAMOS AJUSTAR EL PICTUREBOX
    End Sub

    Private Sub ButtonCAMARA_Click(sender As System.Object, e As System.EventArgs) Handles ButtonCAMARA.Click
        Dim CAMARAS As VideoCaptureDeviceForm = New VideoCaptureDeviceForm() 'DIALOGO CAMARAS DISPONIBLES
        If CAMARAS.ShowDialog() = DialogResult.OK Then
            CAMARA = CAMARAS.VideoDevice 'CAMARA ELEGIDA
            AddHandler CAMARA.NewFrame, New NewFrameEventHandler(AddressOf CAPTURAR) ' EJECUTARA CADA VEZ QUE SE GENERE UNA IMAGEN
            CAMARA.Start() 'INICIA LA PRESENTACION DE IMAGENES EN EL PICTUREBOX
        End If
    End Sub

    Private Sub ButtonVIDEO_Click(sender As System.Object, e As System.EventArgs) Handles ButtonVIDEO.Click
        If ButtonVIDEO.BackColor = Color.Black Then 'NO ESTA GRABANDO VIDEO
            SaveFileDialog1.DefaultExt = ".avi" ' GUARDARA COMO ARCHIVO AVI
            If SaveFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                Dim ANCHO As Integer = CAMARA.VideoResolution.FrameSize.Width 'DEFINE EL ANCHO DEL FOTOGRAMA
                Dim ALTO As Integer = CAMARA.VideoResolution.FrameSize.Height ' DEFINE EL ALTO DEL FOTOGRAMA
                'CREA EL ARCHIVO PARA LOS DATOS CON LOS PARAMETROS DE GUARDADO
                ESCRITOR.Open(SaveFileDialog1.FileName, ANCHO, ALTO, NumericUpDownFPS.Value, VideoCodec.Default, NumericUpDownBRT.Value * 1000)
                ESCRITOR.WriteVideoFrame(BMP) 'EMPIEZA A GUARDAR DATOS
                ButtonVIDEO.BackColor = Color.Red 'PARA QUE SEPAMOS QUE ESTA GRABANDO
            End If
        Else
            ButtonVIDEO.BackColor = Color.Black ' ESTA GRABANDO
            ESCRITOR.Close() 'DEJA DE GUARDAR DATOS
        End If
    End Sub

    Private Sub CAPTURAR(sender As Object, eventArgs As NewFrameEventArgs)     
        If ButtonVIDEO.BackColor = Color.Black Then 'SI NO ESTA GRABANDO ......
            BMP = DirectCast(eventArgs.Frame.Clone(), Bitmap) 'PONE LOS DATOS EN EL BITMAP
            PictureBox1.Image = DirectCast(eventArgs.Frame.Clone(), Bitmap) 'LOS PRESENTA EN EL PICTURE BOX
        Else ' SI ESTAS GRABANDO...
            Try
                BMP = DirectCast(eventArgs.Frame.Clone(), Bitmap) 'PON LOS DATOS EN EL BITMAP
                PictureBox1.Image = DirectCast(eventArgs.Frame.Clone(), Bitmap) 'LOS PRESENTA EN EL PICTURE BOX
                ESCRITOR.WriteVideoFrame(BMP) 'LOS GUARDA EN LA MEMORIA
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub ButtonFOTO_Click(sender As System.Object, e As System.EventArgs) Handles ButtonFOTO.Click
        CAPTURA.PictureBox1.Image = PictureBox1.Image 'COPIA LA IMAGEN QUE HAY EN EL PICTUREBOX EN EL PICTUREBOX DEL FORMULARIO CAPTURA
        CAPTURA.Show() 'MUESTRA EL FORMULARIO CAPTURA
    End Sub

    Private Sub ButtonCERRAR_Click(sender As System.Object, e As System.EventArgs) Handles ButtonCERRAR.Click
        Me.Close() 'ESTE BOTON NO HACE FALTA PERO QUEDA ELEGANTE
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            CAMARA.Stop() 'CIERRA LA CAMARA
            ESCRITOR.Close() 'DEJA DE GUARDAR DATOS.
        Catch ex As Exception
        End Try
    End Sub
End Class
