﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ButtonCAMARA = New System.Windows.Forms.Button()
        Me.ButtonFOTO = New System.Windows.Forms.Button()
        Me.ButtonVIDEO = New System.Windows.Forms.Button()
        Me.ButtonCERRAR = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.NumericUpDownFPS = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NumericUpDownBRT = New System.Windows.Forms.NumericUpDown()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownFPS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownBRT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 10)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(640, 480)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'ButtonCAMARA
        '
        Me.ButtonCAMARA.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonCAMARA.BackColor = System.Drawing.Color.Black
        Me.ButtonCAMARA.ForeColor = System.Drawing.Color.Cyan
        Me.ButtonCAMARA.Location = New System.Drawing.Point(668, 10)
        Me.ButtonCAMARA.Name = "ButtonCAMARA"
        Me.ButtonCAMARA.Size = New System.Drawing.Size(140, 40)
        Me.ButtonCAMARA.TabIndex = 1
        Me.ButtonCAMARA.Text = "CAMARA"
        Me.ButtonCAMARA.UseVisualStyleBackColor = False
        '
        'ButtonFOTO
        '
        Me.ButtonFOTO.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonFOTO.BackColor = System.Drawing.Color.Black
        Me.ButtonFOTO.ForeColor = System.Drawing.Color.Cyan
        Me.ButtonFOTO.Location = New System.Drawing.Point(668, 395)
        Me.ButtonFOTO.Name = "ButtonFOTO"
        Me.ButtonFOTO.Size = New System.Drawing.Size(140, 40)
        Me.ButtonFOTO.TabIndex = 2
        Me.ButtonFOTO.Text = "FOTO"
        Me.ButtonFOTO.UseVisualStyleBackColor = False
        '
        'ButtonVIDEO
        '
        Me.ButtonVIDEO.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonVIDEO.BackColor = System.Drawing.Color.Black
        Me.ButtonVIDEO.ForeColor = System.Drawing.Color.Cyan
        Me.ButtonVIDEO.Location = New System.Drawing.Point(668, 144)
        Me.ButtonVIDEO.Name = "ButtonVIDEO"
        Me.ButtonVIDEO.Size = New System.Drawing.Size(140, 40)
        Me.ButtonVIDEO.TabIndex = 3
        Me.ButtonVIDEO.Text = "VIDEO"
        Me.ButtonVIDEO.UseVisualStyleBackColor = False
        '
        'ButtonCERRAR
        '
        Me.ButtonCERRAR.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonCERRAR.BackColor = System.Drawing.Color.Black
        Me.ButtonCERRAR.ForeColor = System.Drawing.Color.Cyan
        Me.ButtonCERRAR.Location = New System.Drawing.Point(668, 450)
        Me.ButtonCERRAR.Name = "ButtonCERRAR"
        Me.ButtonCERRAR.Size = New System.Drawing.Size(140, 40)
        Me.ButtonCERRAR.TabIndex = 4
        Me.ButtonCERRAR.Text = "CERRAR"
        Me.ButtonCERRAR.UseVisualStyleBackColor = False
        '
        'NumericUpDownFPS
        '
        Me.NumericUpDownFPS.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NumericUpDownFPS.BackColor = System.Drawing.Color.Black
        Me.NumericUpDownFPS.ForeColor = System.Drawing.Color.Yellow
        Me.NumericUpDownFPS.Location = New System.Drawing.Point(728, 69)
        Me.NumericUpDownFPS.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.NumericUpDownFPS.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownFPS.Name = "NumericUpDownFPS"
        Me.NumericUpDownFPS.Size = New System.Drawing.Size(80, 22)
        Me.NumericUpDownFPS.TabIndex = 5
        Me.NumericUpDownFPS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDownFPS.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(665, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 16)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "FPS"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(665, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 16)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "BRT"
        '
        'NumericUpDownBRT
        '
        Me.NumericUpDownBRT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NumericUpDownBRT.BackColor = System.Drawing.Color.Black
        Me.NumericUpDownBRT.ForeColor = System.Drawing.Color.Yellow
        Me.NumericUpDownBRT.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDownBRT.Location = New System.Drawing.Point(728, 103)
        Me.NumericUpDownBRT.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDownBRT.Minimum = New Decimal(New Integer() {200, 0, 0, 0})
        Me.NumericUpDownBRT.Name = "NumericUpDownBRT"
        Me.NumericUpDownBRT.Size = New System.Drawing.Size(80, 22)
        Me.NumericUpDownBRT.TabIndex = 7
        Me.NumericUpDownBRT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDownBRT.Value = New Decimal(New Integer() {300, 0, 0, 0})
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(820, 502)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NumericUpDownBRT)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.NumericUpDownFPS)
        Me.Controls.Add(Me.ButtonCERRAR)
        Me.Controls.Add(Me.ButtonVIDEO)
        Me.Controls.Add(Me.ButtonFOTO)
        Me.Controls.Add(Me.ButtonCAMARA)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Cyan
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CAMARA A VIDEO"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownFPS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownBRT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonCAMARA As System.Windows.Forms.Button
    Friend WithEvents ButtonFOTO As System.Windows.Forms.Button
    Friend WithEvents ButtonVIDEO As System.Windows.Forms.Button
    Friend WithEvents ButtonCERRAR As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents NumericUpDownFPS As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownBRT As System.Windows.Forms.NumericUpDown

End Class
