﻿Public Class CAPTURA

    Private Sub CAPTURA_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        Me.TopMost = True

    End Sub

    Private Sub ButtonGUARDAR_Click(sender As System.Object, e As System.EventArgs) Handles ButtonGUARDAR.Click
        SaveFileDialog1.DefaultExt = ".jpg"
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            PictureBox1.Image.Save(SaveFileDialog1.FileName, Imaging.ImageFormat.Jpeg)
        End If
    End Sub
End Class